"""Resources: everything the console session loads once and shares (the corpus, the
matchers, the banis, the Granth in order, what was learnt from sewadars' picks)."""
from __future__ import annotations

import json
from pathlib import Path

from .akv import AKV_BANI
from .sehaj import Granth
from .learnt import Learnt

ANAND_SID, ANAND_SIX = 3375, 6     # Anand Sahib (shabad), and its 6 pauris and salok as sung in kirtan (bani)
LENGTHS = ("short", "medium", "long", "extra long")      # Rehras, Chaupai, Sohila and Aarti


def long_parts(corpus, base) -> dict[int, int]:
    """For the fuzzy line matcher: flat line index -> part of its composition,
    for compositions long enough to be split (same parts as PhraseMatcher).
    Walks the corpus exactly as ShabadMatcher built its flat index."""
    from .phrase_matcher import parts_of, SPLIT_OVER
    out, idx = {}, 0
    for sid, data in corpus.shabads.items():
        verses = data.get("verses", [])
        part_at = []
        if len(verses) > SPLIT_OVER:
            texts = [(v.get("gurmukhi") or {}).get("unicode") or v.get("unicode", "") for v in verses]
            for k, part in enumerate(parts_of(texts)):
                part_at += [k] * len(part)
        for i, verse in enumerate(verses):
            normalized = base.normalize_text(base.get_verse_text(verse))
            if len(normalized) >= 5 and not base._is_header_line(normalized):
                if part_at:
                    out[idx] = part_at[i]
                idx += 1
    assert idx == len(base._flat_lines), "flat index walk out of step"
    return out


class Resources:
    """Everything that is loaded once and shared by all sessions."""

    def __init__(self, repo: Path, learnt_path: Path | None = None):
        from engine import ShabadCorpus, ShabadMatcher
        from .phrase_matcher import PhraseMatcher
        self.corpus = ShabadCorpus(repo / "data" / "sggs_corpus.json")
        self.corpus.load()
        extra = repo / "data" / "sggs_extra.json"     # shabads the corpus lacks (tools/build_sggs_order.py)
        if extra.exists():
            for sh in json.loads(extra.read_text(encoding="utf-8")):
                self.corpus._index_shabad(sh)
        other_meta = {}
        other = repo / "data" / "other_corpus.json"   # Vaaran and Kabit Savaiye Bhai Gurdas Ji, Ghazals Bhai Nand Lal Ji
        if other.exists():
            o = json.loads(other.read_text(encoding="utf-8"))
            for sh in o["shabads"]:
                self.corpus._index_shabad(sh)
            other_meta = o.get("meta", {})
        self.base = ShabadMatcher(self.corpus)
        self.phrase = PhraseMatcher(self.corpus)
        self.base._flat_part = long_parts(self.corpus, self.base)
        self.learnt = Learnt(learnt_path)
        self.acoustic = None                           # see enable_acoustic()
        self.phrase.set_learnt(self.learnt.feature_map())
        self.banis = {b["id"]: b for b in json.loads((repo / "data" / "banis.json").read_text(encoding="utf-8"))}
        meta = json.loads((repo / "data" / "shabad_meta.json").read_text(encoding="utf-8"))
        self.meta = {**meta["shabads"], **other_meta}
        self.sid_banis = meta["sid_banis"]
        self.granth = Granth(self.corpus, self.meta, self.phrase.first_line, repo / "data" / "sggs_angs.json",
                             repo / "data" / "sggs_order.json")
        self.akv_sids = {ln["sid"] for ln in self.banis[AKV_BANI]["lines"] if ln.get("sid")}
        # Anand Sahib's opening (pauris 1-5) and last pauri, as sung in kirtan. The corpus
        # keeps those two as shabads of their own (333375, 333376; pauris 6-39 are 3375).
        six = self.banis[ANAND_SIX]["lines"]
        self.anand_lines = {ln["g"] for ln in six if ln.get("sid") == ANAND_SID}
        self.anand_parts = {sid for sid, g in self.phrase.first_line.items() if g in self.anand_lines}
        opening = next((ln["g"] for ln in six if ln["g"] in self.anand_lines and ln.get("type") == "Pankti"), "")
        self.anand_open = next((sid for sid in self.anand_parts if self.phrase.first_line[sid] == opening), ANAND_SID)

    def variants(self, bani_id: int) -> list[int]:
        """The same bani in its other lengths (Rehras, Chaupai, Sohila, Aarti), shortest first."""
        fam = self.banis[bani_id].get("family")
        if not fam:
            return [bani_id]
        ids = [b["id"] for b in self.banis.values() if b.get("family") == fam]
        return sorted(ids, key=lambda i: LENGTHS.index(self.banis[i].get("length", "short")))

    def anand_track(self) -> dict:
        """Anand Sahib as sung after Asa Ki Vaar: pauris 1-5, the 40th, and the salok
        ਪਵਣੁ ਗੁਰੂ, followed as one shabad."""
        b = self.banis[ANAND_SIX]
        return {"id": "k6", "kind": "shabad", "sid": self.anand_open, "lines": b["lines"],
                "title": self.phrase.first_line.get(self.anand_open, b["name_gurmukhi"]), "subtitle": b["name"]}

    def enable_acoustic(self, tokenizer_path) -> None:
        """Build the acoustic index (a few seconds); until then acoustic matching is off."""
        from .acoustic import AcousticIndex
        self.acoustic = AcousticIndex(self.corpus, tokenizer_path)

    def shabad_track(self, sid: int) -> dict:
        m = self.meta.get(str(sid), {})
        lines = []
        for ln in self.corpus.get_lines(sid):
            g = (ln.get("gurmukhi") or {}).get("unicode") or ln.get("unicode", "")
            lines.append({"g": g, "tr": ln.get("transliteration_english", ""),
                          "en": ln.get("translation_english", ""),
                          "sid": sid, "ang": m.get("ang"), "ref": m.get("ref"), "type": ""})
        return {"id": f"s{sid}", "kind": "shabad", "sid": sid, "lines": lines,
                "title": self.phrase.first_line.get(sid, ""),
                "subtitle": _where(m)}

    def bani_track(self, bani_id: int) -> dict:
        b = self.banis[bani_id]
        return {"id": f"b{bani_id}", "kind": "bani", "bani_id": bani_id, "lines": b["lines"],
                "title": b["name_gurmukhi"], "subtitle": b["name"]}


def _where(m: dict) -> str:
    if not m:
        return ""
    if m.get("where"):                        # Vaaran, Kabit Savaiye, Ghazals
        return m["where"]
    return f"Ang {m.get('ang')}, {m.get('raag')}, {m.get('writer')}"
