"""
Acoustic matching: score Gurbani lines against the speech model's sound
probabilities, not against the words it wrote down.

Every 80 ms the model gives the chance of each of its 256 Gurmukhi sound pieces
(plus "nothing new"). The written transcript keeps only the likeliest piece at
each moment; when singing is slow, drawn out or sung by a whole sangat, those
choices come out as nonsense words (ਜਚੇਣ, ਪਾਈਐਨ) that match nothing. The
probabilities underneath still fit the real line (ਚੈਨੁ ਨ ਪਾਈਐ) better than
they fit anything else.

For each check:
  1. candidate lines: character-trigram search of the transcript over every
     line (spaces ignored, so words run together or split apart still match);
  2. each candidate is aligned to the probabilities with CTC, anywhere in the
     window and any part of the line (a local alignment: +BONUS for each sound
     piece taken in, plus how much less likely it was than the best piece at
     that moment, which is <= 0);
  3. a shabad scores its best line.
"""
from __future__ import annotations

import math
from collections import defaultdict

import numpy as np

BLANK = 256
BONUS = 3.0            # reward per sound piece aligned
CANDIDATES = 1500      # lines scored per check (about 0.1-0.4 s)
MAX_DF = 3000          # trigrams in more lines than this don't help to find candidates


def _norm(text: str) -> str:
    from engine._internal.hard_ctc import normalize_gurmukhi
    return normalize_gurmukhi(text)


class AcousticIndex:
    def __init__(self, corpus, tokenizer_path):
        import sentencepiece as spm
        from engine._internal.hard_ctc import is_header_line
        self.sp = spm.SentencePieceProcessor(model_file=str(tokenizer_path))
        sids, toks, post = [], [], defaultdict(list)
        for sid in sorted(corpus.shabads):
            for v in corpus.get_lines(sid):
                g = _norm((v.get("gurmukhi") or {}).get("unicode") or v.get("unicode", ""))
                if not g or is_header_line(g) or len(g.split()) < 2:
                    continue
                i = len(sids)
                sids.append(sid)
                toks.append(np.array(self.sp.encode(g), dtype=np.int32))
                s = g.replace(" ", "")
                for tg in {s[j:j + 3] for j in range(len(s) - 2)}:
                    post[tg].append(i)
        self.sid = np.array(sids)
        self.tok = toks
        n = len(sids)
        self.post = {tg: np.array(p, dtype=np.int32) for tg, p in post.items() if len(p) <= MAX_DF}
        self.idf = {tg: math.log(n / len(p)) for tg, p in self.post.items()}

    def candidates(self, transcript: str, k: int = CANDIDATES) -> np.ndarray:
        s = _norm(transcript).replace(" ", "")
        acc = np.zeros(len(self.sid), dtype=np.float32)
        any_ = False
        for tg in {s[j:j + 3] for j in range(len(s) - 2)}:
            p = self.post.get(tg)
            if p is not None:
                acc[p] += self.idf[tg]
                any_ = True
        if not any_:
            return np.array([], dtype=np.int32)
        k = min(k, int((acc > 0).sum()))
        idx = np.argpartition(-acc, k - 1)[:k] if k < len(acc) else np.nonzero(acc)[0]
        return idx[np.argsort(-acc[idx])]

    def rank(self, logprobs, transcript: str, top: int = 5) -> list[tuple[int, float]]:
        """Best shabads for this window, by their best-aligned line."""
        if logprobs is None or len(logprobs) < 5:
            return []
        cand = self.candidates(transcript)
        if len(cand) == 0:
            return []
        sc = local_scores(logprobs, [self.tok[i] for i in cand])
        per: dict[int, float] = {}
        for i, s in zip(cand, sc):
            sid = int(self.sid[i])
            if s > per.get(sid, -1e9):
                per[sid] = float(s)
        return sorted(per.items(), key=lambda x: -x[1])[:top]


def local_scores(lp, token_lists, bonus: float = BONUS) -> np.ndarray:
    """Local CTC alignment score of each token list against log-probs lp [T, 257]:
    the best stretch of frames and the best run of the list's pieces, all lists at
    once (their CTC label sequences side by side in one array)."""
    R = np.asarray(lp, dtype=np.float32)
    R = R - R.max(axis=1, keepdims=True)                # <= 0: how much less likely than the best piece
    labs, adv_ok, skip_ok, seg = [], [], [], []
    for toks in token_lists:
        seg.append(len(labs))
        ext = [BLANK]
        for t in toks:
            ext += [int(t), BLANK]
        labs += ext
        adv_ok += [j >= 1 for j in range(len(ext))]
        skip_ok += [j >= 2 and ext[j] != BLANK and ext[j - 2] != ext[j] for j in range(len(ext))]
    labs = np.array(labs)
    adv_ok, skip_ok = np.array(adv_ok), np.array(skip_ok)
    gain = np.where(labs != BLANK, bonus, 0.0).astype(np.float32)
    neg = np.float32(-1e9)
    prev = np.full(len(labs), neg, dtype=np.float32)
    best = prev.copy()
    E = R[:, labs]
    adv, skp = np.empty_like(prev), np.empty_like(prev)
    for t in range(R.shape[0]):
        adv[0] = neg
        adv[1:] = prev[:-1]
        skp[:2] = neg
        skp[2:] = prev[:-2]
        cur = np.maximum(np.maximum(prev, np.where(adv_ok, adv + gain, neg)),
                         np.maximum(np.where(skip_ok, skp + gain, neg), gain)) + E[t]
        np.maximum(best, cur, out=best)
        prev = cur
    return np.maximum.reduceat(best, seg)
