"""What kind of window was heard: clear words, or music heard as syllables.
Used by every mode of the console session (engine_ext/console_session.py)."""
from __future__ import annotations

# While a shabad is on screen, a window with fewer than this many clear words
# (three letters or more) neither keeps nor leaves it: in sangat singing about a
# third of windows are fragments that match random shabads.
MIN_CLEAR_TO_LEAVE = 3

NOISE_FILTER = False                # tried: no gain on the five recordings (the hour was 2 min worse); kept for later work
_SIGNS = set("ਾਿੀੁੂੇੈੋੌੰਂੱ਼੍ੑਁਃ")


def is_noise(transcript: str) -> bool:
    """Tabla, harmonium or other music heard as syllables: hardly a word of
    three letters or more, and the same syllable again and again in a row
    (ਵਚ ਵਚ ਵਚ ਬਾ ਬਾ ਬਾ ਕਚ ਕਚ). A sung line repeats as a whole phrase
    (ਜੇ ਲੋਚੈ ਸਭੁ ਕੋਇ ਜੇ ਲੋਚੈ ...), not word by word, so it is not caught."""
    toks = transcript.split()
    if not NOISE_FILTER or len(toks) < 6:
        return False
    longer = sum(sum(ch not in _SIGNS for ch in w) >= 3 for w in toks)
    again = sum(a == b for a, b in zip(toks, toks[1:]))
    return longer <= 0.1 * len(toks) and again >= 0.25 * (len(toks) - 1)


def clear_words(transcript: str) -> int:
    if is_noise(transcript):
        return 0
    return sum(len(w) >= 3 for w in transcript.split())
