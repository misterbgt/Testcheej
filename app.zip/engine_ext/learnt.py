"""Learning how a sangat's singing comes through the speech recogniser.

When a sewadar picks a shabad (search, history, a suggestion, or going back),
that is a confirmation: while it stays on screen, what the recogniser heard is
saved against that shabad. A whole sangat singing often comes out garbled
("ਤੁਮ ਬਡ ਦਾਤੇ ਦੇ ਰਹੇ" as "ਤੁਮ ਵਡ ਰਾਗ ਦੇਰਾਹੇ"), but garbled the same way each
time, so those words become extra evidence for that shabad next time.

Safeguards:
  - a pick counts only if it stays on screen PENDING_S seconds (a mistaken pick
    changed straight away teaches nothing); teaching stops when the shabad
    changes, and after MAX_TEACH_S;
  - simran, near-silence and fragment-only windows are never saved;
  - a heard word or word pair counts only once it has turned up in MIN_SEEN
    separate windows for that shabad, and only words of 3+ letters;
  - words or pairs that learning has tied to more than MAX_SHABADS shabads
    are dropped as uninformative;
  - learnt words weigh less than real Gurbani words (see PhraseMatcher).

Stored as one JSON object per line in a file next to the history, so it stays
on this computer and can be cleared, copied or (later) pooled.
"""
from __future__ import annotations

import json
import time
from collections import defaultdict
from pathlib import Path

from .phrase_matcher import features, words_of

PENDING_S = 20.0
MAX_TEACH_S = 20 * 60.0
MIN_SEEN = 2
MAX_SHABADS = 3


class Learnt:
    def __init__(self, path: Path | None = None):
        self.path = Path(path) if path else None
        self.entries: list[dict] = []
        self.seen: dict[tuple[str, int], int] = defaultdict(int)
        if self.path and self.path.exists():
            for line in self.path.read_text(encoding="utf-8").splitlines():
                try:
                    e = json.loads(line)
                    if isinstance(e.get("sid"), int) and isinstance(e.get("text"), str):
                        self._count(e)
                except ValueError:
                    continue

    def add(self, sid: int, text: str, source: str = "pick"):
        e = {"sid": int(sid), "text": text, "src": source, "at": int(time.time())}
        self._count(e)
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(e, ensure_ascii=False) + "\n")

    def _count(self, e: dict):
        self.entries.append(e)
        for f in features(words_of(e["text"])):
            parts = f.split("_")
            if all(len(p) >= 3 for p in parts) or (len(parts) == 2 and any(len(p) >= 3 for p in parts)):
                self.seen[(f, e["sid"])] += 1

    def forget(self):
        self.entries, self.seen = [], defaultdict(int)
        if self.path and self.path.exists():
            self.path.unlink()

    def shabads(self) -> int:
        return len({e["sid"] for e in self.entries})

    def feature_map(self) -> dict[str, set[int]]:
        """feature -> shabads it has been learnt for (after the safeguards)."""
        out: dict[str, set[int]] = defaultdict(set)
        for (f, sid), n in self.seen.items():
            if n >= MIN_SEEN:
                out[f].add(sid)
        return {f: s for f, s in out.items() if len(s) <= MAX_SHABADS}


class Teacher:
    """Collects windows while a picked shabad stays on screen."""
    def __init__(self, learnt: Learnt):
        self.learnt, self.sid, self.t0, self.pending, self.enabled = learnt, None, 0.0, [], True

    def picked(self, sid: int, t: float):
        self.sid, self.t0, self.pending = int(sid), t, []

    def stop(self):
        self.sid, self.pending = None, []

    def heard(self, sid_on_screen: int | None, text: str, t: float) -> bool:
        """Returns True when something was committed (so the matcher can refresh)."""
        if not self.enabled or self.sid is None:
            return False
        if sid_on_screen != self.sid or t - self.t0 > MAX_TEACH_S:
            self.stop()
            return False
        self.pending.append(text)
        if t - self.t0 < PENDING_S:
            return False
        for x in self.pending:
            self.learnt.add(self.sid, x)
        self.pending = []
        return True
