"""
Akhand Paath / Sehaj Paath: follow Sri Guru Granth Sahib Ji in order.

In an Akhand Paath or Sehaj Paath the reader goes straight through the Granth,
shabad after shabad and Ang after Ang. Once the place is found, the next words
can only come from the lines just ahead, so there is no need to identify each
new shabad from scratch: the tracker simply carries on into the next shabad.

Granth          the order of Sri Guru Granth Sahib Ji (shabad IDs 1-5540 run in
                Ang order) with the Ang of every line.
SehajTracker    a BaniTracker over a window of the Granth: the shabad before,
                the current shabad and enough of the following ones to look
                ahead. When the reader moves into the next shabad, the window
                moves with them (the screen gets the new lines, the position is
                kept). If the place is not confirmed for a while, it looks further
                ahead (fast readers) and, the longer it stays unsure, further back too
                (the screen may have run ahead of the reader on a false match), and
                keeps the last line on screen meanwhile. A move far ahead or back
                must be heard twice in a row. If it stays unsure for long, the
                console (console_session.py) finds the place again across the whole
                Granth, as a fresh start would.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from .bani_tracker import BaniTracker, smith_waterman
from .phrase_matcher import words_of
from .simran import is_simran

SGGS_LAST = 5540            # shabad IDs above this are other texts (Vaaran, Kabit, Ghazals)
WINDOW_AHEAD = 45           # lines kept beyond the end of the current shabad
BACK, AHEAD = 2, 25         # search range around the confirmed line (in lines)
MIN_TRACK, MIN_COLD = 7.0, 10.0
LOST_AFTER = 3              # checks without a match before the wider search
WIDEN = 12                  # extra lines looked ahead per missed check (fast readers)
MAX_AHEAD = 160
LOST_BACK = 12              # how far back the wider search looks at first ...
BACK_GROW, MAX_BACK = 10, 120   # ... and how it widens per unsure check, up to this
DOUBT_LOST = 4              # checks without a strong match before it also looks back further
FAR = 30                    # a move further than this needs the stronger, unique match, heard twice
NEAR = 3                    # a move this small may come from a weaker match
MARGIN = 30                 # extra lines when the window has to grow
TIE = 1.5                   # ends scoring within this of the best count as a tie: the nearest wins
QUICK_WORDS, QUICK_MIN, QUICK_MARGIN = 7, 4.0, 1.0   # quick checks: the last words, next line only
QUICK_AHEAD = 3             # quick checks go at most this far beyond the last line a full check confirmed


class Granth:
    """Sri Guru Granth Sahib Ji in reading order, line by line, with the Ang of every
    line. From data/sggs_order.json (tools/build_sggs_order.py) when present: the order
    of the Shabad OS database, which also has the few shabads and lines the search
    corpus leaves out or keeps under other numbers. Otherwise from the corpus itself
    (shabad IDs 1-5540 in order, data/sggs_angs.json for the Angs)."""

    def __init__(self, corpus, meta: dict, first_line: dict, angs_path: Path | None = None,
                 order_path: Path | None = None):
        self.corpus, self.meta, self.first_line = corpus, meta, first_line
        self._rows: dict[int, list] = {}               # sid -> its lines (order file rows)
        self.loc: dict[tuple, int] = {}                # (corpus sid, corpus line) -> global line
        self.alias: dict[int, int] = {}                # corpus-only numbers -> the shabad holding them
        if order_path is not None and Path(order_path).exists():
            rows = json.loads(Path(order_path).read_text(encoding="utf-8"))["lines"]
            self.seq = []
            for g, r in enumerate(rows):
                sid = int(r[0])
                if not self.seq or self.seq[-1] != sid:
                    self.seq.append(sid)
                self._rows.setdefault(sid, []).append(r)
                if len(r) == 5:
                    self.loc.setdefault((int(r[3]), int(r[4])), g)
                    if int(r[3]) != sid:
                        self.alias.setdefault(int(r[3]), sid)
        else:
            self.seq = sorted(s for s in corpus.shabads if 1 <= int(s) <= SGGS_LAST and "ang" in meta.get(str(s), {}))
            breaks = {}
            if angs_path is not None and Path(angs_path).exists():
                breaks = {int(k): v for k, v in json.loads(Path(angs_path).read_text(encoding="utf-8")).items()}
            for sid in self.seq:
                n, br = len(corpus.get_lines(sid)), breaks.get(int(sid))
                angs, k = [], 0
                for i in range(n):
                    while br and k + 1 < len(br) and br[k + 1][0] <= i:
                        k += 1
                    angs.append(br[k][1] if br else meta.get(str(sid), {}).get("ang"))
                self._rows[sid] = [[sid, angs[i], 4, sid, i] for i in range(n)]
        self.index = {s: i for i, s in enumerate(self.seq)}
        self.start: dict[int, int] = {}                # global index of each shabad's first line
        g = 0
        for s in self.seq:
            self.start[s] = g
            g += len(self._rows[s])
        self.total = g

    def __contains__(self, sid) -> bool:
        return int(sid) in self.index or int(sid) in self.alias

    def count(self, sid: int) -> int:
        return len(self._rows[int(sid)])

    def canonical(self, sid: int) -> int:
        """The shabad of the Granth order for a corpus number."""
        sid = int(sid)
        return sid if sid in self.index else self.alias[sid]

    def locate(self, sid: int, line: int = 0) -> int:
        """Global line of line `line` of corpus shabad `sid` (as search results give it)."""
        sid, line = int(sid), max(0, int(line))
        g = self.loc.get((sid, line))
        if g is not None:
            return g
        for k in range(1, min(line, 12) + 1):          # a corpus line the order lacks: the line after the one before it
            g = self.loc.get((sid, line - k))
            if g is not None:
                return min(g + 1, self.total - 1)
        if sid in self.index:
            return self.start[sid] + min(line, self.count(sid) - 1)
        firsts = [g for (s, i), g in self.loc.items() if s == sid]
        return min(firsts) if firsts else self.start[self.canonical(sid)]

    def corpus_line(self, g: int) -> tuple[int, int]:
        """The corpus shabad and line of global line g, as locate takes them back (for
        one of the few lines the corpus lacks, the corpus line before it)."""
        sid = self.sid_at(max(0, min(int(g), self.total - 1)))
        rows = self._rows[sid]
        i = max(0, min(int(g) - self.start[sid], len(rows) - 1))
        for k in range(i, -1, -1):
            if len(rows[k]) == 5:
                return int(rows[k][3]), int(rows[k][4])
        return sid, 0

    def angs(self, sid: int) -> list[int]:
        return [r[1] for r in self._rows[int(sid)]]

    def where(self, sid: int, ang=None) -> str:
        m = self.meta.get(str(sid), {})
        return f"Ang {ang or m.get('ang')}, {m.get('raag')}, {m.get('writer')}"

    def title(self, sid: int) -> str:
        t = self.first_line.get(int(sid))
        if t:
            return t
        rows = self._rows.get(int(sid), [])
        r = next((r for r in rows if r[2] == 4), rows[0] if rows else None)
        return "" if r is None else self._text(r)[0]

    def _text(self, r) -> tuple[str, str, str]:
        if len(r) == 5:
            L = self.corpus.get_lines(int(r[3]))
            ln = L[int(r[4])] if int(r[4]) < len(L) else {}
            return ((ln.get("gurmukhi") or {}).get("unicode") or ln.get("unicode", ""),
                    ln.get("transliteration_english", ""), ln.get("translation_english", ""))
        return r[3], r[4], r[5]

    def lines(self, sid: int) -> list[dict]:
        rows = self._rows[int(sid)]
        title = self.title(sid)
        out = []
        for i, r in enumerate(rows):
            g, tr, en = self._text(r)
            out.append({"g": g, "tr": tr, "en": en, "sid": int(sid), "ang": r[1], "type": "", "li": i,
                        "ln": len(rows), "st": title, "sub": self.where(sid, r[1])})
        return out

    def window(self, sid: int, ahead: int = WINDOW_AHEAD, behind: int = 0) -> list[int]:
        """Shabads for a window around sid: the one before (and more, until at least
        `behind` lines lie before sid), sid, and following ones until at least
        `ahead` lines lie beyond the end of sid."""
        i = self.index[self.canonical(sid)]
        b, nb = max(0, i - 1), (self.count(self.seq[i - 1]) if i > 0 else 0)
        while nb < behind and b > 0:
            b -= 1
            nb += self.count(self.seq[b])
        sids = self.seq[b: i + 1]
        n, j = 0, i + 1
        while n < ahead and j < len(self.seq):
            sids.append(self.seq[j])
            n += self.count(self.seq[j])
            j += 1
        return sids

    def sid_at(self, g: int) -> int:
        """The shabad holding global line g."""
        lo, hi = 0, len(self.seq) - 1
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if self.start[self.seq[mid]] <= g:
                lo = mid
            else:
                hi = mid - 1
        return self.seq[lo]


class SehajTracker(BaniTracker):
    """Follows the Granth in order through a moving window (see the module notes).
    Positions (pos) are indexes into the current window, like any tracker; after a
    call that may move the window, `shift` says by how many lines indexes moved
    (new index = old index - shift) and `moved` says the window's lines changed."""

    def __init__(self, granth: Granth, sid: int):
        self.granth = granth
        self.shift, self.moved = 0, False
        self.hits = 0                                  # confirmed checks since the place was found
        self.doubt = 0                                 # checks since the last strong match
        self.pending = None                            # a far move heard once: (global line, check no.)
        self.checks = 0
        self.last = (None, 0.0, 0.0)                   # last check: (global line or None, score, runner)
        self.main_g = None                             # the last line a full check (or a sewadar) confirmed
        self._build(granth.canonical(sid))
        self.pos = None

    # ---- the window
    def _build(self, center: int, ahead: int = WINDOW_AHEAD, behind: int = 0):
        g = self.granth
        self.center = center
        self.sids = g.window(center, ahead, behind)
        lines = []
        for s in self.sids:
            lines += g.lines(s)
        self.g0 = g.start[self.sids[0]]
        super().__init__({"lines": lines}, back=BACK, ahead=AHEAD, min_track=MIN_TRACK,
                         min_cold=MIN_COLD, lost_after=LOST_AFTER)

    def track(self) -> dict:
        c = self.center
        return {"id": f"g{self.g0}-{self.g0 + len(self.lines)}", "kind": "granth", "lines": self.lines,
                "title": self.granth.title(c), "subtitle": self.granth.where(c),
                "sid": c}

    def _recentre(self, g_keep: int | None, ahead: int = WINDOW_AHEAD, behind: int = 0):
        """Rebuild the window around the shabad of global line g_keep."""
        old_g0, pos, misses = self.g0, self.pos, self.misses
        sid = self.granth.sid_at(g_keep) if g_keep is not None else self.center
        self._build(sid, ahead, behind)
        self.shift += self.g0 - old_g0
        self.moved = True
        self.pos = None if pos is None else max(0, min(old_g0 + pos - self.g0, len(self.lines) - 1))
        self.misses = misses

    def keep_up(self, need_ahead: int = 0, need_back: int = 0):
        """Move the window when the reader has entered another shabad, or when
        the search needs to look further ahead (or back) than the window reaches."""
        if self.pos is None:
            return
        cur = self.lines[self.pos]["sid"]
        start = self.granth.start[self.center] - self.g0
        end = start + self.granth.count(self.center)
        room = len(self.lines) - 1 - self.pos
        # when the window must grow, it grows with room to spare (MARGIN), so the screens
        # are not sent new lines at every check while the search widens
        behind = need_back - (self.pos - start) + MARGIN if need_back > self.pos and self.g0 > 0 else 0
        if cur != self.center:
            self._recentre(self.g0 + self.pos, max(WINDOW_AHEAD, need_ahead), max(0, need_back))
        elif (need_ahead > room and self.sids[-1] != self.granth.seq[-1]) or behind > 0:
            self._recentre(self.g0 + self.pos, max(WINDOW_AHEAD, need_ahead - (end - self.pos) + MARGIN),
                           max(0, behind))

    def take_shift(self) -> tuple[int, bool]:
        s, m = self.shift, self.moved
        self.shift, self.moved = 0, False
        return s, m

    def settled(self):
        """The place was just set (by hand, or found again): no doubt about it."""
        self.misses, self.doubt, self.pending = 0, 0, None
        self.main_g = None if self.pos is None else self.g0 + self.pos

    def place(self, pos: int):
        self.pos = max(0, min(int(pos), len(self.lines) - 1))
        self.settled()
        self.keep_up()

    def place_sid(self, sid: int, line: int = 0):
        """Line `line` of corpus shabad `sid` (from search, history or a suggestion)."""
        g = self.granth.locate(sid, line)
        if not (self.g0 <= g < self.g0 + len(self.lines)):
            self.pos = None
            self._recentre(g)
        self.pos = g - self.g0
        self.settled()
        self.keep_up()

    def relocate(self, sid: int, transcript: str = "") -> bool:
        """Found again across the Granth (console_session): go to shabad sid, at the
        line that fits what was just read (it may be in the next shabad)."""
        g_first = self.granth.locate(sid, 0)
        self.pos = None
        self._recentre(g_first)
        q = words_of(transcript)
        lo = g_first - self.g0
        line, sc = None, 0.0
        if len(q) >= 3:
            hi = min(len(self.lines) - 1, lo + self.granth.count(self.granth.sid_at(g_first)) + 8)
            line, sc, _ = self._search_near(q, lo, hi)
        self.pos = line if line is not None and sc >= self.min_track else lo
        self.settled()
        self.keep_up()
        return True

    # ---- following
    def update(self, transcript: str) -> dict:
        if is_simran(transcript):
            return self._event("hold", "simran")
        q = words_of(transcript)
        if len(q) < 3:
            return self._event("hold", "quiet")
        self.checks += 1
        if self.pos is None:                          # first placing: anywhere in the window
            line, sc, runner = self._search(q, 0, len(self.lines) - 1)
            self.last = (None if line is None else self.g0 + line, sc, runner)
            if line is not None and sc >= self.min_cold and runner <= 0.75 * sc:
                self.pos = line
                self.settled()
                self.hits += 1
                self.keep_up()
                return self._event("locked", f"score {sc:.0f}")
            return self._event("searching", f"score {sc:.0f}")

        wide = self.misses >= self.lost_after
        ahead = min(MAX_AHEAD, self.ahead + WIDEN * self.misses)
        back = self.back
        if wide:
            back = LOST_BACK
        if self.doubt >= DOUBT_LOST:                   # unsure for a while: the screen may be ahead
            back = min(MAX_BACK, max(back, LOST_BACK + BACK_GROW * (self.doubt - DOUBT_LOST)))
        self.keep_up(ahead, back)
        lo = max(self.pos - back, 0)
        hi = min(self.pos + ahead, len(self.lines) - 1)
        line, sc, runner = self._search_near(q, lo, hi)
        self.last = (None if line is None else self.g0 + line, sc, runner)
        strong = line is not None and sc >= self.min_cold and runner <= 0.75 * sc
        ok = line is not None and sc >= self.min_track
        d = 0 if line is None else line - self.pos
        if ok and (wide or d > FAR or d < -self.back) and not strong:
            ok = False                                 # after a gap, or a long way off: must stand out
        if ok and (d > FAR or d < -max(self.back, NEAR)) and (self.doubt or wide or d > FAR):
            # a long way from the last place (or back after being unsure): only when
            # heard twice in a row at the same place, so one false match never moves it
            g = self.g0 + line
            p = self.pending
            if not (p and self.checks - p[1] <= 2 and -2 <= g - p[0] <= 8):
                self.pending = (g, self.checks)
                ok = False
        if ok:
            self.pos, self.misses, self.pending = max(line, lo), 0, None
            self.doubt = 0 if strong else self.doubt + 1
            self.main_g = self.g0 + self.pos
            self.hits += 1
            self.keep_up()
            return self._event("tracking", f"score {sc:.0f}")
        self.misses += 1
        self.doubt += 1
        return self._event("searching" if self.misses >= self.lost_after else "hold", "no match")

    def _search_near(self, q, lo_line, hi_line):
        """Like _search, but when several places fit almost equally well (lines that
        all open the same way, as in the Brahm Giani ashtpadi), take the nearest
        one: the reader is far more likely to be just ahead than ten lines on."""
        lo, hi = self._word_range(lo_line, hi_line)
        al = smith_waterman(q, self.words[lo:hi])
        if not al:
            return None, 0.0, 0.0
        scores = np.array([a.score for a in al])
        best = float(scores.max())
        j = int(np.argmax(scores >= best - TIE))          # earliest end that is (nearly) the best
        line = self.word_line[lo + j]
        far = [a.score for a in al if abs(self.word_line[lo + a.end_word] - line) > 15]
        return line, best, float(max(far) if far else 0.0)

    def quick(self, transcript: str) -> int | None:
        """A short check (the last few seconds): has the reader already started the
        next line? Only the very last words count, and they must fit the next line
        clearly better than the current one (many lines open with the same words)."""
        if self.pos is None or is_simran(transcript):
            return None
        q = words_of(transcript)[-QUICK_WORDS:]
        if len(q) < 3:
            return None
        self.keep_up(2)
        nxt = self.pos + 1
        if nxt >= len(self.lines) or (self.main_g is not None and self.g0 + nxt > self.main_g + QUICK_AHEAD):
            return None
        s_next = self._line_score(q, nxt)
        if s_next >= QUICK_MIN and s_next >= self._line_score(q, self.pos) + QUICK_MARGIN:
            return nxt
        return None

    def _line_score(self, q, line: int) -> float:
        lo, hi = self._word_range(line, line)
        al = smith_waterman(q, self.words[lo:hi])
        return max((a.score for a in al), default=0.0)

    def step(self, delta: int) -> dict:
        if self.pos is None:
            self.pos = 0
        g = int(np.clip(self.g0 + self.pos + delta, 0, self.granth.total - 1))
        if not (self.g0 <= g < self.g0 + len(self.lines)):
            self._recentre(g)
        self.pos = g - self.g0
        self.settled()
        self.keep_up()
        return self._event("manual", f"{delta:+d}")

    def where_now(self) -> str:
        """For the log: where the tracker is and how sure."""
        if self.pos is None:
            return "sehaj: not placed"
        L = self.lines[self.pos]
        g, sc, run = self.last
        heard = "-" if g is None else f"{g}"
        return (f"sehaj: line {self.g0 + self.pos} (shabad {L['sid']} line {L['li'] + 1}/{L['ln']}, Ang {L['ang']}) "
                f"best {heard} score {sc:.0f} runner {run:.0f} misses {self.misses} doubt {self.doubt}"
                f"{' pending ' + str(self.pending[0]) if self.pending else ''}")
