"""Detect Waheguru simran from an ASR transcript.

The kirtan ASR model renders simran as streams of one/two-letter fragments
("ਮ ਵ ਵ ਮ", "ਮਨ ਮਨ ਮਨ") or, when clear, as ਵਾਹਿਗੁਰੂ - often clipped
("ਵਾਹਿਗੁਰ", "ਵਹਿਗੁਰਹਿ"), especially when a whole sangat sings it.
Gurbani - even badly transcribed - comes out as longer, varied words.

A short window that is mostly Waheguru (three or more, with ਜੀ counted in)
is simran too: otherwise it matched the Bhatt savaiya line "ਵਾਹਿਗੁਰੂ ਵਾਹਿਗੁਰੂ
ਵਾਹਿਗੁਰੂ ਵਾਹਿ ਜੀਉ" (Ang 1402) and put it on the screen during simran. When that
savaiya really is sung, its other lines identify it.

Tested on one Rensbhai programme: 7/7 simran windows caught, 0/97 Gurbani
windows flagged. Thresholds need checking on more jathas and styles.
"""
import re

WAHEGURU = re.compile(r"^ਵਾ?ਹ[ਿੇ]?ਗੁਰ")      # ਵਾਹਿਗੁਰੂ and clipped forms: ਵਾਹਿਗੁਰ, ਵਹਿਗੁਰ..., ਵਾਹੇਗੁਰੂ
JI = {"ਜੀ", "ਜੀਉ", "ਜੀਓ"}


def is_simran(transcript: str, min_tokens: int = 6,
              short_frac: float = 0.7, max_distinct: float = 0.4) -> bool:
    toks = transcript.split()
    if not toks:
        return False
    wg = sum(bool(WAHEGURU.match(t)) for t in toks)
    if wg >= 3 and (wg + sum(t in JI for t in toks)) / len(toks) >= 0.6:
        return True
    if len(toks) < min_tokens:
        return False
    if wg / len(toks) >= 0.4:
        return True
    short = sum(len(t) <= 2 for t in toks) / len(toks)
    distinct = len(set(toks)) / len(toks)
    return short >= short_frac and distinct <= max_distinct
