"""
BaniTracker - follow a continuous recitation (Sukhmani Sahib, Japji Sahib,
Asa di Vaar, Rehras, Sehaj Paath...) line by line.

A bani is treated as ONE long ordered track instead of many short shabads,
so the tracker never has to re-identify at a shabad boundary.

Each update aligns the words just heard against the bani text using a
Smith-Waterman local alignment with fuzzy word similarity. Consecutive
words must line up in order, which stops repeated openings (e.g. the
forty "ਸਾਧ ਕੈ ਸੰਗਿ" lines of Ashtpadi 7) from causing jumps.

  - locked:   search a window just behind to well ahead of the current line
  - lost:     after several poor windows, search the whole bani to re-sync
  - holding:  simran or too few words -> keep the current line on screen
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from rapidfuzz import fuzz
from rapidfuzz.process import cdist

from .phrase_matcher import words_of
from .simran import is_simran

MATCH_HI, MATCH_LO, MISMATCH, GAP = 2.0, 0.5, -1.0, -1.0


@dataclass
class Align:
    score: float
    end_word: int      # index into the reference word list
    start_word: int


def sw_matrix(q: list[str], r: list[str]):
    """Smith-Waterman score matrix H, alignment starts, and the word-match
    scores S (len(q) x len(r))."""
    sim = cdist(q, r, scorer=fuzz.ratio, workers=1)          # len(q) x len(r)
    S = np.where(sim >= 80, MATCH_HI, np.where(sim >= 60, MATCH_LO, MISMATCH))
    n, m = S.shape
    H = np.zeros((n + 1, m + 1), dtype=np.float32)
    start = np.zeros((n + 1, m + 1), dtype=np.int32)
    for i in range(1, n + 1):
        prev, cur = H[i - 1], H[i]
        diag = prev[:-1] + S[i - 1]                      # H[i-1][j-1] + s
        up = prev[1:] + GAP                              # H[i-1][j]  + gap
        best = np.maximum(np.maximum(diag, up), 0.0)
        src_start = np.where(diag >= up, start[i - 1][:-1], start[i - 1][1:])
        src_start = np.where(best == 0.0, np.arange(m), src_start)
        # left moves (skipped reference words) need a sequential pass
        row, st = best, src_start
        for j in range(1, m):
            left = row[j - 1] + GAP
            if left > row[j]:
                row[j], st[j] = left, st[j - 1]
        cur[1:] = row
        start[i][1:] = st
    return H, start, S


def smith_waterman(q: list[str], r: list[str]) -> list[Align]:
    """Return the best local alignment ending at each reference word."""
    if not q or not r:
        return []
    H, start, _ = sw_matrix(q, r)
    m = H.shape[1] - 1
    ends = H.max(axis=0)[1:]                             # best score ending at each ref word
    rows = H.argmax(axis=0)[1:]
    return [Align(float(ends[j]), j, int(start[rows[j]][j + 1])) for j in range(m)]


class BaniTracker:
    def __init__(self, bani: dict, back: int = 2, ahead: int = 30,
                 min_track: float = 7.0, min_cold: float = 12.0,
                 lost_after: int = 3):
        self.bani = bani
        self.lines = bani["lines"]
        self.words: list[str] = []
        self.word_line: list[int] = []
        self.line_first_word: list[int] = []
        for li, ln in enumerate(self.lines):
            self.line_first_word.append(len(self.words))
            for w in words_of(ln["g"]):
                self.words.append(w)
                self.word_line.append(li)
        self.back, self.ahead = back, ahead
        self.min_track, self.min_cold, self.lost_after = min_track, min_cold, lost_after
        self.pos: int | None = None
        self.misses = 0

    # ---- helpers
    def _word_range(self, lo_line: int, hi_line: int) -> tuple[int, int]:
        lo = self.line_first_word[max(lo_line, 0)]
        hi = (self.line_first_word[hi_line + 1] if hi_line + 1 < len(self.lines)
              else len(self.words))
        return lo, hi

    def _search(self, q, lo_line, hi_line):
        lo, hi = self._word_range(lo_line, hi_line)
        al = smith_waterman(q, self.words[lo:hi])
        if not al:
            return None, 0.0, 0.0
        scores = np.array([a.score for a in al])
        j = int(scores.argmax())                          # earliest best end
        best_line = self.word_line[lo + j]
        # runner-up at least 15 lines away (uniqueness for cold search)
        far = [a.score for a in al
               if abs(self.word_line[lo + a.end_word] - best_line) > 15]
        return best_line, float(scores[j]), float(max(far) if far else 0.0)

    # ---- main entry
    def update(self, transcript: str) -> dict:
        if is_simran(transcript):
            return self._event("hold", "simran")
        q = words_of(transcript)
        if len(q) < 3:
            return self._event("hold", "quiet")

        if self.pos is None:                             # cold / lost: whole bani
            line, sc, runner = self._search(q, 0, len(self.lines) - 1)
            if line is not None and sc >= self.min_cold and runner <= 0.75 * sc:
                self.pos, self.misses = line, 0
                return self._event("locked", f"score {sc:.0f}")
            return self._event("searching", f"score {sc:.0f}")

        lo = max(self.pos - self.back, 0)
        hi = min(self.pos + self.ahead, len(self.lines) - 1)
        line, sc, _ = self._search(q, lo, hi)
        if line is not None and sc >= self.min_track:
            self.pos, self.misses = max(line, lo), 0
            return self._event("tracking", f"score {sc:.0f}")
        self.misses += 1
        if self.misses >= self.lost_after:
            self.pos = None
            return self._event("lost", "re-syncing")
        return self._event("hold", "no match")

    def step(self, delta: int) -> dict:
        """Manual next/previous line from the sewadar."""
        if self.pos is None:
            self.pos = 0
        self.pos = int(np.clip(self.pos + delta, 0, len(self.lines) - 1))
        self.misses = 0
        return self._event("manual", f"{delta:+d}")

    def _event(self, state: str, why: str) -> dict:
        ln = self.lines[self.pos] if self.pos is not None else None
        nxt = self.lines[self.pos + 1] if self.pos is not None and self.pos + 1 < len(self.lines) else None
        return {"state": state, "why": why, "pos": self.pos, "total": len(self.lines),
                "line": ln, "next": nxt}
