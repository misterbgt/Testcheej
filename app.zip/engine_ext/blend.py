"""Blend the engine's fuzzy line matcher with the phrase matcher."""
def blend_rank(base_cands, phrase_ranked, lam=0.5, k=10):
    base = {c.shabad_id: c.score for c in base_cands}
    phr = dict(phrase_ranked)
    pool = set(base) | set(phr)
    s = {sid: phr.get(sid, 0.0) + lam * base.get(sid, 0.0) for sid in pool}
    return sorted(s.items(), key=lambda x: -x[1])[:k]


def gated_rank(base_cands, phrase_ranked, min_top=35.0, min_lead=10.0, fallback_lam=2.0, k=10):
    """Trust the phrase matcher when it is confident (clear words heard);
    otherwise fall back to a blend that leans on the fuzzy line matcher."""
    if phrase_ranked:
        top = phrase_ranked[0][1]
        lead = top - (phrase_ranked[1][1] if len(phrase_ranked) > 1 else 0.0)
        if top >= min_top and lead >= min_lead:
            return phrase_ranked[:k]
    return blend_rank(base_cands, phrase_ranked, fallback_lam, k)
