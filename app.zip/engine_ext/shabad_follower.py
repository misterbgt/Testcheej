"""
ShabadFollower - follow the lines of ONE shabad during kirtan.

Ragis rarely sing a shabad straight through. The usual pattern is:
rahao (asthai) first, each tuk of a stanza repeated, back to the rahao
after every stanza, then on to the next stanza. So, besides the words
heard, two things decide which line is shown:

  what is being sung NOW   only alignments that end on one of the last few
                           words heard count first, so the display moves
                           to a new line as soon as it starts instead of
                           lagging on the one before
  words of a line          quick(): a short check every second or two -
                           when two or three words of another line of this
                           shabad are heard in order (its opening, or anywhere
                           in it) and no other line fits them as well, the
                           display moves at once
  what usually comes next  staying on the line, the next line, the rahao,
                           and (after the rahao) the stanza line where the
                           ragi left off get a small head start; the words
                           still decide, the head start only breaks close
                           calls between lines
"""
from __future__ import annotations

import re

import numpy as np
from rapidfuzz import fuzz

from .bani_tracker import sw_matrix
from .phrase_matcher import words_of
from .simran import is_simran

NUM_END = re.compile(r"॥\s*[੦-੯]+\s*॥\s*$")
HEADER_WORDS = ("ਮਹਲਾ", "ਮਃ", "ਮਹਲੁ", "ਸਲੋਕੁ", "ਸਲੋਕ", "ਪਉੜੀ", "ਛੰਤ", "ਡਖਣਾ")

# head starts, in alignment points (one clearly heard word = 2 points)
STAY, NEXT, RAHAO, RAHAO_AFTER_STANZA, RESUME = 1.0, 2.0, 1.0, 2.5, 2.5
TAIL_WORDS, MIN_TAIL = 3, 4.0
# quick check: last Q_TAIL words heard; opening run needs Q_OPEN_PTS (2 words, one clear);
# mid-line run needs Q_MID_WORDS words and Q_MID_PTS; must end within the last Q_RECENT words;
# a different line within Q_MARGIN points over the same words means wait
Q_TAIL, Q_OPEN_PTS, Q_MID_WORDS, Q_MID_PTS, Q_RECENT, Q_MARGIN, Q_SUBS = 6, 3.5, 2, 4.0, 2, 2.0, 1
SKELETON = {c: None for c in range(0x0A3E, 0x0A4E)} | {0x0A70: None, 0x0A71: None, 0x0A01: None, 0x0A02: None, 0x0A3C: None}


def structure(lines: list[dict]) -> tuple[set, set, set]:
    """(header lines, rahao lines, stanza-end lines) of a shabad."""
    g = [ln.get("g", "") for ln in lines]
    header = set()
    for i, t in enumerate(g):
        short = len(words_of(t)) <= 3
        if i < 3 and not NUM_END.search(t) and (t.startswith("ੴ") or short
                                                or any(w in t for w in HEADER_WORDS) and len(t.split()) <= 6):
            header.add(i)
        else:
            break
    if len(header) == len(g):
        header = set()
    rahao = set()
    for i, t in enumerate(g):
        if "ਰਹਾਉ" in t:
            rahao.add(i)
            j = i - 1                         # the rahao often spans two tuks
            while j >= 0 and j not in header and not NUM_END.search(g[j]) and "ਰਹਾਉ" not in g[j]:
                rahao.add(j)
                j -= 1
    ends = {i for i, t in enumerate(g) if NUM_END.search(t) and i not in rahao}
    return header, rahao, ends


class ShabadFollower:
    def __init__(self, track: dict, min_track: float = 6.0):
        self.bani = track
        self.lines = track["lines"]
        self.words: list[str] = []
        self.word_line: list[int] = []
        for li, ln in enumerate(self.lines):
            for w in words_of(ln["g"]):
                self.words.append(w)
                self.word_line.append(li)
        self.word_line_arr = np.array(self.word_line, dtype=np.int32)
        self.line_words = [words_of(ln["g"]) for ln in self.lines]
        self.header, self.rahao, self.stanza_end = structure(self.lines)
        body = [i for i in range(len(self.lines)) if i not in self.header]
        self.first = body[0] if body else 0
        self.min_track = min_track
        self.pos: int | None = None
        self.high: int | None = None          # furthest stanza line sung so far
        self.misses = 0
        self.strength = 0.0                   # in-order match of the last words heard, on the chosen line

    # ---------------------------------------------------------------- order
    def _next_body(self, i: int, skip_rahao: bool = False) -> int | None:
        for j in range(i + 1, len(self.lines)):
            if j in self.header or (skip_rahao and j in self.rahao):
                continue
            return j
        return None

    def resume_line(self) -> int | None:
        """After the rahao: the stanza line where the ragi left off."""
        if self.high is None:
            return self._next_body(-1, skip_rahao=True)
        return self._next_body(self.high, skip_rahao=True)

    def head_start(self) -> dict[int, float]:
        p = self.pos
        if p is None:
            return {}
        b: dict[int, float] = {}

        def give(i, v):
            if i is not None and 0 <= i < len(self.lines):
                b[i] = max(b.get(i, 0.0), v)

        give(p, STAY)
        give(self._next_body(p), NEXT)
        after = p in self.stanza_end
        for r in self.rahao:
            give(r, RAHAO_AFTER_STANZA if after else RAHAO)
        if p in self.rahao:
            give(self.resume_line(), RESUME)
        return b

    def expected_next(self) -> int | None:
        """The line most likely to be sung after the current one."""
        p = self.pos
        if p is None:
            return None
        if p in self.rahao:
            later = [r for r in self.rahao if r > p]
            return min(later) if later else self.resume_line()
        if p in self.stanza_end and self.rahao:
            return min(self.rahao)
        return self._next_body(p)

    # ---------------------------------------------------------------- matching
    def _line_scores(self, q: list[str]) -> tuple[np.ndarray, np.ndarray]:
        """Per line: best alignment ending there (full), and best alignment
        ending there on a matched word among the last few heard (tail)."""
        n_lines = len(self.lines)
        full = np.zeros(n_lines, dtype=np.float32)
        tail = np.zeros(n_lines, dtype=np.float32)
        if not self.words:
            return full, tail
        H, _, S = sw_matrix(q, self.words)
        end_full = H[1:, 1:].max(axis=0)
        lo = max(0, len(q) - TAIL_WORDS)
        m = H[lo:-1, :-1] + S[lo:]                     # alignments that END on a matched word
        m = np.where(S[lo:] > 0, m, 0.0)
        end_tail = m.max(axis=0)
        np.maximum.at(full, self.word_line_arr, end_full)
        np.maximum.at(tail, self.word_line_arr, end_tail)
        for h in self.header:                         # the raag heading is not sung
            full[h] = tail[h] = 0.0
        return full, tail

    # ---------------------------------------------------------------- first words
    @staticmethod
    def _sim(a: str, b: str) -> float:
        """Word match for opening words. Sung words often come out of the
        speech model with the wrong vowel signs, so the consonants alone
        (ਚਿਤਿ / ਚੇਤੁ -> ਚਤ) count too."""
        if a == b:
            return 2.0
        sa, sb = a.translate(SKELETON), b.translate(SKELETON)
        if min(len(a), len(b)) <= 2:
            return 1.0 if sa and sa == sb else 0.0
        r = fuzz.ratio(a, b)
        if r >= 80:
            return 2.0
        if len(sa) >= 2 and sa == sb:
            return 1.5
        if r >= 70 or (len(sa) >= 3 and fuzz.ratio(sa, sb) >= 80):
            return 1.0
        return 0.0

    def _runs(self, tail: list[str]) -> dict[int, tuple]:
        """Per line: the freshest run of heard words that matches the line's
        words in the same order, anywhere in the line - not only its opening,
        so a dropped or misheard first word no longer hides the line.
        A run is consecutive on both sides; inside a run of three or more one
        word may be misheard. A run from the line's first word needs two words
        (Q_OPEN_PTS); from the middle of a line, Q_MID_WORDS words and
        Q_MID_PTS points. Returns {line: (end in tail, points, start in tail)},
        keeping per line the run that ends latest, then the strongest."""
        out: dict[int, tuple] = {}
        n = len(tail)
        for li, lw in enumerate(self.line_words):
            if li in self.header or len(lw) < 2:
                continue
            m = len(lw)
            S = [[self._sim(tail[x], lw[y]) for y in range(m)] for x in range(n)]
            best = None
            for d in range(-(n - 1), m):                       # one diagonal: line word = heard word + d
                cells = [(x, x + d) for x in range(max(0, -d), n) if 0 <= x + d < m]
                for a in range(len(cells)):
                    if S[cells[a][0]][cells[a][1]] == 0.0:
                        continue                               # a run starts on a heard word
                    pts, hits, subs = 0.0, 0, 0
                    for b in range(a, len(cells)):
                        v = S[cells[b][0]][cells[b][1]]
                        if v == 0.0:
                            subs += 1
                            if subs > Q_SUBS:
                                break
                            continue
                        pts += v
                        hits += 1
                        if hits < 2 or (subs and hits < 3):
                            continue
                        if cells[a][1] == 0:
                            ok = pts >= Q_OPEN_PTS
                        else:
                            ok = hits >= Q_MID_WORDS and pts >= Q_MID_PTS
                        if ok:
                            cand = (cells[b][0], pts, cells[a][0])
                            if best is None or cand[:2] > best[:2]:
                                best = cand
            if best:
                out[li] = best
        return out

    def quick(self, transcript: str) -> int | None:
        """A run of words from another line of this shabad was just heard,
        and no other line fits those words as well: that line."""
        if self.pos is None:
            return None
        tail = words_of(transcript)[-Q_TAIL:]
        if len(tail) < 2:
            return None
        runs = self._runs(tail)
        last = len(tail) - 1
        fresh = {i: r for i, r in runs.items() if r[0] >= last - (Q_RECENT - 1)}   # what is sung NOW
        if not fresh:
            return None
        ranked = sorted(fresh.items(), key=lambda kv: (kv[1][0], kv[1][1]), reverse=True)
        line, r = ranked[0]
        if line == self.pos:
            return None
        cur = runs.get(self.pos)
        if cur is not None and cur[0] >= r[0]:
            return None              # the line on screen matches the newest words just as well
        text = self.lines[line]["g"]
        for j, rr in ranked[1:]:
            if self.lines[j]["g"] == text:
                continue             # the same words again elsewhere in the shabad
            same_words = rr[2] <= r[0] and r[2] <= rr[0]
            if same_words and rr[1] >= r[1] - Q_MARGIN:
                return None          # another line fits these words too: wait for a word that tells them apart
        return line

    def update(self, transcript: str) -> dict:
        if is_simran(transcript):
            return self._event("hold", "simran")
        q = words_of(transcript)
        if len(q) < 3:
            return self._event("hold", "quiet")
        full, tail = self._line_scores(q)
        bonus = np.zeros(len(self.lines), dtype=np.float32)
        for i, v in self.head_start().items():
            bonus[i] = v
        choice, why = None, ""
        if tail.max() >= MIN_TAIL:
            ok = tail >= MIN_TAIL
            choice = int(np.argmax(np.where(ok, tail + bonus, -1.0)))
            why = f"now {tail[choice]:.0f}"
        elif full.max() >= self.min_track:
            ok = full >= self.min_track
            choice = int(np.argmax(np.where(ok, full + bonus, -1.0)))
            why = f"window {full[choice]:.0f}"
        if choice is None:
            self.misses += 1
            self.strength = 0.0
            return self._event("hold", "no match")
        self.strength = float(tail[choice])
        cold = self.pos is None
        self._move(choice)
        self.misses = 0
        return self._event("locked" if cold else "tracking", why)

    def _move(self, i: int):
        self.pos = i
        if i not in self.rahao and i not in self.header:
            self.high = i if self.high is None else max(self.high, i)

    def place(self, i: int):
        """Sewadar moved the line: take it as where the ragi is."""
        self.pos = max(0, min(int(i), len(self.lines) - 1))
        if self.pos not in self.rahao and self.pos not in self.header:
            self.high = self.pos
        self.misses = 0

    def step(self, delta: int) -> dict:
        self.place((self.pos if self.pos is not None else self.first - 1 if delta > 0 else 0) + delta)
        return self._event("manual", f"{delta:+d}")

    def _event(self, state: str, why: str) -> dict:
        ln = self.lines[self.pos] if self.pos is not None else None
        return {"state": state, "why": why, "pos": self.pos, "total": len(self.lines), "line": ln}
