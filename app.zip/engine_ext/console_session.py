"""
ConsoleSession - the decision logic behind the sewadar console.

Feed it one ASR transcript at a time (a ~10 s window every few seconds) and
sewadar commands; it returns messages for the GUI.

Modes
  kirtan  identify the shabad (gated matcher), auto-lock when the evidence
          agrees, then follow lines within it (rahao returns allowed).
          Unlocks after sustained non-matching audio and finds the next one.
  paath   follow a whole bani (Sukhmani Sahib, Japji Sahib, Asa di Vaar ...)
          as one continuous track. With bani_id=None it identifies the
          piece first, then switches to the bani it belongs to.
          With sehaj=True (Akhand Paath / Sehaj Paath): once the place is
          found, follow Sri Guru Granth Sahib Ji in order, into the next
          shabad and the next Ang, without identifying each shabad again
          (engine_ext/sehaj.py).

Asa Ki Vaar (kirtan)  once two parts of the Vaar are heard in the order they are sung
        (a chhant, then its saloks), or the sewadar says so, the Vaar is followed as
        one list in that order (engine_ext/akv.py). A shabad sung after a pauri is
        shown as usual, and the Vaar carries on at the next chhant. After the 24th
        pauri the Vaar is over; Anand Sahib after it is followed as its 6 pauris and
        salok (bani 6).

Return  the last few shabads are remembered with the line the ragi reached.
        If the ragi goes back to one of them (after a parmaan, or a shabad on
        a similar theme), one clear window is enough to switch back.

Holds   simran, near-silence, or the sewadar pressing Hold keep the current
        line on screen and never count as evidence for a different shabad.

Messages
  {"type": "track", ...}   the full line list whenever the track changes
  {"type": "state", ...}   status, position, candidates, heard text
"""
from __future__ import annotations

import json
from pathlib import Path

from .akv import AkvFollower, AKV_BANI
from .bani_tracker import BaniTracker
from .sehaj import Granth, SehajTracker
from .blend import gated_rank
from .shabad_follower import ShabadFollower
from .simran import is_simran
from .learnt import Learnt, Teacher
from .phrase_matcher import words_of

# While a shabad is on screen, a window with fewer than this many clear words
# (three letters or more) neither keeps nor leaves it: in sangat singing about a
# third of windows are fragments that match random shabads.
MIN_CLEAR_TO_LEAVE = 3


def long_parts(corpus, base) -> dict[int, int]:
    """For the fuzzy line matcher: flat line index -> part of its composition,
    for compositions long enough to be split (same parts as PhraseMatcher).
    Walks the corpus exactly as ShabadMatcher built its flat index."""
    from .phrase_matcher import parts_of, SPLIT_OVER
    out, idx = {}, 0
    for sid, data in corpus.shabads.items():
        verses = data.get("verses", [])
        part_at = []
        if len(verses) > SPLIT_OVER:
            texts = [(v.get("gurmukhi") or {}).get("unicode") or v.get("unicode", "") for v in verses]
            for k, part in enumerate(parts_of(texts)):
                part_at += [k] * len(part)
        for i, verse in enumerate(verses):
            normalized = base.normalize_text(base.get_verse_text(verse))
            if len(normalized) >= 5 and not base._is_header_line(normalized):
                if part_at:
                    out[idx] = part_at[i]
                idx += 1
    assert idx == len(base._flat_lines), "flat index walk out of step"
    return out


NOISE_FILTER = False                # tried: no gain on the five recordings (the hour was 2 min worse); kept for later work
_SIGNS = set("ਾਿੀੁੂੇੈੋੌੰਂੱ਼੍ੑਁਃ")


def is_noise(transcript: str) -> bool:
    """Tabla, harmonium or other music heard as syllables: hardly a word of
    three letters or more, and the same syllable again and again in a row
    (ਵਚ ਵਚ ਵਚ ਬਾ ਬਾ ਬਾ ਕਚ ਕਚ). A sung line repeats as a whole phrase
    (ਜੇ ਲੋਚੈ ਸਭੁ ਕੋਇ ਜੇ ਲੋਚੈ ...), not word by word, so it is not caught."""
    toks = transcript.split()
    if not NOISE_FILTER or len(toks) < 6:
        return False
    longer = sum(sum(ch not in _SIGNS for ch in w) >= 3 for w in toks)
    again = sum(a == b for a, b in zip(toks, toks[1:]))
    return longer <= 0.1 * len(toks) and again >= 0.25 * (len(toks) - 1)


def clear_words(transcript: str) -> int:
    if is_noise(transcript):
        return 0
    return sum(len(w) >= 3 for w in transcript.split())

RECENT_KEEP = 3            # previous shabads kept close at hand for a quick return
# Evidence over the last EVIDENCE_S: points for places 1-5 in each check. With garbled
# singing a different shabad tops almost every check, but the real one keeps coming back.
EVIDENCE_S, EVIDENCE_PTS = 90.0, (5, 4, 3, 2, 1)
EVIDENCE_MIN_CHECKS, EVIDENCE_MIN_PTS, EVIDENCE_LEAD = 5, 22, 12
BLANK_AFTER_S = 90.0       # nothing heard has matched the shabad on screen for this long: take it down ...
ESTABLISHED = 6            # ... unless it had matched this many checks since it went up (then it was real:
                           # katha or a long alaap about it keeps it up)
# Acoustic matching (engine_ext/acoustic.py): while no shabad has taken hold, each
# check's best shabads by sound (places 1-5) earn points over the last AC_S; one
# that leads clearly is put up, even when the written words match nothing.
ACOUSTIC = True
AC_S, AC_PTS = 90.0, (5, 4, 3, 2, 1)
AC_MIN_CHECKS, AC_LEAD = 4, 16
AC_LEAD_SWITCH = 24        # to replace a shabad that had taken hold (and has since stopped matching)
STRONG_INSIDE = 5.0        # the last words heard line up, in order, in the current shabad (2-3 words)
# Akhand / Sehaj Paath: checks without a match before options are offered; a place
# confirmed fewer than SEHAJ_ESTABLISHED times is given up after SEHAJ_RETRY misses.
SEHAJ_OFFER, SEHAJ_ESTABLISHED, SEHAJ_RETRY = 8, 4, 5
# The reader keeps reading when a check fails to match (unclear words), so the screen
# keeps moving at the reader's pace, up to SEHAJ_PRED_MAX lines beyond the last
# confirmed line; it only waits when there are no words at all.
SEHAJ_PRED_MAX = 3
# Unsure for SEHAJ_REFIND checks in a row (no strong match - the reader stepped away from
# the microphone, or a false match put the screen in the wrong place): look across the
# whole Granth, as a fresh start would, and move there once the same place is heard
# again and again (as when identifying from the start).
SEHAJ_REFIND = 6
# ... sooner when the place was itself found again a moment ago (it may have followed
# some other reading the microphone picked up): the reader's place can come straight back
SEHAJ_REFIND_SOON, SEHAJ_SOON_S = 4, 180.0

# Asa Ki Vaar: two of its parts heard in sung order within AKV_SEEN_S start following the
# Vaar; a shabad sung after a pauri is put up once it is identified as surely as any
# shabad; the Vaar comes back when the next chhant is heard (AKV_RESUME points of words
# in order, or AKV_RESUME_SOFT in two checks running). Anand Sahib in kirtan (after the
# Vaar, or at any time) is followed as its 6 pauris and salok (bani ANAND_SIX).
AKV_RESUME_SOFT, AKV_RESUME_OTHERS = 4.5, True
# a chhant reached from a pauri on a few words, and a shabad with more of the words heard
# in order (at least AKV_RIVAL_MIN points) in AKV_RIVAL_OF of the last AKV_RIVAL_N checks
AKV_RIVAL_MIN, AKV_RIVAL_N, AKV_RIVAL_OF = 5.0, 5, 3
AKV_SEEN_S, AKV_RESUME, AKV_LOST_CHECKS, AKV_PAUSE_MAX_S, AKV_CATCH_UP = 900.0, 8.0, 8, 1800.0, 3
ANAND_SID, ANAND_SIX = 3375, 6
LENGTHS = ("short", "medium", "long", "extra long")

STATUS_TEXT = {
    "listening": "Listening",
    "finding": "Finding the shabad",
    "following": "Following",
    "held_simran": "Held during simran",
    "held_quiet": "Held, waiting for words",
    "held_user": "Auto changes paused",
    "lost": "Lost the place, searching",
    "searching_ahead": "Not sure of the line, looking ahead",
    "cleared": "Screen cleared: nothing heard matched for a while",
}


class Resources:
    """Everything that is loaded once and shared by all sessions."""

    def __init__(self, repo: Path, learnt_path: Path | None = None):
        from engine import ShabadCorpus, ShabadMatcher
        from .phrase_matcher import PhraseMatcher
        self.corpus = ShabadCorpus(repo / "data" / "sggs_corpus.json")
        self.corpus.load()
        extra = repo / "data" / "sggs_extra.json"     # shabads the corpus lacks (tools/build_sggs_order.py)
        if extra.exists():
            for sh in json.loads(extra.read_text(encoding="utf-8")):
                self.corpus._index_shabad(sh)
        other_meta = {}
        other = repo / "data" / "other_corpus.json"   # Vaaran and Kabit Savaiye Bhai Gurdas Ji, Ghazals Bhai Nand Lal Ji
        if other.exists():
            o = json.loads(other.read_text(encoding="utf-8"))
            for sh in o["shabads"]:
                self.corpus._index_shabad(sh)
            other_meta = o.get("meta", {})
        self.base = ShabadMatcher(self.corpus)
        self.phrase = PhraseMatcher(self.corpus)
        self.base._flat_part = long_parts(self.corpus, self.base)
        self.learnt = Learnt(learnt_path)
        self.acoustic = None                           # see enable_acoustic()
        self.phrase.set_learnt(self.learnt.feature_map())
        self.banis = {b["id"]: b for b in json.loads((repo / "data" / "banis.json").read_text(encoding="utf-8"))}
        meta = json.loads((repo / "data" / "shabad_meta.json").read_text(encoding="utf-8"))
        self.meta = {**meta["shabads"], **other_meta}
        self.sid_banis = meta["sid_banis"]
        self.granth = Granth(self.corpus, self.meta, self.phrase.first_line, repo / "data" / "sggs_angs.json",
                             repo / "data" / "sggs_order.json")
        self.akv_sids = {ln["sid"] for ln in self.banis[AKV_BANI]["lines"] if ln.get("sid")}
        # Anand Sahib's opening (pauris 1-5) and last pauri, as sung in kirtan. The corpus
        # keeps those two as shabads of their own (333375, 333376; pauris 6-39 are 3375).
        six = self.banis[ANAND_SIX]["lines"]
        self.anand_lines = {ln["g"] for ln in six if ln.get("sid") == ANAND_SID}
        self.anand_parts = {sid for sid, g in self.phrase.first_line.items() if g in self.anand_lines}
        opening = next((ln["g"] for ln in six if ln["g"] in self.anand_lines and ln.get("type") == "Pankti"), "")
        self.anand_open = next((sid for sid in self.anand_parts if self.phrase.first_line[sid] == opening), ANAND_SID)

    def variants(self, bani_id: int) -> list[int]:
        """The same bani in its other lengths (Rehras, Chaupai, Sohila, Aarti), shortest first."""
        fam = self.banis[bani_id].get("family")
        if not fam:
            return [bani_id]
        ids = [b["id"] for b in self.banis.values() if b.get("family") == fam]
        return sorted(ids, key=lambda i: LENGTHS.index(self.banis[i].get("length", "short")))

    def anand_track(self) -> dict:
        """Anand Sahib as sung after Asa Ki Vaar: pauris 1-5, the 40th, and the salok
        ਪਵਣੁ ਗੁਰੂ, followed as one shabad."""
        b = self.banis[ANAND_SIX]
        return {"id": "k6", "kind": "shabad", "sid": self.anand_open, "lines": b["lines"],
                "title": self.phrase.first_line.get(self.anand_open, b["name_gurmukhi"]), "subtitle": b["name"]}

    def enable_acoustic(self, tokenizer_path) -> None:
        """Build the acoustic index (a few seconds); until then acoustic matching is off."""
        from .acoustic import AcousticIndex
        self.acoustic = AcousticIndex(self.corpus, tokenizer_path)

    def shabad_track(self, sid: int) -> dict:
        m = self.meta.get(str(sid), {})
        lines = []
        for ln in self.corpus.get_lines(sid):
            g = (ln.get("gurmukhi") or {}).get("unicode") or ln.get("unicode", "")
            lines.append({"g": g, "tr": ln.get("transliteration_english", ""),
                          "en": ln.get("translation_english", ""),
                          "sid": sid, "ang": m.get("ang"), "ref": m.get("ref"), "type": ""})
        return {"id": f"s{sid}", "kind": "shabad", "sid": sid, "lines": lines,
                "title": self.phrase.first_line.get(sid, ""),
                "subtitle": _where(m)}

    def bani_track(self, bani_id: int) -> dict:
        b = self.banis[bani_id]
        return {"id": f"b{bani_id}", "kind": "bani", "bani_id": bani_id, "lines": b["lines"],
                "title": b["name_gurmukhi"], "subtitle": b["name"]}


def _where(m: dict) -> str:
    if not m:
        return ""
    if m.get("where"):                        # Vaaran, Kabit Savaiye, Ghazals
        return m["where"]
    return f"Ang {m.get('ang')}, {m.get('raag')}, {m.get('writer')}"


class ConsoleSession:
    def __init__(self, res: Resources, mode: str = "kirtan", bani_id: int | None = None, sehaj: bool = False):
        self.res = res
        self.sehaj = bool(sehaj)
        self.t = 0.0
        self.heard = ""
        self.held_by_user = False
        self.outbox: list[dict] = []
        self.predict_enabled = True
        self.recent: list[dict] = []
        self._followers: dict[int, ShabadFollower] = {}
        self.bani_length = "long"                   # which length of Rehras, Chaupai, Sohila, Aarti to follow
        self._akv_end_t = None
        self._set_mode(mode, bani_id)

    # ------------------------------------------------------------ commands
    def set_mode(self, mode: str, bani_id: int | None = None, sehaj: bool | None = None):
        if sehaj is not None:
            self.sehaj = bool(sehaj)
        self._set_mode(mode, bani_id)
        return self._emit()

    @property
    def in_sehaj(self) -> bool:
        return self.mode == "paath" and self.sehaj

    def _set_mode(self, mode: str, bani_id: int | None = None):
        """Switch mode without sending anything yet (the caller emits, so the
        new track reaches the screens together with the state)."""
        self.mode = mode
        self.bani_id = bani_id
        self.track = None
        self._conf, self._shown, self._floor, self._backed = [], None, None, False
        self.tracker = None
        self.status = "listening"
        self.candidates: list[dict] = []
        self.suggestion = None
        self.confidence = "none"
        self._streak = (None, 0, False)
        self.recent = []
        self.akv, self.akv_paused, self._akv_seen, self._akv_miss = None, False, [], 0
        if mode == "paath" and self.sehaj:
            self.bani_id = None                     # Akhand / Sehaj Paath follows the Granth, not a bani
        elif mode == "paath" and bani_id is not None:
            self._load_track(self.res.bani_track(bani_id))

    def reset(self):
        return self.set_mode(self.mode, self.bani_id)

    def hold(self, on: bool = True):
        self.held_by_user = on
        if on:
            self.status = "held_user"
        elif self.status == "held_user":
            self.status = "following" if self.tracker and self.tracker.pos is not None else "listening"
        return self._emit()

    def step(self, delta: int):
        if self.tracker:
            self.tracker.step(delta)
            self._sehaj_sync()
            self.confidence = "manual"
            self._conf, self._shown, self._floor, self._backed = [(self.t, self.tracker.pos)], self.tracker.pos, None, False
        return self._emit()

    def goto(self, pos: int):
        if self.tracker:
            if hasattr(self.tracker, "place"):
                self.tracker.place(pos)
            else:
                self.tracker.pos = max(0, min(int(pos), len(self.tracker.lines) - 1))
            self.tracker.misses = 0
            self._sehaj_sync()
            self.confidence = "manual"
            self._conf, self._shown, self._floor, self._backed = [(self.t, self.tracker.pos)], self.tracker.pos, None, False
        return self._emit()

    def confirm(self, sid: int):
        """Sewadar picks a candidate: lock onto it (or its bani in paath mode)."""
        self._lock_shabad(int(sid), transcript=self.heard)
        self.confidence = "manual"
        self._sure = True
        self._teacher().picked(int(sid), self.t)
        return self._emit()

    def back(self, sid: int | None = None):
        """Sewadar: go back to the previous shabad (or a given recent one)."""
        r = next((x for x in self.recent if sid is None or x["sid"] == int(sid)), None)
        if r:
            self._return_to(r, transcript="")
            self.confidence = "manual"
            self._sure = True
            self._teacher().picked(int(r["sid"]), self.t)
        return self._emit()

    def show(self, sid: int, pos: int | None = None, bani_id: int | None = None):
        """Sewadar picked a line from search or history: show it, then keep
        following from there."""
        if bani_id is not None and int(bani_id) == AKV_BANI and self.mode == "kirtan":
            self.akv_command("start")              # Asa Ki Vaar picked in kirtan (history): as it is sung
            if pos is not None and self.akv is not None and not self.akv_paused:
                self.akv.place(int(pos))
            return self._emit()
        if bani_id is not None:
            self.sehaj = False                      # a bani picked by hand: follow that bani
            self._set_mode("paath", int(bani_id))
            self.tracker.pos = max(0, min(int(pos or 0), len(self.tracker.lines) - 1))
            self._conf, self._shown = [(self.t, self.tracker.pos)], self.tracker.pos
            self.status, self.confidence = "following", "manual"
            return self._emit()
        self._lock_shabad(int(sid), transcript="")
        self.confidence, self._sure = "manual", True
        self._teacher().picked(int(sid), self.t)
        if pos is not None:
            if self.track["kind"] == "shabad":
                target = int(pos)
                if self.track.get("id") == "k6" and int(sid) in self.res.anand_parts:
                    own = self.res.shabad_track(int(sid))["lines"]      # Anand Sahib's six pauris: that line
                    g = own[int(pos)]["g"] if 0 <= int(pos) < len(own) else ""
                    target = next((i for i, l in enumerate(self.track["lines"]) if l["g"] == g), 0)
            else:                                   # paath: find the line inside the bani
                g = self.res.shabad_track(int(sid))["lines"][int(pos)]["g"]
                L = self.track["lines"]
                target = next((i for i, l in enumerate(L) if l.get("sid") == int(sid) and l["g"] == g),
                              next((i for i, l in enumerate(L) if l.get("sid") == int(sid)), 0))
            if isinstance(self.tracker, SehajTracker):
                self.tracker.place_sid(int(sid), int(pos))
                self._sehaj_sync()
                target = self.tracker.pos
            elif hasattr(self.tracker, "place"):
                self.tracker.place(target)
            else:
                self.tracker.pos = target
            self._conf, self._shown, self._floor, self._backed = [(self.t, target)], target, None, False
        return self._emit()

    def wants_quick(self) -> bool:
        """Short checks every second or two: in kirtan on a shabad, and in Akhand /
        Sehaj Paath once the place is found (readers can be fast)."""
        if self.mode == "kirtan" and self.akv is not None and not self.akv_paused:
            return not self.held_by_user and self.tracker is self.akv
        if self.mode == "kirtan":                   # exactly as before this mode existed
            return bool(self.track and self.track.get("kind") == "shabad" and not self.held_by_user)
        return (self.in_sehaj and not self.held_by_user and isinstance(self.tracker, SehajTracker)
                and self.tracker.pos is not None and self.status == "following")

    def quick_line(self, transcript: str, t: float) -> list[dict]:
        """Every second or two in kirtan: if the opening words of another line of
        the current shabad were just heard, move there at once. In Akhand / Sehaj
        Paath: if the reader has already reached one of the next lines, move on."""
        if self.in_sehaj:
            return self._sehaj_quick(transcript, t)
        if self.akv is not None and not self.akv_paused and self.tracker is self.akv:
            if self.held_by_user or is_simran(transcript):
                return []
            new = self.akv.quick(transcript)
            if new is None or new == self.akv.pos:
                return []
            self.akv.place(new)
            self.status, self.confidence, self.t, self._akv_miss = "following", "high", t, 0
            return self._emit()
        if (self.mode != "kirtan" or self.held_by_user or not isinstance(self.tracker, ShabadFollower)
                or is_simran(transcript)):
            return []
        new = self.tracker.quick(transcript)
        if new is None or new == self.tracker.pos:
            return []
        self.tracker._move(new)          # a line of this shabad was heard: we are still here
        self.status, self.confidence, self.t = "following", "high", t
        self._away, self._last_hit, self._streak, self.candidates = 0, t, (None, 0, False), []
        return self._emit()

    def accept_suggestion(self):
        if self.suggestion and self.suggestion.get("bani_id") == AKV_BANI and self.mode == "kirtan":
            return self.akv_command("start")
        if self.suggestion:
            bid = self.suggestion["bani_id"]
            pos_sid = self.track["sid"] if self.track and self.track["kind"] == "shabad" else None
            self.sehaj = False
            self._set_mode("paath", bid)
            if pos_sid is not None:
                first = next((i for i, l in enumerate(self.track["lines"]) if l["sid"] == pos_sid), 0)
                self.tracker.pos = first
            self.status = "following"
        return self._emit()

    # ------------------------------------------------------------ audio
    def process(self, transcript: str, t: float, recent: str | None = None, logprobs=None,
                sounds: list | None = None) -> list[dict]:
        """transcript: the context window (20 s in kirtan). recent: optional
        transcript of just the last ~10 s, used to place the current line.
        logprobs: the speech model's sound probabilities for the same window, for
        acoustic matching; or sounds: that matching already done (the app runs it
        off its event loop, see wants_acoustic)."""
        self.t, self.heard = t, (recent or transcript)
        self._recent, self._lp, self._sounds = recent, logprobs, sounds
        if self.held_by_user:
            return self._emit()
        self._teach(transcript, t)
        if is_noise(transcript):                 # music heard as syllables: changes nothing
            return self._emit()
        if is_simran(transcript):
            self.status = "held_simran" if self.tracker and self.tracker.pos is not None else "listening"
            return self._emit()

        if self.mode == "kirtan" and self.akv is not None:
            if not self.akv_paused:
                self._akv_follow(transcript)
                return self._emit()
            if self._akv_resume(transcript):
                return self._emit()

        if self.tracker is None:
            self.status = "finding"
            self._identify(transcript)
            self._acoustic(transcript)
            return self._emit()

        if self.mode == "kirtan" and self.track["kind"] == "shabad":
            if self.akv is None and self._akv_next_part(transcript):
                return self._emit()
            self._kirtan_follow(transcript)
            self._acoustic(transcript)
            return self._emit()

        if isinstance(self.tracker, SehajTracker):
            self._sehaj_follow(transcript, t)
            return self._emit()

        ev = self.tracker.update(transcript)
        st = ev["state"]
        self._lost_n = 0 if st in ("tracking", "locked") else getattr(self, "_lost_n", 0) + (st in ("searching", "lost"))
        if st in ("tracking", "locked"):
            self.status, self.confidence = "following", "high"
            self.candidates = []
            self._paath_confirm(t)
        elif st == "hold":
            self.status = "held_quiet"
            self.confidence = "medium"
        elif st == "searching":
            self.status, self.confidence = "lost", "low"
        elif st == "lost":
            if self.track["kind"] == "shabad" and self.mode == "kirtan":
                # the ragi has probably moved on: keep the old line visible, find the next one
                self.status, self.confidence = "finding", "low"
                self.tracker.pos = None
                self._identify(transcript)
            else:
                self.status, self.confidence = "lost", "low"
        if self.status == "lost" and getattr(self, "_lost_n", 0) >= 2 and self._other_length(transcript):
            return self._emit()
        if self.status == "lost" and getattr(self, "_lost_n", 0) >= 3 and len(transcript.split()) >= 3:
            bc = self.res.base.find_candidates(transcript, top_k=10)     # show options, don't switch
            self.candidates = [self._cand(sid, sc) for sid, sc in gated_rank(bc, self.res.phrase.rank(transcript, 10))[:3]]
        return self._emit()

    # ------------------------------------------------------------ Asa Ki Vaar (kirtan)
    def akv_command(self, action: str, n: int | None = None):
        """Sewadar: start following Asa Ki Vaar (from the part on screen, or the
        beginning), go on to the next part, carry on with the Vaar after a shabad sung
        between pauris, go to pauri n, or end it."""
        if action == "start":
            if self.mode != "kirtan":
                self.sehaj = False
                self._set_mode("kirtan")
            probe, line = self._akv_probe(), None
            if self.akv is not None and not self.akv_paused:
                return self._emit()
            if self.track and self.track.get("kind") == "shabad" and self.track.get("sid") in self.res.akv_sids:
                pos = self.tracker.pos if self.tracker and self.tracker.pos is not None else None
                line = probe.find(self.track["sid"], self.track["lines"][pos]["g"] if pos is not None else self.heard)
            if line is None and self.akv is not None:
                line = self.akv.resume_line()
            if line is None:
                line = probe.shakka_start(1)
            if self.akv is not None:
                self._remember_current()
            self._akv_start(line)
        elif self.akv is None:
            return self._emit()
        elif action == "next":
            if self.akv_paused:
                nxt = self.akv.resume_line()
                if nxt is not None:
                    self._remember_current()
                    self._akv_start(nxt)
            else:
                self.akv.next_part()
                self.status, self._akv_miss = "following", 0
        elif action == "resume" and self.akv_paused:
            nxt = self.akv.resume_line()
            if nxt is not None:
                self._remember_current()
                self._akv_start(nxt)
        elif action == "pauri" and n is not None and 1 <= int(n) <= 24:
            if self.akv_paused:
                self._remember_current()
            self._akv_start(self.akv.shakka_start(int(n)))
        elif action == "end":
            self._akv_finish()
            self.track, self.tracker, self.last_pos = None, None, None
            self.status, self.candidates = "listening", []
        self.confidence = "manual"
        return self._emit()

    def _akv_probe(self) -> AkvFollower:
        """An Asa Ki Vaar follower used only to look places up."""
        probe = getattr(self.res, "_akv_probe", None)
        if probe is None:
            probe = self.res._akv_probe = AkvFollower(self.res.bani_track(AKV_BANI))
        return probe

    def _akv_start(self, line: int, transcript: str = ""):
        """Follow the Vaar from line (bani 13)."""
        if self.akv is None:
            self.akv = AkvFollower(self.res.bani_track(AKV_BANI))
        f = self.akv
        self.akv_paused, self._akv_miss, self._akv_rivals = False, 0, []
        f.place(line)
        self.track, self.tracker, self.last_pos = f.track, f, None
        self._conf, self._shown, self._floor, self._backed = [], None, None, False
        self.outbox.append({"type": "track", "track": {k: v for k, v in f.track.items()}})
        if transcript:
            f.update(transcript)
        self.status, self.confidence, self.candidates = "following", "high", []
        self._streak, self._ev, self.suggestion = (None, 0, False), [], None
        self._away, self._last_hit, self._last_ok, self._hits = 0, self.t, self.t, 0
        self._locked_at, self._sure = self.t, False

    def _akv_finish(self):
        self.akv, self.akv_paused, self._akv_seen, self._akv_miss = None, False, [], 0
        self._akv_end_t = self.t

    def _akv_lock(self, sid: int, transcript: str) -> bool:
        """A shabad was identified (or picked) in kirtan: is it part of Asa Ki Vaar, and
        is the Vaar being sung? True when that is dealt with here."""
        f = self.akv
        if f is not None and not self.akv_paused:
            if sid in self.res.akv_sids:              # a part of the Vaar: go there
                line = f.find(sid, transcript)
                if line is not None:
                    f.place(line)
                    self.status, self._akv_miss = "following", 0
                return True
            if f.pauri_no() == 24 and f.in_pauri():  # the Vaar is over
                self._akv_finish()
                return False
            self.akv_paused, self._akv_pause_t = True, self.t     # a shabad between pauris
            return False
        if f is not None:                             # paused: back to the Vaar?
            if sid not in self.res.akv_sids:
                return False
            line, back = f.find(sid, transcript), f.resume_line()
            if line is not None and back is not None and f.part_at[line] >= f.part_at[back]:
                self._remember_current()
                self._akv_start(line, transcript)
            return True
        if sid not in self.res.akv_sids:
            return False
        probe = self._akv_probe()
        line = probe.find(sid, transcript)
        seen = [(t0, l0) for t0, l0 in self._akv_seen if self.t - t0 <= AKV_SEEN_S]
        go = line is not None and any(l0 < line and probe.part_at[l0] != probe.part_at[line]
                                      and 0 <= probe.pauri_no(line) - probe.pauri_no(l0) <= 1 for _, l0 in seen)
        if line is not None:
            seen.append((self.t, line))
        self._akv_seen = seen[-8:]
        if not go:
            return False
        self._akv_start(line, transcript)
        self.outbox.append({"type": "notice", "message":
                            "Asa Ki Vaar: following it in the order it is sung (each chhant, its saloks, its pauri)."})
        return True

    def _akv_next_part(self, transcript: str) -> bool:
        """A part of Asa Ki Vaar is on screen as a shabad: if the words heard are the
        opening of the part sung after it (a chhant, then its first salok), the Vaar
        is being sung - follow it from there."""
        sid = self.track.get("sid")
        if sid not in self.res.akv_sids or self.tracker is None:
            return False
        probe = self._akv_probe()
        pos = self.tracker.pos if self.tracker.pos is not None else getattr(self.tracker, "first", 0)
        line = probe.find(sid, self.track["lines"][pos]["g"])
        if line is None:
            return False
        k = int(probe.part_at[line]) + 1
        if k >= len(probe.parts):
            return False
        nxt = probe.parts[k]
        hi = min(nxt.end, nxt.first + 2)
        texts = [x for x in (getattr(self, "_recent", None), transcript) if x]
        best = max((probe.match_score(x, nxt.first, hi) for x in texts), default=0.0)
        if best < AKV_RESUME or best <= self._aligns(sid, transcript) + 2:
            return False
        self._akv_seen = []
        self._akv_start(nxt.first, texts[0])
        self.outbox.append({"type": "notice", "message":
                            "Asa Ki Vaar: following it in the order it is sung (each chhant, its saloks, its pauri)."})
        return True

    def _akv_follow(self, transcript: str):
        f = self.akv
        ev = {"state": "none"}
        if getattr(self, "_recent", None):
            ev = f.update(self._recent)                 # freshest audio decides the line
        if ev["state"] != "tracking":
            ev = f.update(transcript)
        if ev["state"] == "tracking":
            self.status, self.confidence, self.candidates = "following", "high", []
            self._akv_miss, self._last_hit = 0, self.t
            f.part_hits += 1
            if f.unsure_chhant():                       # or a shabad sung after the pauri?
                if not self._akv_rival(transcript):
                    self._akv_identify(transcript, quiet=True)
            else:
                self._streak, self._akv_rivals = (None, 0, False), []
            return
        if len(transcript.split()) < 3 or clear_words(transcript) < MIN_CLEAR_TO_LEAVE:
            self.status = "held_quiet"
            return
        self._akv_miss += 1
        f.part_misses += 1
        self.status, self.confidence = "held_quiet", "medium"
        if self._akv_miss >= AKV_CATCH_UP and f.catch_up(transcript):
            self.status, self._akv_miss = "following", 0
            return
        # after a pauri a shabad may be sung (or the Vaar is over); in the middle of a
        # part, unmatched words are vichaar or a misheard line: keep the place. A chhant
        # only just reached from a pauri, and unsure since, may be that shabad.
        if f.unsure_chhant() and self._akv_rival(transcript):
            return
        if f.in_pauri() or f.unsure_chhant() or self._akv_miss >= AKV_LOST_CHECKS:
            self._akv_identify(transcript)

    def _akv_rival(self, transcript: str) -> bool:
        """The screen only just moved from a pauri into the next chhant, on a few words:
        does a shabad - sung after the pauri - explain the words better (more of them in
        order) than the chhant does, in AKV_RIVAL_OF of the last AKV_RIVAL_N checks? Then
        put it up (the Vaar waits, and carries on at this chhant)."""
        f = self.akv
        p = f.part()
        own = f.match_score(transcript, p.first, p.end)
        best, best_al = None, 0.0
        for sid, _ in [x for x in self.res.phrase.rank(transcript, 10) if x[0] not in self.res.akv_sids][:5]:
            al = self._aligns(sid, transcript)
            if al > best_al:
                best, best_al = sid, al
        ok = best is not None and best_al >= AKV_RIVAL_MIN and best_al > own
        self._akv_rivals = (getattr(self, "_akv_rivals", []) + [best if ok else None])[-AKV_RIVAL_N:]
        if not (ok and self._akv_rivals.count(best) >= AKV_RIVAL_OF):
            return False
        self._akv_rivals, self._streak = [], (None, 0, False)
        self._lock_shabad(best, transcript)
        return True

    def _akv_identify(self, transcript: str, quiet: bool = False):
        """What else is being sung? As sure as identifying any shabad (the same
        streak), then: a later part of the Vaar (the screen had fallen behind), or a
        shabad between pauris, or what comes after the Vaar. quiet: the Vaar matched
        (no candidates shown)."""
        f = self.akv
        bc = self.res.base.find_candidates(transcript, top_k=10)
        pr = self.res.phrase.rank(transcript, 10)
        ranked = gated_rank(bc, pr)
        if not quiet:
            self.candidates = [self._cand(sid, sc) for sid, sc in ranked[:3]]
        if not ranked:
            return
        top = ranked[0][0]
        confident = bool(pr) and pr[0][1] >= 35 and (pr[0][1] - (pr[1][1] if len(pr) > 1 else 0)) >= 10
        prev, n, had = self._streak
        n = n + 1 if top == prev else 1
        had = (had if top == prev else False) or (confident and pr[0][0] == top)
        self._streak = (top, n, had)
        # leaving the Vaar takes a little more than finding a shabad from nothing: sangat
        # singing of a pauri can come out as words of some other shabad for a few checks
        if top in self.res.akv_sids:
            if not ((n >= 2 and had) or n >= 3):
                return
        elif not (((n >= 3 and had) or n >= 4) and self._aligns(top, transcript) >= 5):
            return
        self._streak = (None, 0, False)
        if top in self.res.akv_sids:
            line = f.find(top, transcript)
            if line is not None and f.part_at[line] > f.part_at[f.pos] and f.pauri_no(line) <= f.pauri_no() + 1:
                f.place(line)
                self.status, self._akv_miss, self.candidates = "following", 0, []
            return
        self._lock_shabad(top, transcript)

    def _akv_resume(self, transcript: str) -> bool:
        """A shabad sung between pauris is on screen: has the next chhant begun?"""
        f = self.akv
        nxt = f.resume_line()
        if nxt is None or self.t - getattr(self, "_akv_pause_t", self.t) > AKV_PAUSE_MAX_S:
            self._akv_finish()
            return False
        if f.part(nxt).kind == "salok":              # where it was, or on at the next chhant
            ranges = [(f.part(nxt).first, f.part(nxt).end)]
            if f.next_chhant() is not None:
                ranges.append((f.next_chhant(), f.next_chhant() + 3))
        else:
            ranges = [(nxt, nxt + 3)]
        texts = [x for x in (getattr(self, "_recent", None), transcript) if x]
        best, nxt = max(((f.match_score(x, lo, min(hi, len(f.lines) - 1)), lo) for x in texts for lo, hi in ranges),
                        default=(0.0, nxt))
        cur = self.track["sid"] if self.track and self.track.get("kind") == "shabad" else None
        mine = self._aligns(cur, transcript) if cur is not None else 0.0
        # clearly (five words or so in order), or a little (three) in two checks running,
        # better than the shabad on screen and the shabads the words point to
        soft = best >= AKV_RESUME_SOFT and best > mine + 1
        if soft and AKV_RESUME_OTHERS:
            others = [sid for sid, _ in self.res.phrase.rank(transcript, 10) if sid not in self.res.akv_sids][:3]
            soft = all(best > self._aligns(sid, transcript) + 1 for sid in others)
        self._akv_soft = getattr(self, "_akv_soft", 0) + 1 if soft else 0
        if not (best >= AKV_RESUME and best > mine + 2) and self._akv_soft < 2:
            return False
        self._akv_soft = 0
        self._remember_current()
        self._akv_start(nxt, texts[0])
        return True

    def _akv_state(self) -> dict | None:
        if self.akv is None:
            return None
        p = self.akv.part()
        back = self.akv.resume_line() if self.akv_paused else None
        nxt = self.akv.pauri_no(back) if back is not None else None
        if nxt is not None and self.akv.part(back).kind == "salok" and nxt < 24:
            nxt += 1                                     # (or the salok again)
        return {"pauri": p.n if p else None, "part": p.kind if p else None, "paused": self.akv_paused,
                "next": nxt}

    def _anand_six(self, transcript: str):
        """Anand Sahib in kirtan (after Asa Ki Vaar, and at other times) is sung as
        pauris 1-5, the 40th, and the salok ਪਵਣੁ ਗੁਰੂ: its opening or its 40th pauri
        was found (Resources.anand_parts) - follow those as one shabad."""
        L, pos = self.track["lines"], self.tracker.pos
        g = L[pos]["g"] if pos is not None else ""
        six = self.res.anand_track()
        self._load_track(six, shabad=True)
        key = words_of(g)
        target = next((i for i, ln in enumerate(six["lines"]) if key and words_of(ln["g"]) == key), None)
        if target is not None:
            self.tracker.place(target)
        elif transcript:
            self.tracker.update(transcript)
        if self.tracker.pos is None:
            self.tracker.pos = self.tracker.first

    def _other_length(self, transcript: str) -> bool:
        """Paath of Rehras, Chaupai, Sohila or Aarti, and the reader's words are not in
        this length of it: if they are clearly in another length, follow that one."""
        if self.mode != "paath" or not self.track or self.track.get("kind") != "bani":
            return False
        cur = self.track["bani_id"]
        for v in self.res.variants(cur):
            if v == cur:
                continue
            t = BaniTracker(self.res.bani_track(v))
            if t.update(transcript)["state"] == "locked":
                self.bani_id = v
                self._load_track(self.res.bani_track(v))
                self.tracker.pos = t.pos
                self.status, self.confidence, self._lost_n = "following", "high", 0
                self.outbox.append({"type": "notice", "message": f"Following {self.res.banis[v]['name']}: "
                                    "the words being read are in that length of the bani."})
                return True
        return False

    def _preferred_length(self, bid: int, sid: int) -> int:
        """Rehras, Chaupai, Sohila and Aarti are read in several lengths: the one chosen
        in the settings, when it has this shabad."""
        have = self.res.sid_banis.get(str(sid)) or []
        # Chaupai and Aarti have no medium length of their own (SikhiToTheMax's is the
        # short one), and Aarti no extra long one here: the nearest length instead
        for want in {"medium": ("medium", "short"), "extra long": ("extra long", "long")}.get(
                self.bani_length, (self.bani_length,)):
            for v in self.res.variants(bid):
                if self.res.banis[v].get("length") == want and v in have:
                    return v
        return bid

    # ------------------------------------------------------------ Akhand / Sehaj Paath
    def _load_sehaj(self, sid: int, transcript: str = ""):
        self.last_pos = None
        self._conf, self._shown, self._floor, self._backed = [], None, None, False
        self._sehaj_lost = 0
        self.tracker = SehajTracker(self.res.granth, sid)
        self.tracker.pos = None
        if transcript:                                  # place the line from what was just read
            self.tracker.update(transcript)
        if self.tracker.pos is None:
            self.tracker.place_sid(sid, 0)
        self.tracker.take_shift()
        self._new_sehaj_track()

    def _new_sehaj_track(self):
        self.track = self.tracker.track()
        self.outbox.append({"type": "track", "track": dict(self.track)})

    def _sehaj_sync(self):
        """After the tracker may have moved its window: shift every stored line
        number and send the new lines to the screens."""
        if not isinstance(self.tracker, SehajTracker):
            return
        shift, moved = self.tracker.take_shift()
        if not moved:
            return
        if shift:
            n = len(self.tracker.lines) - 1
            fix = lambda p: None if p is None else max(0, min(p - shift, n))     # noqa: E731
            self._conf = [(a, fix(b)) for a, b in self._conf]
            self._shown, self._floor = fix(self._shown), fix(self._floor)
            self.last_pos = fix(getattr(self, "last_pos", None))
        self._new_sehaj_track()

    def _sehaj_follow(self, transcript: str, t: float):
        ev = self.tracker.update(transcript)
        self._sehaj_sync()
        st = ev["state"]
        need = SEHAJ_REFIND_SOON if t - getattr(self, "_refound_t", -1e9) <= SEHAJ_SOON_S else SEHAJ_REFIND
        if (self.tracker.doubt >= need and self.tracker.hits >= SEHAJ_ESTABLISHED
                and clear_words(transcript) >= 4 and self._sehaj_refind(transcript, t)):
            return
        if self.tracker.doubt < need:
            self._refind = (None, 0, False)
        if st in ("tracking", "locked"):
            self.status, self.confidence, self.candidates = "following", "high", []
            self._sehaj_lost = 0
            self._paath_confirm(t)
            return
        if st == "hold":
            if ev["why"] == "no match" and self.status in ("following", "searching_ahead"):
                self.confidence = "medium"              # words, but unclear: the reader is still reading
            elif self.status != "searching_ahead":
                self.status, self.confidence = "held_quiet", "medium"
            return
        # searching: the last line stays on screen while it looks further ahead
        self._sehaj_lost = getattr(self, "_sehaj_lost", 0) + 1
        self.status, self.confidence = "searching_ahead", "low"
        if self.tracker.hits < SEHAJ_ESTABLISHED and self._sehaj_lost >= SEHAJ_RETRY:
            # never really took hold: perhaps the wrong place - identify again
            self.tracker, self.track, self.status = None, None, "finding"
            self._streak = (None, 0, False)
            self._identify(transcript)
            return
        if self._sehaj_lost >= SEHAJ_OFFER and len(transcript.split()) >= 3:
            bc = self.res.base.find_candidates(transcript, top_k=10)     # offer options, never switch
            self.candidates = [self._cand(sid, sc) for sid, sc in gated_rank(bc, self.res.phrase.rank(transcript, 10))[:3]]

    def _sehaj_refind(self, transcript: str, t: float) -> bool:
        """Unsure for a while: which shabad of the Granth is being read? Move there when
        the same one (or the next one: the reader moves on) comes top in checks in a row."""
        G = self.res.granth
        pr = self.res.phrase.rank(transcript, 10)
        ranked = [(sid, sc) for sid, sc in gated_rank(self.res.base.find_candidates(transcript, top_k=10), pr)
                  if sid in G]
        if not ranked:
            self._refind = (None, 0, False)
            return False
        top = ranked[0][0]
        confident = bool(pr) and pr[0][0] == top and pr[0][1] >= 35 and \
            (pr[0][1] - (pr[1][1] if len(pr) > 1 else 0)) >= 10
        prev, n, had = getattr(self, "_refind", (None, 0, False))
        same = prev is not None and (top == prev or G.index[G.canonical(top)] - G.index[G.canonical(prev)] in (0, 1))
        n = n + 1 if same else 1
        had = (had if same else False) or confident
        self._refind = (top, n, had)
        if not ((n >= 2 and had) or n >= 3):
            return False
        before = self.tracker.where_now()
        self.tracker.relocate(int(top), transcript)
        self._sehaj_sync()
        self._refind = (None, 0, False)
        self._sehaj_lost = 0
        self.status, self.confidence, self.candidates = "following", "high", []
        self._conf, self._shown, self._floor, self._backed = [], None, None, False
        self._paath_confirm(t)
        self._refound_t = t
        self.found_again = f"found the place again: shabad {top} (was {before})"
        L = self.tracker.lines[self.tracker.pos]
        self.outbox.append({"type": "notice", "message": f"Found the reader's place again: Ang {L['ang']}."})
        return True

    def _sehaj_quick(self, transcript: str, t: float) -> list[dict]:
        if not self.wants_quick() or is_simran(transcript):
            return []
        new = self.tracker.quick(transcript)
        self._sehaj_sync()
        if new is None or new <= self.tracker.pos:
            return []
        self.tracker.pos, self.tracker.misses = new, 0
        self.tracker.keep_up()
        self._sehaj_sync()
        self.t = t
        self._paath_confirm(t)
        return self._emit()

    # ------------------------------------------------------------ paath: anticipate the next line
    def _paath_confirm(self, t: float):
        """A check has confirmed the reader's line: settle what is on screen."""
        p = self.tracker.pos
        self._conf = [(a, b) for a, b in self._conf + [(t, p)] if t - a <= 45]
        shown = self._shown
        if shown is None or p >= shown:
            self._floor, self._backed = None, False
        elif shown - p <= 2 and not self._backed:
            self._floor, self._backed = shown, True      # slightly ahead: hold once, don't jump back
        else:
            self._floor, self._backed = None, False      # clearly behind: go back
        self._shown = self._predict(t)

    def _pace(self):
        """Seconds per line over the last ~45 s of confirmed progress."""
        if len(self._conf) < 3:
            return None
        (t0, p0), (t1, p1) = self._conf[0], self._conf[-1]
        if p1 - p0 < 3 or t1 <= t0:
            return None
        return min(8.0, max(1.2, (t1 - t0) / (p1 - p0)))

    def _moving(self) -> bool:
        return self.status == "following" or (self.in_sehaj and self.status == "searching_ahead")

    def _predict(self, t: float) -> int:
        t_c, p_c = self._conf[-1]
        pace, pred = self._pace(), p_c
        most = SEHAJ_PRED_MAX if self.in_sehaj else 2
        if pace and self._moving():                  # stays at the furthest line reached: never slides back
            dt = min(t - t_c, max(8.0, (most + 1) * pace))
            pred = p_c + min(most, int(dt / pace + 0.5))
        if self._floor is not None:
            if pred >= self._floor:
                self._floor = None
            else:
                pred = self._floor
        return min(pred, len(self.tracker.lines) - 1)

    def tick(self, t: float) -> list[dict]:
        """Call as audio arrives: moves the display ahead between checks (paath mode)."""
        if (not self.predict_enabled or self.mode != "paath" or self.held_by_user or not self._conf
                or self.tracker is None or self.tracker.pos is None or not self._moving()):
            return []
        new = self._predict(t)
        if new != self._shown:
            self._shown, self.t = new, t
            return self._emit()
        return []

    # ------------------------------------------------------------ internals
    def _coverage(self, transcript: str) -> float:
        """Share of heard words that also occur (fuzzily) in the locked shabad."""
        from rapidfuzz import fuzz
        from rapidfuzz.process import cdist
        from .phrase_matcher import words_of
        q = [w for w in words_of(transcript) if len(w) >= 2]
        if len(q) < 3:
            return -1.0
        sim = cdist(q, self.tracker.words, scorer=fuzz.ratio, workers=1)
        return float((sim.max(axis=1) >= 75).mean())

    def _still_here(self, transcript: str, sid: int) -> bool:
        """Is the locked shabad still among the best explanations of what is heard?
        Compared against all of Gurbani, so long shabads full of common words
        cannot hold the lock on their own."""
        ranked = self.res.phrase.rank(transcript, 20)
        if not ranked:
            return False
        mine = dict(ranked).get(sid, 0.0)
        return mine > 0 and mine >= 0.6 * ranked[0][1]

    def _kirtan_follow(self, transcript: str):
        ev = {"state": "none"}
        if getattr(self, "_recent", None):
            ev = self.tracker.update(self._recent)       # freshest audio decides the line
        if ev["state"] not in ("tracking", "locked"):
            ev = self.tracker.update(transcript)
        cur = self.track["sid"]
        if self.tracker.pos is None:
            self.tracker.pos = self.last_pos if self.last_pos is not None else getattr(self.tracker, "first", 1)
        self.tracker.misses = 0                 # the tracker never decides to leave on its own
        if len(transcript.split()) < 3 or clear_words(transcript) < MIN_CLEAR_TO_LEAVE:
            # too few words, or only fragments ("ਹੈ ਨਾ ਹ ਹ ਮੈ ਨਾ" - a whole sangat singing
            # often comes out like this): nothing to judge by, so hold the shabad on screen
            self.status = "held_quiet"
            self._unmatched_too_long()
            return
        hit = ev["state"] in ("tracking", "locked")      # the tracker decides the LINE ...
        # ... and the shabad: first inside the current shabad (the words just heard
        # line up, in order, in one of its lines), only then against all of Gurbani
        strong = hit and getattr(self.tracker, "strength", 0.0) >= STRONG_INSIDE
        still = strong or self._still_here(transcript, cur)
        if hit and still:
            self.status, self.confidence, self._away, self._last_hit = "following", "high", 0, self.t
            self._last_ok, self._hits = self.t, getattr(self, "_hits", 0) + 1
            return
        stale = self.t - getattr(self, "_last_hit", self.t) >= 90
        if still and not stale:
            self.status, self.confidence, self._away = "following", "medium", 0
            self._last_ok, self._hits = self.t, getattr(self, "_hits", 0) + 1
            return
        if self._unmatched_too_long():
            return
        back = self._returning(transcript)
        if back:
            self._return_to(back, transcript, recent=getattr(self, "_recent", None))
            return
        self._away = getattr(self, "_away", 0) + 1
        self.status, self.confidence = "held_quiet", "low"
        if self._away >= 2 or stale:             # sustained mismatch: look for the next shabad
            if stale:
                self._last_hit = self.t
            self._identify(transcript, exclude_lock=cur)

    def _teacher(self) -> Teacher:
        if getattr(self, "teacher", None) is None:
            self.teacher = Teacher(self.res.learnt)
        return self.teacher

    def _teach(self, transcript: str, t: float):
        """While a sewadar-picked shabad stays on screen, save what is heard."""
        tc = self._teacher()
        if tc.sid is None:
            return
        on = self.track["sid"] if self.track and self.track.get("kind") == "shabad" and self.mode == "kirtan" else None
        if on is None or is_simran(transcript) or clear_words(transcript) < MIN_CLEAR_TO_LEAVE:
            if on != tc.sid:
                tc.stop()
            return
        if tc.heard(on, transcript, t):
            self.res.phrase.set_learnt(self.res.learnt.feature_map())

    def _unmatched_too_long(self) -> bool:
        """Nothing heard has matched the shabad on screen for BLANK_AFTER_S, and
        it never really took hold (fewer than ESTABLISHED matching checks since
        it went up - a wrong guess); sewadar picks and paused auto changes are
        left alone. Take it down rather than leave a possibly wrong shabad up. It goes to the top of the recent
        list, so Back (B, or Previous on the phone) brings it straight back."""
        if (self._sure or self.held_by_user or getattr(self, "_hits", 0) >= ESTABLISHED
                or self.t - getattr(self, "_last_ok", self.t) < BLANK_AFTER_S):
            return False
        if self.track and self.track.get("kind") == "shabad" and self.tracker:
            sid = self.track["sid"]
            pos = self.tracker.pos if self.tracker.pos is not None else self.last_pos
            entry = {"sid": sid, "pos": pos, "high": getattr(self.tracker, "high", None), "t": self.t}
            self.recent = ([entry] + [r for r in self.recent if r["sid"] != sid])[:RECENT_KEEP]
        self.track, self.tracker, self.last_pos = None, None, None
        self.status, self.confidence, self.candidates = "cleared", "low", []
        self._streak, self._away, self.suggestion = (None, 0, False), 0, None
        self.outbox.append({"type": "notice", "message":
                            "Nothing heard matched the shabad for a while, so the screen was cleared. "
                            "Press Back (B) if it should stay."})
        return True

    def _identify(self, transcript: str, exclude_lock: int | None = None):
        words = transcript.split()
        if len(words) < 3:
            self.status = "listening" if self.tracker is None else self.status
            return
        if self.mode == "kirtan" and self.recent:
            back = self._returning(transcript)
            if back:
                self._return_to(back, transcript, recent=getattr(self, "_recent", None))
                return
        bc = self.res.base.find_candidates(transcript, top_k=10)
        pr = self.res.phrase.rank(transcript, 10)
        ranked = gated_rank(bc, pr)
        confident = bool(pr) and pr[0][1] >= 35 and (pr[0][1] - (pr[1][1] if len(pr) > 1 else 0)) >= 10
        self.candidates = [self._cand(sid, sc) for sid, sc in ranked[:3]]
        if not ranked:
            return
        top = ranked[0][0]
        if exclude_lock is not None and top == exclude_lock:
            self._away, self._streak = 0, (None, 0, False)
            self.status = "following"
            return
        if exclude_lock is None or self.status != "following":
            self.status = "finding"
        prev, n, had_conf = self._streak
        n = n + 1 if top == prev else 1
        had_conf = (had_conf if top == prev else False) or (confident and pr[0][0] == top)
        self._streak = (top, n, had_conf)
        if (n >= 2 and had_conf) or n >= 3:
            self._lock_shabad(top, transcript)
            return
        best = self._evidence(ranked, transcript)
        if best is not None and best != exclude_lock:
            self._lock_shabad(best, transcript)

    def wants_acoustic(self) -> bool:
        """Is acoustic matching worth running for the next check? Only in kirtan,
        while no shabad has taken hold (nothing up, or one not yet established or
        no longer matching); never against a sewadar's pick or Hold."""
        if not ACOUSTIC or getattr(self.res, "acoustic", None) is None or self.mode != "kirtan" \
                or self.held_by_user or getattr(self, "_sure", False) or (self.akv is not None and not self.akv_paused):
            return False
        cur = self.track["sid"] if self.track and self.track.get("kind") == "shabad" else None
        return not (cur is not None and getattr(self, "_hits", 0) >= ESTABLISHED and self.status == "following")

    def _acoustic(self, transcript: str):
        """Tally the best shabads by sound; put up one that leads clearly."""
        ac = getattr(self.res, "acoustic", None)
        sounds = getattr(self, "_sounds", None)
        if sounds is None and getattr(self, "_lp", None) is None:
            return
        if not self.wants_acoustic():
            self._ac = []                       # a shabad has taken hold and is being followed
            return
        cur = self.track["sid"] if self.track and self.track.get("kind") == "shabad" else None
        tally = getattr(self, "_ac", None)
        if tally is None:
            tally = self._ac = []
        if clear_words(transcript) >= 1:
            if sounds is None:
                sounds = ac.rank(self._lp, transcript, top=len(AC_PTS))
            tally.append((self.t, [sid for sid, _ in sounds[:len(AC_PTS)]]))
        tally[:] = [x for x in tally if x[0] > self.t - AC_S]
        pts: dict[int, int] = {}
        n: dict[int, int] = {}
        for _, sids in tally:
            for i, sid in enumerate(sids):
                pts[sid] = pts.get(sid, 0) + AC_PTS[i]
                n[sid] = n.get(sid, 0) + 1
        if not pts:
            return
        order = sorted(pts.items(), key=lambda x: -x[1])
        sid, p = order[0]
        runner = order[1][1] if len(order) > 1 else 0
        held = cur is not None and getattr(self, "_hits", 0) >= ESTABLISHED
        need = AC_LEAD_SWITCH if held else AC_LEAD
        if sid != cur and n[sid] >= AC_MIN_CHECKS and p - runner >= need and pts.get(cur, 0) * 2 < p \
                and not (held and pts.get(cur, 0) > 0):
            self._lock_shabad(sid, transcript)
            self.status = "following"

    def _evidence(self, ranked, transcript: str) -> int | None:
        """The shabad that keeps coming back near the top over the last
        EVIDENCE_S, clearly ahead of every other - including the one on screen."""
        ev = getattr(self, "_ev", None)
        if ev is None:
            ev = self._ev = []
        if clear_words(transcript) >= MIN_CLEAR_TO_LEAVE:
            ev.append((self.t, [sid for sid, _ in ranked[:len(EVIDENCE_PTS)]]))
        ev[:] = [x for x in ev if x[0] >= self.t - EVIDENCE_S]
        pts: dict[int, int] = {}
        n: dict[int, int] = {}
        for _, sids in ev:
            for i, sid in enumerate(sids):
                pts[sid] = pts.get(sid, 0) + EVIDENCE_PTS[i]
                n[sid] = n.get(sid, 0) + 1
        if not pts:
            return None
        order = sorted(pts.items(), key=lambda x: -x[1])
        sid, p = order[0]
        runner = order[1][1] if len(order) > 1 else 0
        cur = self.track["sid"] if self.track and self.track.get("kind") == "shabad" else None
        if n[sid] >= EVIDENCE_MIN_CHECKS and p >= EVIDENCE_MIN_PTS and p - runner >= EVIDENCE_LEAD \
                and pts.get(cur, 0) * 2 < p:
            return sid
        return None

    def _returning(self, transcript: str) -> dict | None:
        """Is the ragi back on one of the recent shabads? A recent shabad is
        judged like the one on screen (it only has to be among the best
        explanations of what is heard), plus the words must line up in order
        in its text. One window is then enough to go back."""
        ranked = self.res.phrase.rank(transcript, 30)
        if not ranked or len(transcript.split()) < 4:
            return None
        top = ranked[0][1]
        score = dict(ranked)
        cur = self.track["sid"] if self.track and self.track.get("kind") == "shabad" else None
        for r in self.recent:
            s = score.get(r["sid"], 0.0)
            if s >= 25 and s >= 0.6 * top and s > score.get(cur, 0.0) + 5 and self._aligns(r["sid"], transcript) >= 4:
                return r
        return None

    def _aligns(self, sid: int, transcript: str) -> float:
        """Best in-order word alignment of the transcript inside a shabad."""
        from .phrase_matcher import words_of
        f = self._followers.get(sid)
        if f is None:
            f = self._followers[sid] = ShabadFollower(self.res.shabad_track(sid))
        q = words_of(transcript)
        if len(q) < 3:
            return 0.0
        full, _ = f._line_scores(q)
        return float(full.max()) if len(full) else 0.0

    def _remember_current(self):
        """Keep the shabad we are leaving close at hand - but only if it was
        really being sung (followed for 40 s or more, or picked by the
        sewadar), so a brief wrong guess is never brought back."""
        if not (self.track and self.track.get("kind") == "shabad" and self.tracker):
            return
        if not self._sure and self._last_hit - self._locked_at < 40:
            return
        sid = self.track["sid"]
        pos = self.tracker.pos if self.tracker.pos is not None else self.last_pos
        entry = {"sid": sid, "pos": pos, "high": getattr(self.tracker, "high", None), "t": self.t}
        self.recent = [entry] + [r for r in self.recent if r["sid"] != sid]
        self.recent = self.recent[:RECENT_KEEP]

    def _return_to(self, r: dict, transcript: str, recent: str | None = None):
        sid = r["sid"]
        self._lock_shabad(sid, transcript="")
        if r.get("pos") is not None:
            self.tracker.pos = r["pos"]
        if hasattr(self.tracker, "high"):
            self.tracker.high = r.get("high")
        for text in (recent, transcript):             # place the line from what was just sung
            if text and self.tracker.update(text)["state"] in ("tracking", "locked"):
                break
        self.recent = [x for x in self.recent if x["sid"] != sid]
        self._sure = True                              # it was sung before: worth remembering again

    def _lock_shabad(self, sid: int, transcript: str = ""):
        if self.mode == "kirtan" and self._akv_lock(sid, transcript):
            return
        if self.mode == "kirtan" and sid in self.res.anand_parts and self.track and self.track.get("id") == "k6":
            if transcript:                                # already following Anand Sahib's six pauris
                self.tracker.update(transcript)
            self.status, self.confidence, self.candidates, self._streak = "following", "high", [], (None, 0, False)
            return
        if self.mode == "kirtan" and not (self.track and self.track.get("sid") == sid):
            self._remember_current()
        banis = self.res.sid_banis.get(str(sid)) or []
        if self.in_sehaj and sid in self.res.granth:
            self._load_sehaj(sid, transcript)
        elif self.mode == "paath" and banis:
            bid = self.bani_id if self.bani_id in banis else self._preferred_length(banis[0], sid)
            self.bani_id = bid
            self._load_track(self.res.bani_track(bid))
            first = next((i for i, l in enumerate(self.track["lines"]) if l["sid"] == sid), 0)
            self.tracker.pos = first
            if transcript:                                 # refine inside the piece
                self.tracker.update(transcript)
        else:
            self._load_track(self.res.shabad_track(sid), shabad=True)
            if transcript:
                self.tracker.update(transcript)
            if self.tracker.pos is None:
                self.tracker.pos = getattr(self.tracker, "first", 1 if len(self.tracker.lines) > 1 else 0)
            if self.mode == "kirtan" and sid in self.res.anand_parts:
                self._anand_six(transcript)
        self.status, self.confidence = "following", "high"
        self.candidates = []
        self._streak, self._ev = (None, 0, False), []
        self._away, self._last_hit, self._last_ok, self._hits = 0, self.t, self.t, 0
        self._locked_at, self._sure = self.t, False
        self.suggestion = None
        if self.mode == "kirtan" and banis:
            b = self.res.banis[banis[0]]
            self.suggestion = {"bani_id": b["id"], "name": b["name"], "name_gurmukhi": b["name_gurmukhi"]}

    def _load_track(self, track: dict, shabad: bool = False):
        self.track = track
        self.last_pos = None
        self._conf, self._shown, self._floor, self._backed = [], None, None, False
        if shabad and self.mode == "kirtan":   # knows the rahao and how ragis move through a shabad
            self.tracker = ShabadFollower(track, min_track=6.0)
        elif shabad:   # paath of a single shabad: whole shabad in range
            n = len(track["lines"])
            self.tracker = BaniTracker(track, back=n, ahead=n, min_track=6.0,
                                       min_cold=8.0, lost_after=2)
            self.tracker.pos = None
        else:
            self.tracker = BaniTracker(track)
            self.tracker.pos = None
        self.outbox.append({"type": "track", "track": {k: v for k, v in track.items()}})

    def _cand(self, sid: int, score: float) -> dict:
        m = self.res.meta.get(str(sid), {})
        return {"sid": sid, "score": round(score), "first_line": self.res.phrase.first_line.get(sid, ""),
                "where": _where(m)}

    def _emit(self) -> list[dict]:
        pos = self.tracker.pos if self.tracker else None
        confirmed = pos
        if (pos is not None and self.mode == "paath" and self.predict_enabled
                and getattr(self, "_shown", None) is not None):
            pos = self._shown
        if pos is not None:
            self.last_pos = pos
        next_pos = None
        if pos is not None and self.tracker:
            if hasattr(self.tracker, "expected_next") and self.tracker.pos == pos:
                next_pos = self.tracker.expected_next()
            elif pos + 1 < len(self.tracker.lines):
                next_pos = pos + 1
        prev = None
        if self.mode == "kirtan" and self.recent:
            r = self.recent[0]
            prev = self._cand(r["sid"], 0)
        msg = {"type": "state", "t": round(self.t, 1), "mode": self.mode, "status": self.status,
               "status_text": STATUS_TEXT[self.status], "held_by_user": self.held_by_user,
               "heard": self.heard, "track_id": self.track["id"] if self.track else None,
               "pos": pos, "confirmed_pos": confirmed, "last_pos": getattr(self, "last_pos", None), "total": len(self.tracker.lines) if self.tracker else 0,
               "confidence": self.confidence, "candidates": self.candidates,
               "suggestion": self.suggestion, "next_pos": next_pos, "previous": prev, "sehaj": self.sehaj,
               "akv": self._akv_state()}
        out, self.outbox = self.outbox + [msg], []
        return out
