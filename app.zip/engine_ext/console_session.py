"""
ConsoleSession - the decision logic behind the sewadar console.

Feed it one ASR transcript at a time (a ~10 s window every few seconds) and
sewadar commands; it returns messages for the GUI.

This file has the commands, the checks and the messages; each mode's own logic is in
session_kirtan.py, session_akv.py (Asa Ki Vaar) and session_paath.py (banis, Akhand /
Sehaj Paath), and what is loaded once in resources.py.

Modes
  kirtan  identify the shabad (gated matcher), auto-lock when the evidence
          agrees, then follow lines within it (rahao returns allowed).
          Unlocks after sustained non-matching audio and finds the next one.
  paath   follow a whole bani (Sukhmani Sahib, Japji Sahib, Asa di Vaar ...)
          as one continuous track. With bani_id=None it identifies the
          piece first, then switches to the bani it belongs to.
          With sehaj=True (Akhand Paath / Sehaj Paath): once the place is
          found, follow Sri Guru Granth Sahib Ji in order, into the next
          shabad and the next Ang, without identifying each shabad again
          (engine_ext/sehaj.py).

Asa Ki Vaar (kirtan)  once two parts of the Vaar are heard in the order they are sung
        (a chhant, then its saloks), or the sewadar says so, the Vaar is followed as
        one list in that order (engine_ext/akv.py). A shabad sung after a pauri is
        shown as usual, and the Vaar carries on at the next chhant. After the 24th
        pauri the Vaar is over; Anand Sahib after it is followed as its 6 pauris and
        salok (bani 6).

Return  the last few shabads are remembered with the line the ragi reached.
        If the ragi goes back to one of them (after a parmaan, or a shabad on
        a similar theme), one clear window is enough to switch back.

Holds   simran, near-silence, or the sewadar pressing Hold keep the current
        line on screen and never count as evidence for a different shabad.

Messages
  {"type": "track", ...}   the full line list whenever the track changes
  {"type": "state", ...}   status, position, candidates, heard text
"""
from __future__ import annotations

from .akv import AKV_BANI
from .bani_tracker import BaniTracker
from .blend import gated_rank
from .heard import is_noise
from .sehaj import SehajTracker
from .session_akv import AkvMixin
from .session_kirtan import KirtanMixin
from .session_paath import PaathMixin
from .shabad_follower import ShabadFollower
from .simran import is_simran

# imported from here by the Lab, the tools and the web version
from .heard import MIN_CLEAR_TO_LEAVE, clear_words  # noqa: E402,F401
from .resources import LENGTHS, Resources, _where  # noqa: E402,F401

STATUS_TEXT = {
    "listening": "Listening",
    "finding": "Finding the shabad",
    "following": "Following",
    "held_simran": "Held during simran",
    "held_quiet": "Held, waiting for words",
    "held_user": "Auto changes paused",
    "lost": "Lost the place, searching",
    "searching_ahead": "Not sure of the line, looking ahead",
    "cleared": "Screen cleared: nothing heard matched for a while",
}


class ConsoleSession(KirtanMixin, AkvMixin, PaathMixin):
    """The session's commands, the checks and what is sent to the screens. Each mode's
    own logic, and the numbers that tune it, are in session_kirtan.py, session_akv.py
    and session_paath.py."""

    def __init__(self, res: Resources, mode: str = "kirtan", bani_id: int | None = None, sehaj: bool = False):
        self.res = res
        self.sehaj = bool(sehaj)
        self.t = 0.0
        self.heard = ""
        self.held_by_user = False
        self.outbox: list[dict] = []
        self.predict_enabled = True
        self.recent: list[dict] = []
        self._followers: dict[int, ShabadFollower] = {}
        self.bani_length = "long"                   # which length of Rehras, Chaupai, Sohila, Aarti to follow
        self._akv_end_t = None
        self._set_mode(mode, bani_id)

    def set_mode(self, mode: str, bani_id: int | None = None, sehaj: bool | None = None):
        if sehaj is not None:
            self.sehaj = bool(sehaj)
        self._set_mode(mode, bani_id)
        return self._emit()

    @property
    def in_sehaj(self) -> bool:
        return self.mode == "paath" and self.sehaj

    def _set_mode(self, mode: str, bani_id: int | None = None):
        """Switch mode without sending anything yet (the caller emits, so the
        new track reaches the screens together with the state)."""
        self.mode = mode
        self.bani_id = bani_id
        self.track = None
        self._conf, self._shown, self._floor, self._backed = [], None, None, False
        self.tracker = None
        self.status = "listening"
        self.candidates: list[dict] = []
        self.suggestion = None
        self.confidence = "none"
        self._streak = (None, 0, False)
        self.recent = []
        self.akv, self.akv_paused, self._akv_seen, self._akv_miss = None, False, [], 0
        if mode == "paath" and self.sehaj:
            self.bani_id = None                     # Akhand / Sehaj Paath follows the Granth, not a bani
        elif mode == "paath" and bani_id is not None:
            self._load_track(self.res.bani_track(bani_id))

    def reset(self):
        return self.set_mode(self.mode, self.bani_id)

    def hold(self, on: bool = True):
        self.held_by_user = on
        if on:
            self.status = "held_user"
        elif self.status == "held_user":
            self.status = "following" if self.tracker and self.tracker.pos is not None else "listening"
        return self._emit()

    def step(self, delta: int):
        if self.tracker:
            self.tracker.step(delta)
            self._sehaj_sync()
            self.confidence = "manual"
            self._conf, self._shown, self._floor, self._backed = [(self.t, self.tracker.pos)], self.tracker.pos, None, False
        return self._emit()

    def goto(self, pos: int):
        if self.tracker:
            if hasattr(self.tracker, "place"):
                self.tracker.place(pos)
            else:
                self.tracker.pos = max(0, min(int(pos), len(self.tracker.lines) - 1))
            self.tracker.misses = 0
            self._sehaj_sync()
            self.confidence = "manual"
            self._conf, self._shown, self._floor, self._backed = [(self.t, self.tracker.pos)], self.tracker.pos, None, False
        return self._emit()

    def confirm(self, sid: int):
        """Sewadar picks a candidate: lock onto it (or its bani in paath mode)."""
        self._lock_shabad(int(sid), transcript=self.heard)
        self.confidence = "manual"
        self._sure = True
        self._teacher().picked(int(sid), self.t)
        return self._emit()

    def back(self, sid: int | None = None):
        """Sewadar: go back to the previous shabad (or a given recent one)."""
        r = next((x for x in self.recent if sid is None or x["sid"] == int(sid)), None)
        if r:
            self._return_to(r, transcript="")
            self.confidence = "manual"
            self._sure = True
            self._teacher().picked(int(r["sid"]), self.t)
        return self._emit()

    def show(self, sid: int, pos: int | None = None, bani_id: int | None = None):
        """Sewadar picked a line from search or history: show it, then keep
        following from there."""
        if bani_id is not None and int(bani_id) == AKV_BANI and self.mode == "kirtan":
            self.akv_command("start")              # Asa Ki Vaar picked in kirtan (history): as it is sung
            if pos is not None and self.akv is not None and not self.akv_paused:
                self.akv.place(int(pos))
            return self._emit()
        if bani_id is not None:
            self.sehaj = False                      # a bani picked by hand: follow that bani
            self._set_mode("paath", int(bani_id))
            self.tracker.pos = max(0, min(int(pos or 0), len(self.tracker.lines) - 1))
            self._conf, self._shown = [(self.t, self.tracker.pos)], self.tracker.pos
            self.status, self.confidence = "following", "manual"
            return self._emit()
        self._lock_shabad(int(sid), transcript="")
        self.confidence, self._sure = "manual", True
        self._teacher().picked(int(sid), self.t)
        if pos is not None:
            if self.track["kind"] == "shabad":
                target = int(pos)
                if self.track.get("id") == "k6" and int(sid) in self.res.anand_parts:
                    own = self.res.shabad_track(int(sid))["lines"]      # Anand Sahib's six pauris: that line
                    g = own[int(pos)]["g"] if 0 <= int(pos) < len(own) else ""
                    target = next((i for i, l in enumerate(self.track["lines"]) if l["g"] == g), 0)
            else:                                   # paath: find the line inside the bani
                g = self.res.shabad_track(int(sid))["lines"][int(pos)]["g"]
                L = self.track["lines"]
                target = next((i for i, l in enumerate(L) if l.get("sid") == int(sid) and l["g"] == g),
                              next((i for i, l in enumerate(L) if l.get("sid") == int(sid)), 0))
            if isinstance(self.tracker, SehajTracker):
                self.tracker.place_sid(int(sid), int(pos))
                self._sehaj_sync()
                target = self.tracker.pos
            elif hasattr(self.tracker, "place"):
                self.tracker.place(target)
            else:
                self.tracker.pos = target
            self._conf, self._shown, self._floor, self._backed = [(self.t, target)], target, None, False
        return self._emit()

    def wants_quick(self) -> bool:
        """Short checks every second or two: in kirtan on a shabad, and in Akhand /
        Sehaj Paath once the place is found (readers can be fast)."""
        if self.mode == "kirtan" and self.akv is not None and not self.akv_paused:
            return not self.held_by_user and self.tracker is self.akv
        if self.mode == "kirtan":                   # exactly as before this mode existed
            return bool(self.track and self.track.get("kind") == "shabad" and not self.held_by_user)
        return (self.in_sehaj and not self.held_by_user and isinstance(self.tracker, SehajTracker)
                and self.tracker.pos is not None and self.status == "following")

    def quick_line(self, transcript: str, t: float) -> list[dict]:
        """Every second or two in kirtan: if the opening words of another line of
        the current shabad were just heard, move there at once. In Akhand / Sehaj
        Paath: if the reader has already reached one of the next lines, move on."""
        if self.in_sehaj:
            return self._sehaj_quick(transcript, t)
        if self.akv is not None and not self.akv_paused and self.tracker is self.akv:
            if self.held_by_user or is_simran(transcript):
                return []
            new = self.akv.quick(transcript)
            if new is None or new == self.akv.pos:
                return []
            self.akv.place(new)
            self.status, self.confidence, self.t, self._akv_miss = "following", "high", t, 0
            return self._emit()
        if (self.mode != "kirtan" or self.held_by_user or not isinstance(self.tracker, ShabadFollower)
                or is_simran(transcript)):
            return []
        new = self.tracker.quick(transcript)
        if new is None or new == self.tracker.pos:
            return []
        self.tracker._move(new)          # a line of this shabad was heard: we are still here
        self.status, self.confidence, self.t = "following", "high", t
        self._away, self._last_hit, self._streak, self.candidates = 0, t, (None, 0, False), []
        return self._emit()

    def accept_suggestion(self):
        if self.suggestion and self.suggestion.get("bani_id") == AKV_BANI and self.mode == "kirtan":
            return self.akv_command("start")
        if self.suggestion:
            bid = self.suggestion["bani_id"]
            pos_sid = self.track["sid"] if self.track and self.track["kind"] == "shabad" else None
            self.sehaj = False
            self._set_mode("paath", bid)
            if pos_sid is not None:
                first = next((i for i, l in enumerate(self.track["lines"]) if l["sid"] == pos_sid), 0)
                self.tracker.pos = first
            self.status = "following"
        return self._emit()

    def process(self, transcript: str, t: float, recent: str | None = None, logprobs=None,
                sounds: list | None = None) -> list[dict]:
        """transcript: the context window (20 s in kirtan). recent: optional
        transcript of just the last ~10 s, used to place the current line.
        logprobs: the speech model's sound probabilities for the same window, for
        acoustic matching; or sounds: that matching already done (the app runs it
        off its event loop, see wants_acoustic)."""
        self.t, self.heard = t, (recent or transcript)
        self._recent, self._lp, self._sounds = recent, logprobs, sounds
        if self.held_by_user:
            return self._emit()
        self._teach(transcript, t)
        if is_noise(transcript):                 # music heard as syllables: changes nothing
            return self._emit()
        if is_simran(transcript):
            self.status = "held_simran" if self.tracker and self.tracker.pos is not None else "listening"
            return self._emit()

        if self.mode == "kirtan" and self.akv is not None:
            if not self.akv_paused:
                self._akv_follow(transcript)
                return self._emit()
            if self._akv_resume(transcript):
                return self._emit()

        if self.tracker is None:
            self.status = "finding"
            self._identify(transcript)
            self._acoustic(transcript)
            return self._emit()

        if self.mode == "kirtan" and self.track["kind"] == "shabad":
            if self.akv is None and self._akv_next_part(transcript):
                return self._emit()
            self._kirtan_follow(transcript)
            self._acoustic(transcript)
            return self._emit()

        if isinstance(self.tracker, SehajTracker):
            self._sehaj_follow(transcript, t)
            return self._emit()

        ev = self.tracker.update(transcript)
        st = ev["state"]
        self._lost_n = 0 if st in ("tracking", "locked") else getattr(self, "_lost_n", 0) + (st in ("searching", "lost"))
        if st in ("tracking", "locked"):
            self.status, self.confidence = "following", "high"
            self.candidates = []
            self._paath_confirm(t)
        elif st == "hold":
            self.status = "held_quiet"
            self.confidence = "medium"
        elif st == "searching":
            self.status, self.confidence = "lost", "low"
        elif st == "lost":
            if self.track["kind"] == "shabad" and self.mode == "kirtan":
                # the ragi has probably moved on: keep the old line visible, find the next one
                self.status, self.confidence = "finding", "low"
                self.tracker.pos = None
                self._identify(transcript)
            else:
                self.status, self.confidence = "lost", "low"
        if self.status == "lost" and getattr(self, "_lost_n", 0) >= 2 and self._other_length(transcript):
            return self._emit()
        if self.status == "lost" and self._paath_refind(transcript):
            return self._emit()
        if self.status == "lost" and getattr(self, "_lost_n", 0) >= 3 and len(transcript.split()) >= 3:
            bc = self.res.base.find_candidates(transcript, top_k=10)     # show options, don't switch
            self.candidates = [self._cand(sid, sc) for sid, sc in gated_rank(bc, self.res.phrase.rank(transcript, 10))[:3]]
        return self._emit()

    def _lock_shabad(self, sid: int, transcript: str = ""):
        if self.mode == "kirtan" and self._akv_lock(sid, transcript):
            return
        if self.mode == "kirtan" and sid in self.res.anand_parts and self.track and self.track.get("id") == "k6":
            if transcript:                                # already following Anand Sahib's six pauris
                self.tracker.update(transcript)
            self.status, self.confidence, self.candidates, self._streak = "following", "high", [], (None, 0, False)
            return
        if self.mode == "kirtan" and not (self.track and self.track.get("sid") == sid):
            self._remember_current()
        banis = self.res.sid_banis.get(str(sid)) or []
        if self.in_sehaj and sid in self.res.granth:
            self._load_sehaj(sid, transcript)
        elif self.mode == "paath" and banis:
            bid = self.bani_id if self.bani_id in banis else self._preferred_length(banis[0], sid)
            self.bani_id = bid
            self._load_track(self.res.bani_track(bid))
            first = next((i for i, l in enumerate(self.track["lines"]) if l["sid"] == sid), 0)
            self.tracker.pos = first
            if transcript:                                 # refine inside the piece
                self.tracker.update(transcript)
        else:
            self._load_track(self.res.shabad_track(sid), shabad=True)
            if transcript:
                self.tracker.update(transcript)
            if self.tracker.pos is None:
                self.tracker.pos = getattr(self.tracker, "first", 1 if len(self.tracker.lines) > 1 else 0)
            if self.mode == "kirtan" and sid in self.res.anand_parts:
                self._anand_six(transcript)
        self.status, self.confidence = "following", "high"
        self.candidates = []
        self._streak, self._ev = (None, 0, False), []
        self._away, self._last_hit, self._last_ok, self._hits = 0, self.t, self.t, 0
        self._locked_at, self._sure = self.t, False
        self.suggestion = None
        if self.mode == "kirtan" and banis:
            b = self.res.banis[banis[0]]
            self.suggestion = {"bani_id": b["id"], "name": b["name"], "name_gurmukhi": b["name_gurmukhi"]}

    def _load_track(self, track: dict, shabad: bool = False):
        self.track = track
        self.last_pos = None
        self._conf, self._shown, self._floor, self._backed = [], None, None, False
        if shabad and self.mode == "kirtan":   # knows the rahao and how ragis move through a shabad
            self.tracker = ShabadFollower(track, min_track=6.0)
        elif shabad:   # paath of a single shabad: whole shabad in range
            n = len(track["lines"])
            self.tracker = BaniTracker(track, back=n, ahead=n, min_track=6.0,
                                       min_cold=8.0, lost_after=2)
            self.tracker.pos = None
        else:
            self.tracker = BaniTracker(track)
            self.tracker.pos = None
        self.outbox.append({"type": "track", "track": {k: v for k, v in track.items()}})

    def _cand(self, sid: int, score: float) -> dict:
        m = self.res.meta.get(str(sid), {})
        return {"sid": sid, "score": round(score), "first_line": self.res.phrase.first_line.get(sid, ""),
                "where": _where(m)}

    def _emit(self) -> list[dict]:
        pos = self.tracker.pos if self.tracker else None
        confirmed = pos
        if (pos is not None and self.mode == "paath" and self.predict_enabled
                and getattr(self, "_shown", None) is not None):
            pos = self._shown
        if pos is not None:
            self.last_pos = pos
        next_pos = None
        if pos is not None and self.tracker:
            if hasattr(self.tracker, "expected_next") and self.tracker.pos == pos:
                next_pos = self.tracker.expected_next()
            elif pos + 1 < len(self.tracker.lines):
                next_pos = pos + 1
        prev = None
        if self.mode == "kirtan" and self.recent:
            r = self.recent[0]
            prev = self._cand(r["sid"], 0)
        msg = {"type": "state", "t": round(self.t, 1), "mode": self.mode, "status": self.status,
               "status_text": STATUS_TEXT[self.status], "held_by_user": self.held_by_user,
               "heard": self.heard, "track_id": self.track["id"] if self.track else None,
               "pos": pos, "confirmed_pos": confirmed, "last_pos": getattr(self, "last_pos", None), "total": len(self.tracker.lines) if self.tracker else 0,
               "confidence": self.confidence, "candidates": self.candidates,
               "suggestion": self.suggestion, "next_pos": next_pos, "previous": prev, "sehaj": self.sehaj,
               "akv": self._akv_state()}
        out, self.outbox = self.outbox + [msg], []
        return out
