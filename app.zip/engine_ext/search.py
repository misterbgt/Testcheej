"""
GurbaniSearch - manual search for the sewadar (console and phone).

Four ways to search, picked automatically or by hand:

  first letters   ਸਬਤਸ, or the same typed on an English keyboard ("sbqs" in the
                  SikhiToTheMax / AnmolLipi layout; plain "sbts" works too, as
                  ਤ/ਟ, ਦ/ਡ, ਨ/ਣ ... and all vowel letters are treated alike)
  words           Gurmukhi words (ਸਚੀ ਬੈਸਕ) or the words in English letters
                  (sachi baisak), spelling need not be exact
  English         words from the English translation (true friends)

Covers every line of Sri Guru Granth Sahib Ji, Vaaran and Kabit Savaiye Bhai
Gurdas Ji and Ghazals Bhai Nand Lal Ji, plus the lines of the banis (Jaap
Sahib, Chaupai Sahib, Tav Prasad Savaiye ...) that are not in them.
"""
from __future__ import annotations

import re

from rapidfuzz import fuzz, process

from .phrase_matcher import words_of

VOWEL = "ਅ"
FOLD_LETTER = {
    "ਟ": "ਤ", "ਠ": "ਥ", "ਡ": "ਦ", "ਢ": "ਧ", "ਣ": "ਨ", "ਞ": "ਨ", "ਙ": "ਨ",
    "ਸ਼": "ਸ", "ਖ਼": "ਖ", "ਗ਼": "ਗ", "ਜ਼": "ਜ", "ਫ਼": "ਫ", "ਲ਼": "ਲ",
}
for v in "ਅਆਇਈਉਊਏਐਓਔੲੳ":
    FOLD_LETTER[v] = VOWEL
# English keyboard -> first letter (SikhiToTheMax / AnmolLipi layout, plus the
# obvious phonetic letters that layout leaves free)
KEYS = {
    "a": VOWEL, "A": VOWEL, "e": VOWEL, "E": VOWEL, "i": VOWEL, "I": VOWEL, "o": VOWEL, "O": VOWEL,
    "u": VOWEL, "U": VOWEL,
    "s": "ਸ", "S": "ਸ", "h": "ਹ", "H": "ਹ", "k": "ਕ", "K": "ਖ", "g": "ਗ", "G": "ਘ",
    "c": "ਚ", "C": "ਛ", "j": "ਜ", "J": "ਝ", "z": "ਜ", "Z": "ਗ", "t": "ਤ", "T": "ਥ",
    "f": "ਦ", "F": "ਧ", "x": "ਨ", "q": "ਤ", "Q": "ਥ", "d": "ਦ", "D": "ਧ", "n": "ਨ", "N": "ਨ",
    "p": "ਪ", "P": "ਫ", "b": "ਬ", "B": "ਭ", "m": "ਮ", "M": "ਮ", "X": "ਯ", "y": "ਯ", "Y": "ਯ",
    "r": "ਰ", "R": "ਰ", "l": "ਲ", "L": "ਲ", "v": "ਵ", "V": "ੜ", "w": "ਵ", "W": "ਵ",
    "^": "ਖ", "&": "ਫ", "|": "ਨ", "\\": "ਨ",
}
GURMUKHI = re.compile(r"[\u0A00-\u0A7F]")
MATRA = re.compile(r"[\u0A3E-\u0A4D\u0A70\u0A71\u0A02\u0A01\u0A03\u0A51\u0A75]")
DIGIT = set("੦੧੨੩੪੫੬੭੮੯0123456789")


def fold_letter(ch: str) -> str:
    return FOLD_LETTER.get(ch, ch)


def first_letters(text: str) -> str:
    out = []
    for w in text.replace("॥", " ").split():
        w = w.replace("\u0A3C", "")                     # nukta
        if not w or w[0] in DIGIT or w.startswith("ੴ") or not GURMUKHI.match(w[0]):
            continue
        out.append(fold_letter(w[0]))
    return "".join(out)


LATIN_VOWEL = {"a": "ਅ", "A": "ਅ", "e": "ੲ", "E": "ੲ", "i": "ੲ", "I": "ੲ", "o": "ੳ", "O": "ੳ", "u": "ੳ", "U": "ੳ"}
BEARER = {**{v: "ਅ" for v in "ਆਐਔ"}, **{v: "ੲ" for v in "ਇਈਏ"}, **{v: "ੳ" for v in "ਉਊਓ"}}


def raw_first_letters(text: str) -> str:
    """First letters as written (vowels by their bearer, as in SikhiToTheMax:
    ਆਵਹੁ ਮੀਤ ਇਕਤ੍ਰ ਹੋਇ -> ਅਮੲਹ), to rank exact matches first."""
    out = []
    for w in text.replace("॥", " ").split():
        if w and w[0] not in DIGIT and not w.startswith("ੴ") and GURMUKHI.match(w[0]):
            out.append(BEARER.get(w[0], w[0]))
    return "".join(out)


def query_letters(q: str) -> str:
    """The first letters the user meant, from Gurmukhi or English keys."""
    out = []
    for ch in q.replace(" ", ""):
        if GURMUKHI.match(ch):
            if not MATRA.match(ch) and ch not in DIGIT and ch != "\u0A3C":
                out.append(fold_letter(ch))
        elif ch in KEYS:
            out.append(KEYS[ch])
    return "".join(out)


def roman(text: str) -> str:
    t = text.lower().replace("(n)", "n")
    t = re.sub(r"[^a-z ]+", " ", t)
    for a, b in (("aa", "a"), ("ee", "i"), ("oo", "u"), ("w", "v"), ("sh", "s"), ("ph", "f")):
        t = t.replace(a, b)
    t = re.sub(r"(.)\1+", r"\1", t)                     # doubled letters
    return re.sub(r"\s+", " ", t).strip()


def plain(text: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z']+", " ", text.lower())).strip()


def gur_words(text: str) -> str:
    return " ".join(words_of(text))


class GurbaniSearch:
    def __init__(self, corpus, meta: dict, banis: dict, first_line: dict):
        self.meta, self.banis = meta, banis
        self.rows: list[dict] = []
        seen = set()
        for sid in corpus.shabads:
            for i, ln in enumerate(corpus.get_lines(sid)):
                g = (ln.get("gurmukhi") or {}).get("unicode") or ln.get("unicode", "")
                if not g:
                    continue
                seen.add((sid, g))
                self.rows.append({"kind": "shabad", "sid": sid, "pos": i, "g": g,
                                  "tr": ln.get("transliteration_english") or "",
                                  "en": ln.get("translation_english") or ""})
        for b in banis.values():                        # bani lines outside SGGS (Dasam Bani...)
            for i, ln in enumerate(b["lines"]):
                if (ln.get("sid"), ln["g"]) in seen or not ln["g"]:
                    continue
                seen.add((ln.get("sid"), ln["g"]))
                self.rows.append({"kind": "bani", "bani_id": b["id"], "sid": ln.get("sid"), "pos": i,
                                  "g": ln["g"], "tr": ln.get("tr") or "", "en": ln.get("en") or ""})
        self.fl = [first_letters(r["g"]) for r in self.rows]
        self.raw_fl = [raw_first_letters(r["g"]) for r in self.rows]
        self.gw = [gur_words(r["g"]) for r in self.rows]
        self.ro = [roman(r["tr"]) for r in self.rows]
        self.en = [plain(r["en"]) for r in self.rows]
        self.first_line = first_line

    # ------------------------------------------------------------------ modes
    def guess_mode(self, q: str) -> str:
        if GURMUKHI.search(q):
            has_matra = bool(MATRA.search(q))
            return "words" if (" " in q.strip() or has_matra) else "letters"
        toks = q.split()
        if len(toks) == 1 and 2 <= len(toks[0]) <= 10 and not re.search(r"[aeiou]{2}", toks[0].lower()):
            vowels = sum(c in "aeiouAEIOU" for c in toks[0])
            if vowels <= len(toks[0]) // 3:
                return "letters"
        return "words"

    def search(self, q: str, mode: str = "auto", limit: int = 25) -> dict:
        q = (q or "").strip()
        if not q:
            return {"mode": mode, "items": []}
        if mode == "latin":                            # "English" on the page: translation, or words/letters in English letters
            mode = "auto"
        if mode == "letters":
            hits, m = self._letters(q, limit), "letters"
        elif mode == "english":
            hits, m = self._english(q, limit), "english"
        elif mode == "words":
            hits, m = self._words(q, limit), "words"
        elif GURMUKHI.search(q):                       # auto, Gurmukhi typed
            m = self.guess_mode(q)
            hits = self._letters(q, limit) if m == "letters" else self._words(q, limit)
        else:                                          # auto, English keyboard: try all three
            letters = self._letters(q, limit) if len(q.split()) == 1 and len(q) <= 12 else []
            strong = [h for h in letters if h[1] >= 95]
            m = "letters" if strong else "words"
            pool: dict[int, float] = {}
            for i, sc in self._words(q, limit) + self._english(q, limit):
                pool[i] = max(pool.get(i, 0.0), sc)
            rest = sorted(((i, sc) for i, sc in pool.items() if i not in dict(strong)), key=lambda x: -x[1])
            hits = strong + rest                       # letter matches first when there are any
        return {"mode": m, "items": [self._item(i, s) for i, s in hits[:limit]]}

    def _letters(self, q, limit):
        exact_key = "".join(BEARER.get(ch, ch) for ch in q if GURMUKHI.match(ch) and not MATRA.match(ch) and ch not in DIGIT)
        if not exact_key:                              # English keys: vowels by their bearer (a -> ਅ, i/e -> ੲ, u/o -> ੳ)
            exact_key = "".join(LATIN_VOWEL.get(ch, KEYS.get(ch, "")) for ch in q.replace(" ", ""))
        key = query_letters(q)
        if len(key) < 2:
            return []
        hits = []
        for i, f in enumerate(self.fl):
            j = f.find(key)
            if j < 0:
                continue
            exact = bool(exact_key) and self.raw_fl[i].find(exact_key) == j
            hits.append((i, (100.0 if j == 0 else 80.0 - min(j, 20)) - (0 if exact or not exact_key else 5)))
        if len(key) >= 4 and len(hits) < limit:
            # Near matches: the line has a word or two more than typed, often just
            # a different word division (ਗੁਰਸਿਖ / ਗੁਰ ਸਿਖ between SikhiToTheMax and
            # Shabad OS) - at most one extra letter between two typed ones, two in all.
            have = {i for i, _ in hits}
            pat = re.compile(".?".join(re.escape(c) for c in key))
            for i, f in enumerate(self.fl):
                if i in have:
                    continue
                m = pat.search(f)
                if m is None:
                    continue
                extra = (m.end() - m.start()) - len(key)
                if 0 < extra <= 2:
                    hits.append((i, (70.0 if m.start() == 0 else 55.0 - min(m.start(), 20)) - 5 * extra))
        hits.sort(key=lambda x: -x[1])
        return hits[:limit]

    def _words(self, q, limit):
        if GURMUKHI.search(q):
            qn, pool = gur_words(q), self.gw
        else:
            qn, pool = roman(q), self.ro
        if len(qn) < 2:
            return []
        res = process.extract(qn, pool, scorer=fuzz.partial_ratio, limit=limit * 4, score_cutoff=72)
        out, raw = [], " ".join(q.split()) if GURMUKHI.search(q) else None
        for _, sc, i in res:
            sc = sc * min(1.0, len(pool[i]) / max(1, len(qn))) ** 0.5    # a short line inside the query is a weak match
            sc += 4 if qn in pool[i] else 0
            if raw and raw in self.rows[i]["g"]:      # spelt exactly as typed, vowel signs and all
                sc += 6 if self.rows[i]["g"].startswith(raw) else 4
            out.append((i, sc))
        out.sort(key=lambda x: -x[1])
        return out[:limit]

    def _english(self, q, limit):
        qp = plain(q)
        words = [w for w in qp.split() if len(w) >= 3] or [qp]
        hits = []
        for i, e in enumerate(self.en):
            if all(w in e for w in words):
                hits.append((i, 90.0 + (8.0 if qp in e else 0.0) + 0.02 * fuzz.partial_ratio(qp, e)))
        if len(hits) < limit:
            have = {i for i, _ in hits}
            more = process.extract(qp, self.en, scorer=fuzz.partial_ratio, limit=limit, score_cutoff=80)
            hits += [(i, s - 20) for _, s, i in more if i not in have]
        hits.sort(key=lambda x: -x[1])
        return hits[:limit]

    def _item(self, i: int, score: float) -> dict:
        r = self.rows[i]
        if r["kind"] == "shabad":
            m = self.meta.get(str(r["sid"]), {})
            where = m.get("where") or (f"Ang {m.get('ang')}, {m.get('raag')}, {m.get('writer')}" if m else "")
            return {"kind": "shabad", "sid": r["sid"], "pos": r["pos"], "g": r["g"], "en": r["en"],
                    "where": where, "score": round(score)}
        b = self.banis[r["bani_id"]]
        return {"kind": "bani", "bani_id": r["bani_id"], "sid": r["sid"], "pos": r["pos"], "g": r["g"],
                "en": r["en"], "where": b["name"], "score": round(score)}
