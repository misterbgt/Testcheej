"""
Asa Ki Vaar kirtan: follow the Vaar in the order it is sung.

How it is sung: any opening shabad first; then for each of the 24 pauris, chhant n
(sung, its lines repeated), the saloks of pauri n (read or sung through - never
skipped), and pauri n itself (sung; sometimes read again). After a pauri a shabad
may be sung, and then the next chhant. After the 24th pauri the Vaar is over
(Anand Sahib usually follows).

Sri Guru Granth Sahib Ji has the chhants (Ang 448-451) apart from the Vaar (Ang
462-475), and every salok and pauri is a shabad of its own, so following shabad by
shabad, as ordinary kirtan is followed, keeps falling behind. data/banis.json (bani
13) has them in the order they are sung; AkvFollower follows that list one part at a
time: it looks for the words heard in the part being sung (its lines are sung again, the
pauri is read again) and on into the next part, never further, so a salok is never
jumped over and a line sung again never sends the screen back to an earlier part.

Parts are found from the bani's own headings (ਸਲੋਕੁ ਮਃ ੧ ॥, ਪਉੜੀ ॥) and the chhants'
shabads; nothing is added to what the sangat sees.
"""
from __future__ import annotations

import re

import numpy as np

from .phrase_matcher import words_of
from .shabad_follower import ShabadFollower, MIN_TAIL

AKV_BANI = 13
CHHANT_SIDS = range(1656, 1662)             # Asa Mahala 4 Chhant Ghar 4: the 24 chhants
NUM_END = re.compile(r"॥\s*[੦-੯]+\s*॥")
SALOK_HEAD = re.compile(r"^(ਸਲੋਕੁ?|ਮਃ|ਮਹਲਾ)\s")
# head starts, in alignment points (one clearly heard word = 2 points)
STAY, NEXT, AHEAD_STEP, AHEAD_MOST, NEXT_PART, EARLIER_PART, MIN_TRACK = 1.0, 2.0, 0.5, 3.0, 2.0, 3.0, 6.0
NEXT_PART_LINES = 3                         # how far into the next part the search reaches
AHEAD_MIN, AHEAD_LEAD = 8.0, 4.0           # further on than that: words in order, and clearly better
CATCH_SOFT, CATCH_LEAD, CATCH_RUN = 4.0, 2.0, 3   # catching up on weaker words: the same part, checks running
SURE_PART = 8.0                             # a part is sure once two of its lines, or four words of one in order, matched


class Part:
    __slots__ = ("kind", "n", "start", "end", "first")

    def __init__(self, kind: str, n: int, start: int):
        self.kind, self.n, self.start, self.end, self.first = kind, n, start, start, start

    def __repr__(self):
        return f"{self.kind} {self.n} [{self.start}-{self.end}]"


def parts_of(lines: list[dict]) -> tuple[list[Part], set]:
    """The parts (chhant, each salok, pauri) of each of the 24 pauris, and the
    heading lines (not sung)."""
    parts: list[Part] = []
    heads: set[int] = set()
    n = 0
    for i, ln in enumerate(lines):
        g = ln.get("g", "")
        chhant = ln.get("sid") in CHHANT_SIDS
        head = ln.get("type") in ("Sirlekh", "Manglacharan")
        if head:
            heads.add(i)
        cur = parts[-1] if parts else None
        if chhant:
            if cur is None or cur.kind != "chhant":
                n += 1
                cur = Part("chhant", n, i)
                parts.append(cur)
        elif cur is None or cur.kind == "chhant":
            cur = Part("salok", n, i)                 # the Vaar part of this pauri begins
            parts.append(cur)
        elif head and g.startswith("ਪਉੜੀ"):
            cur = Part("pauri", n, i)
            parts.append(cur)
        elif head and SALOK_HEAD.match(g) and not all(j in heads for j in range(cur.start, i)):
            cur = Part("salok", n, i)                 # (headings in a row stay one part: "ੴ ... ਸਲੋਕੁ ਮਃ ੧ ॥")
            parts.append(cur)
        cur.end = i
    for p in parts:
        p.first = next((i for i in range(p.start, p.end + 1) if i not in heads), p.start)
    return parts, heads


class AkvFollower:
    """Follows Asa Ki Vaar (bani 13) one part at a time."""

    def __init__(self, track: dict):
        self.track = track
        self.lines = track["lines"]
        self.parts, self.heads = parts_of(self.lines)
        self.part_at = np.zeros(len(self.lines), dtype=np.int32)
        for k, p in enumerate(self.parts):
            self.part_at[p.start:p.end + 1] = k
        self.words = [w for ln in self.lines for w in words_of(ln["g"])]      # for coverage checks
        self.pos: int | None = None
        self.misses = 0
        self.strength = 0.0
        self.high: int | None = None
        self._win: tuple | None = None          # (lo, hi, ShabadFollower over lines lo..hi)
        self._ahead: tuple | None = None        # the same, for the lines after the window to the next chhant's end
        self.part_hits = self.part_misses = 0   # checks that matched / missed since the screen came into this part (counted by the console)
        self.part_lines: set = set()            # lines of this part matched, and the best match
        self.part_best = 0.0
        self.came_from: int | None = None       # the part it came from
        self._lean: list = []                   # later parts the unmatched words weakly pointed to

    # ---------------------------------------------------------------- places
    def part(self, i: int | None = None) -> Part | None:
        i = self.pos if i is None else i
        return None if i is None else self.parts[int(self.part_at[i])]

    def pauri_no(self, i: int | None = None) -> int | None:
        p = self.part(i)
        return p.n if p else None

    def shakka_start(self, n: int) -> int:
        """First sung line of pauri n's chhant."""
        return next(p.first for p in self.parts if p.n == n and p.kind == "chhant")

    def next_chhant(self) -> int | None:
        """Where the Vaar carries on after the current pauri: the next chhant."""
        n = self.pauri_no()
        if n is None or n >= 24:
            return None
        return self.shakka_start(n + 1)

    def resume_line(self) -> int | None:
        """Where the Vaar carries on after a shabad sung in between: after a pauri, the
        next chhant. A shabad is not sung after a chhant, so if the screen had moved on
        into a chhant, that was the shabad's words: the same chhant. In the saloks
        (the screen had lost its place), where it was."""
        p = self.part()
        if p is None:
            return None
        if p.kind == "pauri":
            return self.next_chhant()
        if p.kind == "chhant":
            return p.first
        return self.pos

    def unsure_chhant(self) -> bool:
        """Just moved on from a pauri into the next chhant, and since then more checks
        have missed than matched, or only a few words of one line have matched (sung
        over and over): perhaps a shabad sung after the pauri, with some of the chhant's
        words."""
        p = self.part()
        if not (p is not None and p.kind == "chhant" and self.came_from is not None
                and self.parts[self.came_from].kind == "pauri"):
            return False
        return self.part_misses >= self.part_hits or (len(self.part_lines) < 2 and self.part_best < SURE_PART)

    def at_end(self) -> bool:
        """In the last pauri, at its last lines."""
        p = self.part()
        return p is not None and p.n == 24 and p.kind == "pauri" and self.pos >= p.end - 1

    def in_pauri(self) -> bool:
        p = self.part()
        return p is not None and p.kind == "pauri"

    def next_sung(self, i: int) -> int | None:
        for j in range(i + 1, len(self.lines)):
            if j not in self.heads:
                return j
        return None

    def expected_next(self) -> int | None:
        return None if self.pos is None else self.next_sung(self.pos)

    # ---------------------------------------------------------------- search window
    def _window(self):
        """Lines searched: the part being sung (its lines may be sung again), a few
        lines into the next part, and the last lines of the part before (in case the
        screen moved on a moment too soon)."""
        k = int(self.part_at[self.pos])
        cur = self.parts[k]
        lo = cur.start
        if k > 0:
            prev = [i for i in range(self.parts[k - 1].start, self.parts[k - 1].end + 1) if i not in self.heads]
            lo = prev[-2] if len(prev) >= 2 else self.parts[k - 1].start
        hi = cur.end
        if k + 1 < len(self.parts):
            nxt = self.parts[k + 1]
            hi = min(nxt.end, nxt.first + NEXT_PART_LINES - 1)
        if self._win is None or self._win[:2] != (lo, hi):
            sub = {"lines": self.lines[lo:hi + 1]}
            f = ShabadFollower(sub)
            f.header = {i - lo for i in self.heads if lo <= i <= hi}
            f.rahao, f.stanza_end = set(), set()
            self._win = (lo, hi, f)
        return self._win

    def _ahead_window(self, hi: int):
        """The lines after the search window, to the end of the next chhant: the singing
        may have got there while the screen did not follow (a salok sung too unclearly
        to match)."""
        k = int(self.part_at[self.pos])
        later = [p for p in self.parts[k + 1:] if p.kind == "chhant"]
        end = later[0].end if later else len(self.lines) - 1
        if end <= hi:
            return None
        if self._ahead is None or self._ahead[:2] != (hi + 1, end):
            f = ShabadFollower({"lines": self.lines[hi + 1:end + 1]})
            f.header = {i - hi - 1 for i in self.heads if hi < i <= end}
            f.rahao, f.stanza_end = set(), set()
            self._ahead = (hi + 1, end, f)
        return self._ahead

    def _bonus(self, lo: int, hi: int) -> np.ndarray:
        b = np.zeros(hi - lo + 1, dtype=np.float32)
        p = self.pos
        k = int(self.part_at[p])
        cur = self.parts[k]
        nxt = self.next_sung(p)
        last_lines = [i for i in range(cur.first, cur.end + 1) if i not in self.heads][-2:]
        for i in range(lo, hi + 1):
            v = 0.0
            if i == p:
                v = STAY
            elif i == nxt:
                v = NEXT
            elif self.part_at[i] == k:
                if i > p:                                  # further on in this part: a little less likely
                    v = -min(AHEAD_MOST, AHEAD_STEP * (i - p - 1))
            elif self.part_at[i] > k:                      # the next part
                near_end = p in last_lines
                v = (NEXT_PART if i == self.parts[k + 1].first else 0.0) if near_end else -NEXT_PART
            else:                                          # the end of the part before
                v = -EARLIER_PART
            b[i - lo] = v
        return b

    # ---------------------------------------------------------------- following
    def place(self, i: int):
        old = int(self.part_at[self.pos]) if self.pos is not None else None
        self.pos = max(0, min(int(i), len(self.lines) - 1))
        if self.pos in self.heads:
            self.pos = self.next_sung(self.pos) or self.pos
        if int(self.part_at[self.pos]) != old:
            self.came_from, self.part_hits, self.part_misses, self._lean = old, 0, 0, []
            self.part_lines, self.part_best = set(), 0.0
        self.high = self.pos if self.high is None else max(self.high, self.pos)
        self.misses = 0

    def step(self, delta: int) -> dict:
        i = self.pos if self.pos is not None else 0
        step = 1 if delta > 0 else -1
        for _ in range(abs(int(delta))):
            j = i + step
            while 0 <= j < len(self.lines) and j in self.heads:
                j += step
            if 0 <= j < len(self.lines):
                i = j
        self.place(i)
        return self._event("manual", f"{delta:+d}")

    def next_part(self):
        """Sewadar: on to the next part (the saloks, the pauri, the next chhant)."""
        k = int(self.part_at[self.pos]) if self.pos is not None else -1
        if k + 1 < len(self.parts):
            self.place(self.parts[k + 1].first)

    def update(self, transcript: str) -> dict:
        q = words_of(transcript)
        if len(q) < 3:
            return self._event("hold", "quiet")
        if self.pos is None:
            self.place(self.parts[0].first)
        lo, hi, f = self._window()
        full, tail = f._line_scores(q)
        ahead = self._ahead_window(hi)
        if ahead is not None:                          # clearly further on than the screen?
            afull, _ = ahead[2]._line_scores(q)
            j = int(np.argmax(afull))
            if afull[j] >= AHEAD_MIN and afull[j] >= full.max() + AHEAD_LEAD:
                self.strength = 0.0
                self.place(ahead[0] + j)
                return self._event("tracking", f"further on {afull[j]:.0f}")
        bonus = self._bonus(lo, hi)
        choice, why = None, ""
        if tail.max() >= MIN_TAIL:
            ok = tail >= MIN_TAIL
            choice = int(np.argmax(np.where(ok, tail + bonus, -1e9)))
            why = f"now {tail[choice]:.0f}"
        elif full.max() >= MIN_TRACK:
            ok = full >= MIN_TRACK
            choice = int(np.argmax(np.where(ok, full + bonus, -1e9)))
            why = f"window {full[choice]:.0f}"
        if choice is None:
            self.misses += 1
            self.strength = 0.0
            return self._event("hold", "no match")
        self.strength = float(tail[choice])
        self.place(lo + choice)
        self._lean = []
        self.part_lines.add(self.pos)
        self.part_best = max(self.part_best, float(full[choice]), float(tail[choice]))
        return self._event("tracking", why)

    def quick(self, transcript: str) -> int | None:
        """Words of another nearby line were just heard (see ShabadFollower.quick):
        that line, if it is this part or the start of the next."""
        if self.pos is None:
            return None
        lo, hi, f = self._window()
        f.pos = self.pos - lo
        new = f.quick(transcript)
        if new is None:
            return None
        i = lo + new
        k, cur = int(self.part_at[i]), int(self.part_at[self.pos])
        if k < cur:
            return None                      # the part before: wait for the main check
        if k > cur and i != self.parts[cur + 1].first and i != self.next_sung(self.pos):
            return None                      # into the next part only at its first line
        return i

    def catch_up(self, transcript: str, min_score: float = 10.0) -> bool:
        """Nothing heard has matched for a while: the singing may have moved on further
        than the screen (a salok read quickly, a part missed). Look from the part on
        screen to the end of the next chhant, and move there on a clear match (five
        words or more in order) - or on weaker ones (two or three words), better than
        anything in the part on screen, pointing to the same later part CATCH_RUN
        checks running (sangat singing heard unclearly)."""
        q = words_of(transcript)
        if self.pos is None or len(q) < 4:
            return False
        k = int(self.part_at[self.pos])
        lo = self.parts[k].start
        later = [p for p in self.parts[k + 1:] if p.kind == "chhant"]
        hi = later[0].end if later else len(self.lines) - 1
        f = ShabadFollower({"lines": self.lines[lo:hi + 1]})
        f.header = {i - lo for i in self.heads if lo <= i <= hi}
        full, _ = f._line_scores(q)
        if not len(full):
            return False
        j = int(np.argmax(full))
        kj = int(self.part_at[lo + j])
        if full[j] >= min_score and kj != k:
            self.place(lo + j)
            return True
        here = float(full[:self.parts[k].end - lo + 1].max())
        self._lean = (self._lean + [kj if kj > k and full[j] >= CATCH_SOFT and full[j] >= here + CATCH_LEAD
                                    else None])[-CATCH_RUN:]
        if len(self._lean) == CATCH_RUN and self._lean[0] is not None and len(set(self._lean)) == 1:
            self.place(lo + j)
            return True
        return False

    def match_score(self, transcript: str, lo: int, hi: int) -> float:
        """Best in-order alignment of the words heard inside lines lo..hi."""
        q = words_of(transcript)
        if len(q) < 3:
            return 0.0
        f = ShabadFollower({"lines": self.lines[lo:hi + 1]})
        f.header = {i - lo for i in self.heads if lo <= i <= hi}
        full, _ = f._line_scores(q)
        return float(full.max()) if len(full) else 0.0

    def find(self, sid: int, text: str = "") -> int | None:
        """The line of shabad sid (best by its words) - to carry on from a shabad
        that was being followed on its own."""
        idx = [i for i, ln in enumerate(self.lines) if ln.get("sid") == sid and i not in self.heads]
        if not idx:
            return None
        if text:
            w = set(words_of(text))
            best = max(idx, key=lambda i: (len(w & set(words_of(self.lines[i]["g"]))), -i))
            if w & set(words_of(self.lines[best]["g"])):
                return best
        return idx[0]

    def _event(self, state: str, why: str) -> dict:
        ln = self.lines[self.pos] if self.pos is not None else None
        return {"state": state, "why": why, "pos": self.pos, "total": len(self.lines), "line": ln}

    def summary(self) -> dict | None:
        """For the console: which pauri, which part, and where each pauri starts."""
        p = self.part()
        if p is None:
            return None
        return {"pauri": p.n, "part": p.kind, "of": 24}
