"""Paath, for ConsoleSession (engine_ext/console_session.py): banis in their lengths,
Akhand / Sehaj Paath through Sri Guru Granth Sahib Ji (engine_ext/sehaj.py), and moving
the screen on at the reader's pace between checks."""
from __future__ import annotations

from .bani_tracker import BaniTracker
from .blend import gated_rank
from .heard import MIN_CLEAR_TO_LEAVE, clear_words
from .sehaj import SehajTracker
from .simran import is_simran

# Akhand / Sehaj Paath: checks without a match before options are offered; a place
# confirmed fewer than SEHAJ_ESTABLISHED times is given up after SEHAJ_RETRY misses.
SEHAJ_OFFER, SEHAJ_ESTABLISHED, SEHAJ_RETRY = 8, 4, 5
# The reader keeps reading when a check fails to match (unclear words), so the screen
# keeps moving at the reader's pace, up to SEHAJ_PRED_MAX lines beyond the last
# confirmed line; it only waits when there are no words at all.
SEHAJ_PRED_MAX = 3
# Unsure for SEHAJ_REFIND checks in a row (no strong match - the reader stepped away from
# the microphone, or a false match put the screen in the wrong place): look across the
# whole Granth, as a fresh start would, and move there once the same place is heard
# again and again (as when identifying from the start).
SEHAJ_REFIND = 6
# ... sooner when the place was itself found again a moment ago (it may have followed
# some other reading the microphone picked up): the reader's place can come straight back
SEHAJ_REFIND_SOON, SEHAJ_SOON_S = 4, 180.0
# Paath (a bani, or a single shabad): the place lost for PAATH_REFIND checks in a row while
# words are clearly heard (the reading moved on, or kirtan began with Paath still chosen):
# identify what is heard now, as at the start, and follow that.
PAATH_REFIND = 6


class PaathMixin:
    def _paath_refind(self, transcript: str) -> bool:
        """The place has been lost for a while in Paath: which shabad is being read (or
        sung) now? Move there once the same one comes top in checks running, as when
        identifying from the start (a shabad of the bani on screen: the place in it)."""
        if self._lost_n < PAATH_REFIND:
            self._paath_found = (None, 0, False)
            return False
        if clear_words(transcript) < MIN_CLEAR_TO_LEAVE:
            return False
        pr = self.res.phrase.rank(transcript, 10)
        ranked = gated_rank(self.res.base.find_candidates(transcript, top_k=10), pr)
        if not ranked:
            self._paath_found = (None, 0, False)
            return False
        top = ranked[0][0]
        confident = bool(pr) and pr[0][0] == top and pr[0][1] >= 35 and \
            (pr[0][1] - (pr[1][1] if len(pr) > 1 else 0)) >= 10
        prev, n, had = getattr(self, "_paath_found", (None, 0, False))
        n = n + 1 if top == prev else 1
        had = (had if top == prev else False) or confident
        self._paath_found = (top, n, had)
        if not ((n >= 2 and had) or n >= 3):
            return False
        self._paath_found = (None, 0, False)
        self._lock_shabad(int(top), transcript)
        self._lost_n = 0
        self.found_again = f"paath: found what is being read again: shabad {top}"
        return True

    def _other_length(self, transcript: str) -> bool:
        """Paath of Rehras, Chaupai, Sohila or Aarti, and the reader's words are not in
        this length of it: if they are clearly in another length, follow that one."""
        if self.mode != "paath" or not self.track or self.track.get("kind") != "bani":
            return False
        cur = self.track["bani_id"]
        for v in self.res.variants(cur):
            if v == cur:
                continue
            t = BaniTracker(self.res.bani_track(v))
            if t.update(transcript)["state"] == "locked":
                self.bani_id = v
                self._load_track(self.res.bani_track(v))
                self.tracker.pos = t.pos
                self.status, self.confidence, self._lost_n = "following", "high", 0
                self.outbox.append({"type": "notice", "message": f"Following {self.res.banis[v]['name']}: "
                                    "the words being read are in that length of the bani."})
                return True
        return False

    def _preferred_length(self, bid: int, sid: int) -> int:
        """Rehras, Chaupai, Sohila and Aarti are read in several lengths: the one chosen
        in the settings, when it has this shabad."""
        have = self.res.sid_banis.get(str(sid)) or []
        # Chaupai and Aarti have no medium length of their own (SikhiToTheMax's is the
        # short one), and Aarti no extra long one here: the nearest length instead
        for want in {"medium": ("medium", "short"), "extra long": ("extra long", "long")}.get(
                self.bani_length, (self.bani_length,)):
            for v in self.res.variants(bid):
                if self.res.banis[v].get("length") == want and v in have:
                    return v
        return bid

    def _load_sehaj(self, sid: int, transcript: str = ""):
        self.last_pos = None
        self._conf, self._shown, self._floor, self._backed = [], None, None, False
        self._sehaj_lost = 0
        self.tracker = SehajTracker(self.res.granth, sid)
        self.tracker.pos = None
        if transcript:                                  # place the line from what was just read
            self.tracker.update(transcript)
        if self.tracker.pos is None:
            self.tracker.place_sid(sid, 0)
        self.tracker.take_shift()
        self._new_sehaj_track()

    def _new_sehaj_track(self):
        self.track = self.tracker.track()
        self.outbox.append({"type": "track", "track": dict(self.track)})

    def _sehaj_sync(self):
        """After the tracker may have moved its window: shift every stored line
        number and send the new lines to the screens."""
        if not isinstance(self.tracker, SehajTracker):
            return
        shift, moved = self.tracker.take_shift()
        if not moved:
            return
        if shift:
            n = len(self.tracker.lines) - 1
            fix = lambda p: None if p is None else max(0, min(p - shift, n))     # noqa: E731
            self._conf = [(a, fix(b)) for a, b in self._conf]
            self._shown, self._floor = fix(self._shown), fix(self._floor)
            self.last_pos = fix(getattr(self, "last_pos", None))
        self._new_sehaj_track()

    def _sehaj_follow(self, transcript: str, t: float):
        ev = self.tracker.update(transcript)
        self._sehaj_sync()
        st = ev["state"]
        need = SEHAJ_REFIND_SOON if t - getattr(self, "_refound_t", -1e9) <= SEHAJ_SOON_S else SEHAJ_REFIND
        if (self.tracker.doubt >= need and self.tracker.hits >= SEHAJ_ESTABLISHED
                and clear_words(transcript) >= 4 and self._sehaj_refind(transcript, t)):
            return
        if self.tracker.doubt < need:
            self._refind = (None, 0, False)
        if st in ("tracking", "locked"):
            self.status, self.confidence, self.candidates = "following", "high", []
            self._sehaj_lost = 0
            self._paath_confirm(t)
            return
        if st == "hold":
            if ev["why"] == "no match" and self.status in ("following", "searching_ahead"):
                self.confidence = "medium"              # words, but unclear: the reader is still reading
            elif self.status != "searching_ahead":
                self.status, self.confidence = "held_quiet", "medium"
            return
        # searching: the last line stays on screen while it looks further ahead
        self._sehaj_lost = getattr(self, "_sehaj_lost", 0) + 1
        self.status, self.confidence = "searching_ahead", "low"
        if self.tracker.hits < SEHAJ_ESTABLISHED and self._sehaj_lost >= SEHAJ_RETRY:
            # never really took hold: perhaps the wrong place - identify again
            self.tracker, self.track, self.status = None, None, "finding"
            self._streak = (None, 0, False)
            self._identify(transcript)
            return
        if self._sehaj_lost >= SEHAJ_OFFER and len(transcript.split()) >= 3:
            bc = self.res.base.find_candidates(transcript, top_k=10)     # offer options, never switch
            self.candidates = [self._cand(sid, sc) for sid, sc in gated_rank(bc, self.res.phrase.rank(transcript, 10))[:3]]

    def _sehaj_refind(self, transcript: str, t: float) -> bool:
        """Unsure for a while: which shabad of the Granth is being read? Move there when
        the same one (or the next one: the reader moves on) comes top in checks in a row."""
        G = self.res.granth
        pr = self.res.phrase.rank(transcript, 10)
        ranked = [(sid, sc) for sid, sc in gated_rank(self.res.base.find_candidates(transcript, top_k=10), pr)
                  if sid in G]
        if not ranked:
            self._refind = (None, 0, False)
            return False
        top = ranked[0][0]
        confident = bool(pr) and pr[0][0] == top and pr[0][1] >= 35 and \
            (pr[0][1] - (pr[1][1] if len(pr) > 1 else 0)) >= 10
        prev, n, had = getattr(self, "_refind", (None, 0, False))
        same = prev is not None and (top == prev or G.index[G.canonical(top)] - G.index[G.canonical(prev)] in (0, 1))
        n = n + 1 if same else 1
        had = (had if same else False) or confident
        self._refind = (top, n, had)
        if not ((n >= 2 and had) or n >= 3):
            return False
        before = self.tracker.where_now()
        self.tracker.relocate(int(top), transcript)
        self._sehaj_sync()
        self._refind = (None, 0, False)
        self._sehaj_lost = 0
        self.status, self.confidence, self.candidates = "following", "high", []
        self._conf, self._shown, self._floor, self._backed = [], None, None, False
        self._paath_confirm(t)
        self._refound_t = t
        self.found_again = f"found the place again: shabad {top} (was {before})"
        L = self.tracker.lines[self.tracker.pos]
        self.outbox.append({"type": "notice", "message": f"Found the reader's place again: Ang {L['ang']}."})
        return True

    def _sehaj_quick(self, transcript: str, t: float) -> list[dict]:
        if not self.wants_quick() or is_simran(transcript):
            return []
        new = self.tracker.quick(transcript)
        self._sehaj_sync()
        if new is None or new <= self.tracker.pos:
            return []
        self.tracker.pos, self.tracker.misses = new, 0
        self.tracker.keep_up()
        self._sehaj_sync()
        self.t = t
        self._paath_confirm(t)
        return self._emit()

    def _paath_confirm(self, t: float):
        """A check has confirmed the reader's line: settle what is on screen."""
        p = self.tracker.pos
        self._conf = [(a, b) for a, b in self._conf + [(t, p)] if t - a <= 45]
        shown = self._shown
        if shown is None or p >= shown:
            self._floor, self._backed = None, False
        elif shown - p <= 2 and not self._backed:
            self._floor, self._backed = shown, True      # slightly ahead: hold once, don't jump back
        else:
            self._floor, self._backed = None, False      # clearly behind: go back
        self._shown = self._predict(t)

    def _pace(self):
        """Seconds per line over the last ~45 s of confirmed progress."""
        if len(self._conf) < 3:
            return None
        (t0, p0), (t1, p1) = self._conf[0], self._conf[-1]
        if p1 - p0 < 3 or t1 <= t0:
            return None
        return min(8.0, max(1.2, (t1 - t0) / (p1 - p0)))

    def _moving(self) -> bool:
        return self.status == "following" or (self.in_sehaj and self.status == "searching_ahead")

    def _predict(self, t: float) -> int:
        t_c, p_c = self._conf[-1]
        pace, pred = self._pace(), p_c
        most = SEHAJ_PRED_MAX if self.in_sehaj else 2
        if pace and self._moving():                  # stays at the furthest line reached: never slides back
            dt = min(t - t_c, max(8.0, (most + 1) * pace))
            pred = p_c + min(most, int(dt / pace + 0.5))
        if self._floor is not None:
            if pred >= self._floor:
                self._floor = None
            else:
                pred = self._floor
        return min(pred, len(self.tracker.lines) - 1)

    def tick(self, t: float) -> list[dict]:
        """Call as audio arrives: moves the display ahead between checks (paath mode)."""
        if (not self.predict_enabled or self.mode != "paath" or self.held_by_user or not self._conf
                or self.tracker is None or self.tracker.pos is None or not self._moving()):
            return []
        new = self._predict(t)
        if new != self._shown:
            self._shown, self.t = new, t
            return self._emit()
        return []
