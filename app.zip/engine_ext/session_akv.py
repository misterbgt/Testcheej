"""Asa Ki Vaar in kirtan, and Anand Sahib's six pauris after it, for ConsoleSession
(engine_ext/console_session.py). The Vaar itself is followed by engine_ext/akv.py."""
from __future__ import annotations

from .akv import AkvFollower, AKV_BANI
from .blend import gated_rank
from .heard import MIN_CLEAR_TO_LEAVE, clear_words
from .phrase_matcher import words_of

# Asa Ki Vaar: two of its parts heard in sung order within AKV_SEEN_S start following the
# Vaar; a shabad sung after a pauri is put up once it is identified as surely as any
# shabad; the Vaar comes back when the next chhant is heard (AKV_RESUME points of words
# in order, or AKV_RESUME_SOFT in two checks running). Anand Sahib in kirtan (after the
# Vaar, or at any time) is followed as its 6 pauris and salok (bani ANAND_SIX).
AKV_RESUME_SOFT, AKV_RESUME_OTHERS = 4.5, True
# a chhant reached from a pauri on a few words, and a shabad with more of the words heard
# in order (at least AKV_RIVAL_MIN points) in AKV_RIVAL_OF of the last AKV_RIVAL_N checks
AKV_RIVAL_MIN, AKV_RIVAL_N, AKV_RIVAL_OF = 5.0, 5, 3
AKV_SEEN_S, AKV_RESUME, AKV_LOST_CHECKS, AKV_PAUSE_MAX_S, AKV_CATCH_UP = 900.0, 8.0, 8, 1800.0, 3


class AkvMixin:
    def akv_command(self, action: str, n: int | None = None):
        """Sewadar: start following Asa Ki Vaar (from the part on screen, or the
        beginning), go on to the next part, carry on with the Vaar after a shabad sung
        between pauris, go to pauri n, or end it."""
        if action == "start":
            if self.mode != "kirtan":
                self.sehaj = False
                self._set_mode("kirtan")
            probe, line = self._akv_probe(), None
            if self.akv is not None and not self.akv_paused:
                return self._emit()
            if self.track and self.track.get("kind") == "shabad" and self.track.get("sid") in self.res.akv_sids:
                pos = self.tracker.pos if self.tracker and self.tracker.pos is not None else None
                line = probe.find(self.track["sid"], self.track["lines"][pos]["g"] if pos is not None else self.heard)
            if line is None and self.akv is not None:
                line = self.akv.resume_line()
            if line is None:
                line = probe.shakka_start(1)
            if self.akv is not None:
                self._remember_current()
            self._akv_start(line)
        elif self.akv is None:
            return self._emit()
        elif action == "next":
            if self.akv_paused:
                nxt = self.akv.resume_line()
                if nxt is not None:
                    self._remember_current()
                    self._akv_start(nxt)
            else:
                self.akv.next_part()
                self.status, self._akv_miss = "following", 0
        elif action == "resume" and self.akv_paused:
            nxt = self.akv.resume_line()
            if nxt is not None:
                self._remember_current()
                self._akv_start(nxt)
        elif action == "pauri" and n is not None and 1 <= int(n) <= 24:
            if self.akv_paused:
                self._remember_current()
            self._akv_start(self.akv.shakka_start(int(n)))
        elif action == "end":
            self._akv_finish()
            self.track, self.tracker, self.last_pos = None, None, None
            self.status, self.candidates = "listening", []
        self.confidence = "manual"
        return self._emit()

    def _akv_probe(self) -> AkvFollower:
        """An Asa Ki Vaar follower used only to look places up."""
        probe = getattr(self.res, "_akv_probe", None)
        if probe is None:
            probe = self.res._akv_probe = AkvFollower(self.res.bani_track(AKV_BANI))
        return probe

    def _akv_start(self, line: int, transcript: str = ""):
        """Follow the Vaar from line (bani 13)."""
        if self.akv is None:
            self.akv = AkvFollower(self.res.bani_track(AKV_BANI))
        f = self.akv
        self.akv_paused, self._akv_miss, self._akv_rivals = False, 0, []
        f.place(line)
        self.track, self.tracker, self.last_pos = f.track, f, None
        self._conf, self._shown, self._floor, self._backed = [], None, None, False
        self.outbox.append({"type": "track", "track": {k: v for k, v in f.track.items()}})
        if transcript:
            f.update(transcript)
        self.status, self.confidence, self.candidates = "following", "high", []
        self._streak, self._ev, self.suggestion = (None, 0, False), [], None
        self._away, self._last_hit, self._last_ok, self._hits = 0, self.t, self.t, 0
        self._locked_at, self._sure = self.t, False

    def _akv_finish(self):
        self.akv, self.akv_paused, self._akv_seen, self._akv_miss = None, False, [], 0
        self._akv_end_t = self.t

    def _akv_lock(self, sid: int, transcript: str) -> bool:
        """A shabad was identified (or picked) in kirtan: is it part of Asa Ki Vaar, and
        is the Vaar being sung? True when that is dealt with here."""
        f = self.akv
        if f is not None and not self.akv_paused:
            if sid in self.res.akv_sids:              # a part of the Vaar: go there
                line = f.find(sid, transcript)
                if line is not None:
                    f.place(line)
                    self.status, self._akv_miss = "following", 0
                return True
            if f.pauri_no() == 24 and f.in_pauri():  # the Vaar is over
                self._akv_finish()
                return False
            self.akv_paused, self._akv_pause_t = True, self.t     # a shabad between pauris
            return False
        if f is not None:                             # paused: back to the Vaar?
            if sid not in self.res.akv_sids:
                return False
            line, back = f.find(sid, transcript), f.resume_line()
            if line is not None and back is not None and f.part_at[line] >= f.part_at[back]:
                self._remember_current()
                self._akv_start(line, transcript)
            return True
        if sid not in self.res.akv_sids:
            return False
        probe = self._akv_probe()
        line = probe.find(sid, transcript)
        seen = [(t0, l0) for t0, l0 in self._akv_seen if self.t - t0 <= AKV_SEEN_S]
        go = line is not None and any(l0 < line and probe.part_at[l0] != probe.part_at[line]
                                      and 0 <= probe.pauri_no(line) - probe.pauri_no(l0) <= 1 for _, l0 in seen)
        if line is not None:
            seen.append((self.t, line))
        self._akv_seen = seen[-8:]
        if not go:
            return False
        self._akv_start(line, transcript)
        self.outbox.append({"type": "notice", "message":
                            "Asa Ki Vaar: following it in the order it is sung (each chhant, its saloks, its pauri)."})
        return True

    def _akv_next_part(self, transcript: str) -> bool:
        """A part of Asa Ki Vaar is on screen as a shabad: if the words heard are the
        opening of the part sung after it (a chhant, then its first salok), the Vaar
        is being sung - follow it from there."""
        sid = self.track.get("sid")
        if sid not in self.res.akv_sids or self.tracker is None:
            return False
        probe = self._akv_probe()
        pos = self.tracker.pos if self.tracker.pos is not None else getattr(self.tracker, "first", 0)
        line = probe.find(sid, self.track["lines"][pos]["g"])
        if line is None:
            return False
        k = int(probe.part_at[line]) + 1
        if k >= len(probe.parts):
            return False
        nxt = probe.parts[k]
        hi = min(nxt.end, nxt.first + 2)
        texts = [x for x in (getattr(self, "_recent", None), transcript) if x]
        best = max((probe.match_score(x, nxt.first, hi) for x in texts), default=0.0)
        if best < AKV_RESUME or best <= self._aligns(sid, transcript) + 2:
            return False
        self._akv_seen = []
        self._akv_start(nxt.first, texts[0])
        self.outbox.append({"type": "notice", "message":
                            "Asa Ki Vaar: following it in the order it is sung (each chhant, its saloks, its pauri)."})
        return True

    def _akv_follow(self, transcript: str):
        f = self.akv
        ev = {"state": "none"}
        if getattr(self, "_recent", None):
            ev = f.update(self._recent)                 # freshest audio decides the line
        if ev["state"] != "tracking":
            ev = f.update(transcript)
        if ev["state"] == "tracking":
            self.status, self.confidence, self.candidates = "following", "high", []
            self._akv_miss, self._last_hit = 0, self.t
            f.part_hits += 1
            if f.unsure_chhant():                       # or a shabad sung after the pauri?
                if not self._akv_rival(transcript):
                    self._akv_identify(transcript, quiet=True)
            else:
                self._streak, self._akv_rivals = (None, 0, False), []
            return
        if len(transcript.split()) < 3 or clear_words(transcript) < MIN_CLEAR_TO_LEAVE:
            self.status = "held_quiet"
            return
        self._akv_miss += 1
        f.part_misses += 1
        self.status, self.confidence = "held_quiet", "medium"
        if self._akv_miss >= AKV_CATCH_UP and f.catch_up(transcript):
            self.status, self._akv_miss = "following", 0
            return
        # after a pauri a shabad may be sung (or the Vaar is over); in the middle of a
        # part, unmatched words are vichaar or a misheard line: keep the place. A chhant
        # only just reached from a pauri, and unsure since, may be that shabad.
        if f.unsure_chhant() and self._akv_rival(transcript):
            return
        if f.in_pauri() or f.unsure_chhant() or self._akv_miss >= AKV_LOST_CHECKS:
            self._akv_identify(transcript)

    def _akv_rival(self, transcript: str) -> bool:
        """The screen only just moved from a pauri into the next chhant, on a few words:
        does a shabad - sung after the pauri - explain the words better (more of them in
        order) than the chhant does, in AKV_RIVAL_OF of the last AKV_RIVAL_N checks? Then
        put it up (the Vaar waits, and carries on at this chhant)."""
        f = self.akv
        p = f.part()
        own = f.match_score(transcript, p.first, p.end)
        best, best_al = None, 0.0
        for sid, _ in [x for x in self.res.phrase.rank(transcript, 10) if x[0] not in self.res.akv_sids][:5]:
            al = self._aligns(sid, transcript)
            if al > best_al:
                best, best_al = sid, al
        ok = best is not None and best_al >= AKV_RIVAL_MIN and best_al > own
        self._akv_rivals = (getattr(self, "_akv_rivals", []) + [best if ok else None])[-AKV_RIVAL_N:]
        if not (ok and self._akv_rivals.count(best) >= AKV_RIVAL_OF):
            return False
        self._akv_rivals, self._streak = [], (None, 0, False)
        self._lock_shabad(best, transcript)
        return True

    def _akv_identify(self, transcript: str, quiet: bool = False):
        """What else is being sung? As sure as identifying any shabad (the same
        streak), then: a later part of the Vaar (the screen had fallen behind), or a
        shabad between pauris, or what comes after the Vaar. quiet: the Vaar matched
        (no candidates shown)."""
        f = self.akv
        bc = self.res.base.find_candidates(transcript, top_k=10)
        pr = self.res.phrase.rank(transcript, 10)
        ranked = gated_rank(bc, pr)
        if not quiet:
            self.candidates = [self._cand(sid, sc) for sid, sc in ranked[:3]]
        if not ranked:
            return
        top = ranked[0][0]
        confident = bool(pr) and pr[0][1] >= 35 and (pr[0][1] - (pr[1][1] if len(pr) > 1 else 0)) >= 10
        prev, n, had = self._streak
        n = n + 1 if top == prev else 1
        had = (had if top == prev else False) or (confident and pr[0][0] == top)
        self._streak = (top, n, had)
        # leaving the Vaar takes a little more than finding a shabad from nothing: sangat
        # singing of a pauri can come out as words of some other shabad for a few checks
        if top in self.res.akv_sids:
            if not ((n >= 2 and had) or n >= 3):
                return
        elif not (((n >= 3 and had) or n >= 4) and self._aligns(top, transcript) >= 5):
            return
        self._streak = (None, 0, False)
        if top in self.res.akv_sids:
            line = f.find(top, transcript)
            if line is not None and f.part_at[line] > f.part_at[f.pos] and f.pauri_no(line) <= f.pauri_no() + 1:
                f.place(line)
                self.status, self._akv_miss, self.candidates = "following", 0, []
            return
        self._lock_shabad(top, transcript)

    def _akv_resume(self, transcript: str) -> bool:
        """A shabad sung between pauris is on screen: has the next chhant begun?"""
        f = self.akv
        nxt = f.resume_line()
        if nxt is None or self.t - getattr(self, "_akv_pause_t", self.t) > AKV_PAUSE_MAX_S:
            self._akv_finish()
            return False
        if f.part(nxt).kind == "salok":              # where it was, or on at the next chhant
            ranges = [(f.part(nxt).first, f.part(nxt).end)]
            if f.next_chhant() is not None:
                ranges.append((f.next_chhant(), f.next_chhant() + 3))
        else:
            ranges = [(nxt, nxt + 3)]
        texts = [x for x in (getattr(self, "_recent", None), transcript) if x]
        best, nxt = max(((f.match_score(x, lo, min(hi, len(f.lines) - 1)), lo) for x in texts for lo, hi in ranges),
                        default=(0.0, nxt))
        cur = self.track["sid"] if self.track and self.track.get("kind") == "shabad" else None
        mine = self._aligns(cur, transcript) if cur is not None else 0.0
        # clearly (five words or so in order), or a little (three) in two checks running,
        # better than the shabad on screen and the shabads the words point to
        soft = best >= AKV_RESUME_SOFT and best > mine + 1
        if soft and AKV_RESUME_OTHERS:
            others = [sid for sid, _ in self.res.phrase.rank(transcript, 10) if sid not in self.res.akv_sids][:3]
            soft = all(best > self._aligns(sid, transcript) + 1 for sid in others)
        self._akv_soft = getattr(self, "_akv_soft", 0) + 1 if soft else 0
        if not (best >= AKV_RESUME and best > mine + 2) and self._akv_soft < 2:
            return False
        self._akv_soft = 0
        self._remember_current()
        self._akv_start(nxt, texts[0])
        return True

    def _akv_state(self) -> dict | None:
        if self.akv is None:
            return None
        p = self.akv.part()
        back = self.akv.resume_line() if self.akv_paused else None
        nxt = self.akv.pauri_no(back) if back is not None else None
        if nxt is not None and self.akv.part(back).kind == "salok" and nxt < 24:
            nxt += 1                                     # (or the salok again)
        return {"pauri": p.n if p else None, "part": p.kind if p else None, "paused": self.akv_paused,
                "next": nxt}

    def _anand_six(self, transcript: str):
        """Anand Sahib in kirtan (after Asa Ki Vaar, and at other times) is sung as
        pauris 1-5, the 40th, and the salok ਪਵਣੁ ਗੁਰੂ: its opening or its 40th pauri
        was found (Resources.anand_parts) - follow those as one shabad."""
        L, pos = self.track["lines"], self.tracker.pos
        g = L[pos]["g"] if pos is not None else ""
        six = self.res.anand_track()
        self._load_track(six, shabad=True)
        key = words_of(g)
        target = next((i for i, ln in enumerate(six["lines"]) if key and words_of(ln["g"]) == key), None)
        if target is not None:
            self.tracker.place(target)
        elif transcript:
            self.tracker.update(transcript)
        if self.tracker.pos is None:
            self.tracker.pos = self.tracker.first
