"""Kirtan, for ConsoleSession (engine_ext/console_session.py): identify the shabad,
follow it line by line, take it down when nothing matches, go back to a recent one,
acoustic matching, and learning from shabads a sewadar picks."""
from __future__ import annotations

from .blend import gated_rank
from .heard import MIN_CLEAR_TO_LEAVE, clear_words
from .learnt import Teacher
from .shabad_follower import ShabadFollower
from .simran import is_simran

RECENT_KEEP = 3            # previous shabads kept close at hand for a quick return
# Evidence over the last EVIDENCE_S: points for places 1-5 in each check. With garbled
# singing a different shabad tops almost every check, but the real one keeps coming back.
EVIDENCE_S, EVIDENCE_PTS = 90.0, (5, 4, 3, 2, 1)
EVIDENCE_MIN_CHECKS, EVIDENCE_MIN_PTS, EVIDENCE_LEAD = 5, 22, 12
BLANK_AFTER_S = 90.0       # nothing heard has matched the shabad on screen for this long: take it down ...
ESTABLISHED = 6            # ... unless it had matched this many checks since it went up (then it was real:
                           # katha or a long alaap about it keeps it up)
# Acoustic matching (engine_ext/acoustic.py): while no shabad has taken hold, each
# check's best shabads by sound (places 1-5) earn points over the last AC_S; one
# that leads clearly is put up, even when the written words match nothing.
ACOUSTIC = True
AC_S, AC_PTS = 90.0, (5, 4, 3, 2, 1)
AC_MIN_CHECKS, AC_LEAD = 4, 16
AC_LEAD_SWITCH = 24        # to replace a shabad that had taken hold (and has since stopped matching)
STRONG_INSIDE = 5.0        # the last words heard line up, in order, in the current shabad (2-3 words)


class KirtanMixin:
    def _coverage(self, transcript: str) -> float:
        """Share of heard words that also occur (fuzzily) in the locked shabad."""
        from rapidfuzz import fuzz
        from rapidfuzz.process import cdist
        from .phrase_matcher import words_of
        q = [w for w in words_of(transcript) if len(w) >= 2]
        if len(q) < 3:
            return -1.0
        sim = cdist(q, self.tracker.words, scorer=fuzz.ratio, workers=1)
        return float((sim.max(axis=1) >= 75).mean())

    def _still_here(self, transcript: str, sid: int) -> bool:
        """Is the locked shabad still among the best explanations of what is heard?
        Compared against all of Gurbani, so long shabads full of common words
        cannot hold the lock on their own."""
        ranked = self.res.phrase.rank(transcript, 20)
        if not ranked:
            return False
        mine = dict(ranked).get(sid, 0.0)
        return mine > 0 and mine >= 0.6 * ranked[0][1]

    def _kirtan_follow(self, transcript: str):
        ev = {"state": "none"}
        if getattr(self, "_recent", None):
            ev = self.tracker.update(self._recent)       # freshest audio decides the line
        if ev["state"] not in ("tracking", "locked"):
            ev = self.tracker.update(transcript)
        cur = self.track["sid"]
        if self.tracker.pos is None:
            self.tracker.pos = self.last_pos if self.last_pos is not None else getattr(self.tracker, "first", 1)
        self.tracker.misses = 0                 # the tracker never decides to leave on its own
        if len(transcript.split()) < 3 or clear_words(transcript) < MIN_CLEAR_TO_LEAVE:
            # too few words, or only fragments ("ਹੈ ਨਾ ਹ ਹ ਮੈ ਨਾ" - a whole sangat singing
            # often comes out like this): nothing to judge by, so hold the shabad on screen
            self.status = "held_quiet"
            self._unmatched_too_long()
            return
        hit = ev["state"] in ("tracking", "locked")      # the tracker decides the LINE ...
        # ... and the shabad: first inside the current shabad (the words just heard
        # line up, in order, in one of its lines), only then against all of Gurbani
        strong = hit and getattr(self.tracker, "strength", 0.0) >= STRONG_INSIDE
        still = strong or self._still_here(transcript, cur)
        if hit and still:
            self.status, self.confidence, self._away, self._last_hit = "following", "high", 0, self.t
            self._last_ok, self._hits = self.t, getattr(self, "_hits", 0) + 1
            return
        stale = self.t - getattr(self, "_last_hit", self.t) >= 90
        if still and not stale:
            self.status, self.confidence, self._away = "following", "medium", 0
            self._last_ok, self._hits = self.t, getattr(self, "_hits", 0) + 1
            return
        if self._unmatched_too_long():
            return
        back = self._returning(transcript)
        if back:
            self._return_to(back, transcript, recent=getattr(self, "_recent", None))
            return
        self._away = getattr(self, "_away", 0) + 1
        self.status, self.confidence = "held_quiet", "low"
        if self._away >= 2 or stale:             # sustained mismatch: look for the next shabad
            if stale:
                self._last_hit = self.t
            self._identify(transcript, exclude_lock=cur)

    def _teacher(self) -> Teacher:
        if getattr(self, "teacher", None) is None:
            self.teacher = Teacher(self.res.learnt)
        return self.teacher

    def _teach(self, transcript: str, t: float):
        """While a sewadar-picked shabad stays on screen, save what is heard."""
        tc = self._teacher()
        if tc.sid is None:
            return
        on = self.track["sid"] if self.track and self.track.get("kind") == "shabad" and self.mode == "kirtan" else None
        if on is None or is_simran(transcript) or clear_words(transcript) < MIN_CLEAR_TO_LEAVE:
            if on != tc.sid:
                tc.stop()
            return
        if tc.heard(on, transcript, t):
            self.res.phrase.set_learnt(self.res.learnt.feature_map())

    def _unmatched_too_long(self) -> bool:
        """Nothing heard has matched the shabad on screen for BLANK_AFTER_S, and
        it never really took hold (fewer than ESTABLISHED matching checks since
        it went up - a wrong guess); sewadar picks and paused auto changes are
        left alone. Take it down rather than leave a possibly wrong shabad up. It goes to the top of the recent
        list, so Back (B, or Previous on the phone) brings it straight back."""
        if (self._sure or self.held_by_user or getattr(self, "_hits", 0) >= ESTABLISHED
                or self.t - getattr(self, "_last_ok", self.t) < BLANK_AFTER_S):
            return False
        if self.track and self.track.get("kind") == "shabad" and self.tracker:
            sid = self.track["sid"]
            pos = self.tracker.pos if self.tracker.pos is not None else self.last_pos
            entry = {"sid": sid, "pos": pos, "high": getattr(self.tracker, "high", None), "t": self.t}
            self.recent = ([entry] + [r for r in self.recent if r["sid"] != sid])[:RECENT_KEEP]
        self.track, self.tracker, self.last_pos = None, None, None
        self.status, self.confidence, self.candidates = "cleared", "low", []
        self._streak, self._away, self.suggestion = (None, 0, False), 0, None
        self.outbox.append({"type": "notice", "message":
                            "Nothing heard matched the shabad for a while, so the screen was cleared. "
                            "Press Back (B) if it should stay."})
        return True

    def _identify(self, transcript: str, exclude_lock: int | None = None):
        words = transcript.split()
        if len(words) < 3:
            self.status = "listening" if self.tracker is None else self.status
            return
        if self.mode == "kirtan" and self.recent:
            back = self._returning(transcript)
            if back:
                self._return_to(back, transcript, recent=getattr(self, "_recent", None))
                return
        bc = self.res.base.find_candidates(transcript, top_k=10)
        pr = self.res.phrase.rank(transcript, 10)
        ranked = gated_rank(bc, pr)
        confident = bool(pr) and pr[0][1] >= 35 and (pr[0][1] - (pr[1][1] if len(pr) > 1 else 0)) >= 10
        self.candidates = [self._cand(sid, sc) for sid, sc in ranked[:3]]
        if not ranked:
            return
        top = ranked[0][0]
        if exclude_lock is not None and top == exclude_lock:
            self._away, self._streak = 0, (None, 0, False)
            self.status = "following"
            return
        if exclude_lock is None or self.status != "following":
            self.status = "finding"
        prev, n, had_conf = self._streak
        n = n + 1 if top == prev else 1
        had_conf = (had_conf if top == prev else False) or (confident and pr[0][0] == top)
        self._streak = (top, n, had_conf)
        if (n >= 2 and had_conf) or n >= 3:
            self._lock_shabad(top, transcript)
            return
        best = self._evidence(ranked, transcript)
        if best is not None and best != exclude_lock:
            self._lock_shabad(best, transcript)

    def wants_acoustic(self) -> bool:
        """Is acoustic matching worth running for the next check? Only in kirtan,
        while no shabad has taken hold (nothing up, or one not yet established or
        no longer matching); never against a sewadar's pick or Hold."""
        if not ACOUSTIC or getattr(self.res, "acoustic", None) is None or self.mode != "kirtan" \
                or self.held_by_user or getattr(self, "_sure", False) or (self.akv is not None and not self.akv_paused):
            return False
        cur = self.track["sid"] if self.track and self.track.get("kind") == "shabad" else None
        return not (cur is not None and getattr(self, "_hits", 0) >= ESTABLISHED and self.status == "following")

    def _acoustic(self, transcript: str):
        """Tally the best shabads by sound; put up one that leads clearly."""
        ac = getattr(self.res, "acoustic", None)
        sounds = getattr(self, "_sounds", None)
        if sounds is None and getattr(self, "_lp", None) is None:
            return
        if not self.wants_acoustic():
            self._ac = []                       # a shabad has taken hold and is being followed
            return
        cur = self.track["sid"] if self.track and self.track.get("kind") == "shabad" else None
        tally = getattr(self, "_ac", None)
        if tally is None:
            tally = self._ac = []
        if clear_words(transcript) >= 1:
            if sounds is None:
                sounds = ac.rank(self._lp, transcript, top=len(AC_PTS))
            tally.append((self.t, [sid for sid, _ in sounds[:len(AC_PTS)]]))
        tally[:] = [x for x in tally if x[0] > self.t - AC_S]
        pts: dict[int, int] = {}
        n: dict[int, int] = {}
        for _, sids in tally:
            for i, sid in enumerate(sids):
                pts[sid] = pts.get(sid, 0) + AC_PTS[i]
                n[sid] = n.get(sid, 0) + 1
        if not pts:
            return
        order = sorted(pts.items(), key=lambda x: -x[1])
        sid, p = order[0]
        runner = order[1][1] if len(order) > 1 else 0
        held = cur is not None and getattr(self, "_hits", 0) >= ESTABLISHED
        need = AC_LEAD_SWITCH if held else AC_LEAD
        if sid != cur and n[sid] >= AC_MIN_CHECKS and p - runner >= need and pts.get(cur, 0) * 2 < p \
                and not (held and pts.get(cur, 0) > 0):
            self._lock_shabad(sid, transcript)
            self.status = "following"

    def _evidence(self, ranked, transcript: str) -> int | None:
        """The shabad that keeps coming back near the top over the last
        EVIDENCE_S, clearly ahead of every other - including the one on screen."""
        ev = getattr(self, "_ev", None)
        if ev is None:
            ev = self._ev = []
        if clear_words(transcript) >= MIN_CLEAR_TO_LEAVE:
            ev.append((self.t, [sid for sid, _ in ranked[:len(EVIDENCE_PTS)]]))
        ev[:] = [x for x in ev if x[0] >= self.t - EVIDENCE_S]
        pts: dict[int, int] = {}
        n: dict[int, int] = {}
        for _, sids in ev:
            for i, sid in enumerate(sids):
                pts[sid] = pts.get(sid, 0) + EVIDENCE_PTS[i]
                n[sid] = n.get(sid, 0) + 1
        if not pts:
            return None
        order = sorted(pts.items(), key=lambda x: -x[1])
        sid, p = order[0]
        runner = order[1][1] if len(order) > 1 else 0
        cur = self.track["sid"] if self.track and self.track.get("kind") == "shabad" else None
        if n[sid] >= EVIDENCE_MIN_CHECKS and p >= EVIDENCE_MIN_PTS and p - runner >= EVIDENCE_LEAD \
                and pts.get(cur, 0) * 2 < p:
            return sid
        return None

    def _returning(self, transcript: str) -> dict | None:
        """Is the ragi back on one of the recent shabads? A recent shabad is
        judged like the one on screen (it only has to be among the best
        explanations of what is heard), plus the words must line up in order
        in its text. One window is then enough to go back."""
        ranked = self.res.phrase.rank(transcript, 30)
        if not ranked or len(transcript.split()) < 4:
            return None
        top = ranked[0][1]
        score = dict(ranked)
        cur = self.track["sid"] if self.track and self.track.get("kind") == "shabad" else None
        for r in self.recent:
            s = score.get(r["sid"], 0.0)
            if s >= 25 and s >= 0.6 * top and s > score.get(cur, 0.0) + 5 and self._aligns(r["sid"], transcript) >= 4:
                return r
        return None

    def _aligns(self, sid: int, transcript: str) -> float:
        """Best in-order word alignment of the transcript inside a shabad."""
        from .phrase_matcher import words_of
        f = self._followers.get(sid)
        if f is None:
            f = self._followers[sid] = ShabadFollower(self.res.shabad_track(sid))
        q = words_of(transcript)
        if len(q) < 3:
            return 0.0
        full, _ = f._line_scores(q)
        return float(full.max()) if len(full) else 0.0

    def _remember_current(self):
        """Keep the shabad we are leaving close at hand - but only if it was
        really being sung (followed for 40 s or more, or picked by the
        sewadar), so a brief wrong guess is never brought back."""
        if not (self.track and self.track.get("kind") == "shabad" and self.tracker):
            return
        if not self._sure and self._last_hit - self._locked_at < 40:
            return
        sid = self.track["sid"]
        pos = self.tracker.pos if self.tracker.pos is not None else self.last_pos
        entry = {"sid": sid, "pos": pos, "high": getattr(self.tracker, "high", None), "t": self.t}
        self.recent = [entry] + [r for r in self.recent if r["sid"] != sid]
        self.recent = self.recent[:RECENT_KEEP]

    def _return_to(self, r: dict, transcript: str, recent: str | None = None):
        sid = r["sid"]
        self._lock_shabad(sid, transcript="")
        if r.get("pos") is not None:
            self.tracker.pos = r["pos"]
        if hasattr(self.tracker, "high"):
            self.tracker.high = r.get("high")
        for text in (recent, transcript):             # place the line from what was just sung
            if text and self.tracker.update(text)["state"] in ("tracking", "locked"):
                break
        self.recent = [x for x in self.recent if x["sid"] != sid]
        self._sure = True                              # it was sung before: worth remembering again
