"""
PhraseMatcher - shabad-level identification that is robust to kirtan-style
repetition.

Idea: instead of comparing the ASR window with one line at a time, compare
the *set* of word pairs (and single words) heard with the set found anywhere
in each shabad. Repeating a phrase ten times adds nothing extra, singing
half-lines separately still matches, and rare phrases count far more than
common ones (IDF weighting). Short saloks are not penalised for having
few lines.

score(shabad) = sum of IDF of heard features found in the shabad
                / sum of IDF of all heard features
"""
from __future__ import annotations

import math
import re
from collections import defaultdict

DROP = str.maketrans("", "", "ੑ੍ੱਂੰ਼")
FOLD = str.maketrans({"ੀ": "ਿ", "ੂ": "ੁ", "ੈ": "ੇ", "ੌ": "ੋ"})
NON_GURMUKHI = re.compile(r"[^\u0A00-\u0A7F ]")
DIGITS = set("੦੧੨੩੪੫੬੭੮੯")


def norm_word(w: str) -> str:
    w = w.translate(DROP).translate(FOLD)
    if len(w) > 2 and w[-1] in "ਿੁ":   # grammatical endings vary in singing/ASR
        w = w[:-1]
    return w


def words_of(text: str) -> list[str]:
    text = NON_GURMUKHI.sub(" ", text.replace("॥", " "))
    out = []
    for w in text.split():
        if any(c in DIGITS for c in w):
            continue
        w = norm_word(w)
        if len(w) >= 2:
            out.append(w)
    return out


JOIN_WORDS = False                  # tried: helped some lines, broke a long composition (Salok Vaaran Thay Vadheek 97% -> 12%)


def features(words: list[str], bigram_weight: float = 1.0) -> list[str]:
    """Words and word pairs, each once, in a fixed order (a set's order changes
    from run to run with Python's string hashing, and with it the order scores
    are added up - enough to flip a close call now and then)."""
    f = set(words)
    f.update(f"{a}_{b}" for a, b in zip(words, words[1:]))
    if JOIN_WORDS:                        # ਗੁਰ ਸਿਖ / ਗੁਰਸਿਖ: words written apart also count joined
        f.update(a + b for a, b in zip(words, words[1:]) if len(a) + len(b) >= 5)
    return sorted(f)


STANZA_END = re.compile(r"॥\s*[੦-੯]+\s*॥")
SPLIT_OVER, PART_MIN, PART_MAX = 60, 6, 24


def parts_of(texts: list[str]) -> list[list[str]]:
    """A long composition (Oankaar, Salok Vaaran Thay Vadheek, Baarah Maahaa ...)
    split into its own stanzas, grouped to PART_MIN..PART_MAX lines. Matched as
    one unit, 300-400 lines contain nearly any garbled words somewhere and win
    whenever the recogniser struggles."""
    if len(texts) <= SPLIT_OVER:
        return [texts]
    parts, cur = [], []
    for t in texts:
        cur.append(t)
        if (STANZA_END.search(t) and len(cur) >= PART_MIN) or len(cur) >= PART_MAX:
            parts.append(cur)
            cur = []
    if cur:
        if parts and len(cur) < PART_MIN:
            parts[-1] += cur
        else:
            parts.append(cur)
    return parts


class PhraseMatcher:
    def __init__(self, corpus, min_words: int = 2):
        self.index: dict[str, set[int]] = defaultdict(set)
        self.first_line: dict[int, str] = {}
        self.doc_sid: dict[int, int] = {}      # a part of a long composition -> its shabad
        n = 0
        for sid in corpus.shabads:
            lines = corpus.get_lines(sid)
            texts = [(l.get("gurmukhi", {}) or {}).get("unicode") or l.get("unicode", "")
                     for l in lines]
            parts = parts_of(texts)
            for k, part in enumerate(parts):
                words = []
                for t in part:
                    words += words_of(t)   # join lines: phrases can span a line break
                if len(words) < min_words:
                    continue
                doc = sid if len(parts) == 1 else -(sid * 1000 + k)
                self.doc_sid[doc] = sid
                n += 1
                for feat in features(words):
                    self.index[feat].add(doc)
            self.first_line[sid] = next((t for t in texts[1:] if t and not t.startswith("ੴ")),
                                        texts[0] if texts else "")
        self.n = n
        self.idf = {f: math.log(n / len(s)) for f, s in self.index.items()}

    # heard words learnt for a shabad (engine_ext.learnt) that are not Gurbani words
    # at all weigh this much - less than the rarest real word (about 8.6)
    LEARNT_IDF = 5.0

    def set_learnt(self, fmap: dict[str, set[int]]):
        """Extra evidence: garbled words the recogniser has produced while a
        confirmed shabad was sung, mapped to that shabad."""
        self.learnt = fmap

    def rank(self, transcript: str, top_k: int = 10) -> list[tuple[int, float]]:
        learnt = getattr(self, "learnt", None) or {}
        feats = features(words_of(transcript))
        feats = [f for f in feats if f in self.idf or f in learnt]
        total = sum(self.idf.get(f, self.LEARNT_IDF) for f in feats) or 1.0
        per_doc: dict[int, float] = defaultdict(float)
        for f in feats:
            w = self.idf.get(f, 0.0)
            for doc in self.index.get(f, ()):
                per_doc[doc] += w
        acc: dict[int, float] = defaultdict(float)
        for doc, v in per_doc.items():          # a long composition scores as its best part
            sid = self.doc_sid.get(doc, doc)
            acc[sid] = max(acc[sid], v)
        for f in feats:
            if f not in learnt:
                continue
            w = self.idf.get(f, self.LEARNT_IDF)
            own = {self.doc_sid.get(d, d) for d in self.index.get(f, ())}
            for sid in learnt[f]:
                if sid not in own:
                    acc[sid] += w
        ranked = sorted(((sid, 100 * s / total) for sid, s in acc.items()),
                        key=lambda x: -x[1])
        return ranked[:top_k]
