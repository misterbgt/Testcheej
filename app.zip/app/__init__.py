"""Gurbani Audio Searcher: the laptop app around the engine (engine/, engine_ext/).

  core.py      what the laptop app and the web version share: settings, history,
               screen messages and the sewadar's commands
  hub.py       the laptop's hub: the windows, phones and screens connected to it
  server.py    the local web server and start-up (console_app.py runs it)
  paths.py     where things are kept;  model.py  the speech model
  windows.py   the app's own windows;  network.py  phones on the Wi-Fi
  messages.py  pictures and messages for the screens;  lock.py  the lock code
  cast.py      casting to a Chromecast;  tls.py  the secure address for phones

The version is set here only: the pages get it from the server (__VERSION__ and
__VERSION_NAME__ in pages/*.html), the web version from its build.
"""
VERSION = "2026-10-13b"     # build stamp: pages left open reload when it changes
VERSION_NAME = "ਅ੩"         # the version sewadars see: a Gurmukhi letter (ੳ, ਅ, ੲ, ਸ, ਹ ...) for a bigger
                            # change, then Gurmukhi numerals counting the updates within it
