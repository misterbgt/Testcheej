"""What the laptop app (app/hub.py) and the web version (web/web_hub.py) share: the
settings and their limits, the history, the screen messages (ਵਾਹਿਗੁਰੂ, a message or a
picture instead of the Gurbani), how often the words heard are checked, and the
sewadar's commands to the console session (engine_ext/console_session.py).

Only the standard library and the engine are used here, so the web version can run it
in the browser (Pyodide). Each side keeps the pictures and recent messages its own way
(the laptop in its data folder, the web version in the page), through the few methods
marked "each side".
"""
from __future__ import annotations

import logging
import re
import time

from engine_ext.console_session import ConsoleSession

HOP_S = {"kirtan": 5.0, "paath": 3.0, "akv": 3.0}   # seconds between full checks; akv: following Asa Ki Vaar
                                                    # (saloks are read quickly)
QUICK_HOP_S, QUICK_WIN_S = 1.5, 4.5      # short check for words of another line (kirtan; Akhand / Sehaj Paath)
HISTORY_AFTER_S = 15                     # a shabad goes into the history once it has been on screen this long
HISTORY_KEEP = 200                       # entries kept in the history (the screens get the newest 100)
MSG_IMAGES_KEPT, MSG_TEXTS_KEPT = 8, 8   # recent pictures and messages offered again
IMAGE_NAME = re.compile(r"[0-9a-f]{16}\.(png|jpg|gif)")

DEFAULT_SETTINGS = {"en": True, "tr": False, "prev": False, "next": True, "predict": True, "phone": True,
                    "notice": True,                      # testing notice along the bottom of the sangat screen
                    "learn": True,                       # learn from shabads a sewadar picks (engine_ext/learnt.py)
                    # text sizes in percent: current Gurmukhi line, previous line, next line,
                    # translation, transliteration, and the whole sangat screen (100 = fill it)
                    "fs_g": 100, "fs_prev": 100, "fs_next": 100, "fs_en": 100, "fs_tr": 100, "fs_all": 100,
                    # livestream overlay (/overlay, overlay.html): where it sits, how wide (percent
                    # of the picture), colours, background strength (percent, 0 = text only),
                    # Gurbani and translation sizes, and whether the English shows
                    "ov_pos": "top-middle", "ov_width": 80, "ov_bg": "#0F1A30", "ov_gc": "#FFFFFF",
                    "ov_tc": "#F2D9A6", "ov_op": 0, "ov_gs": 100, "ov_ts": 100, "ov_en": True,
                    # Rehras, Chaupai, Sohila and Aarti come in several lengths (as on SikhiToTheMax):
                    # the one followed when the bani is found by itself
                    "bani_length": "long"}
SIZE_LIMITS = {"fs_all": (40, 100), "ov_op": (0, 100), "ov_width": (30, 100)}       # others: 50-200
CHOICES = {"ov_pos": ("top-left", "top-middle", "top-right", "bottom-left", "bottom-middle", "bottom-right"),
           "bani_length": ("short", "medium", "long", "extra long")}
log = logging.getLogger("console")


def bani_menu(res):
    """The banis in the order they are listed: each one's lengths together, shortest first."""
    out, done = [], set()
    for b in res.banis.values():
        if b["id"] in done:
            continue
        for v in res.variants(b["id"]):
            out.append(res.banis[v])
            done.add(v)
    return out


class HubCore:
    def __init__(self):
        self.res = self.sess = None
        self.settings = dict(DEFAULT_SETTINGS)
        self.history: list[dict] = []              # newest first, for as long as the app runs
        self._on_screen = (None, 0.0)              # (track id, since)
        self.last_track = self.last_state = None
        self.line_at: dict[str, dict] = {}         # track id -> the line last shown in it (History goes back there)
        self.screen_msg = None                    # ਵਾਹਿਗੁਰੂ, a message or a picture shown instead of the Gurbani

    # -------------------------------------------------------------- the session
    def new_session(self) -> ConsoleSession:
        sess = ConsoleSession(self.res, mode="kirtan")
        self.configure(sess)
        return sess

    def configure(self, sess):
        sess.predict_enabled = bool(self.settings.get("predict", True))
        sess.bani_length = self.settings.get("bani_length", "long")
        sess._teacher().enabled = bool(self.settings.get("learn", True))

    def hop(self) -> float:
        """Seconds between full checks: quicker while Asa Ki Vaar is followed."""
        sess = self.sess
        if sess.mode == "kirtan" and sess.akv is not None and not sess.akv_paused:
            return HOP_S["akv"]
        return HOP_S.get(sess.mode, 5.0)

    def banis(self) -> list[dict]:
        return [{"id": b["id"], "name": b["name"], "name_gurmukhi": b["name_gurmukhi"]} for b in bani_menu(self.res)]

    def take(self, msgs) -> bool:
        """Messages on their way to the screens: remember the latest track and state.
        True when the history changed (so it goes out too)."""
        for m in msgs:
            if m["type"] == "track":
                self.last_track = m
            elif m["type"] == "state":
                self.last_state = m
                self.note_line(m)
        return any(m["type"] == "state" and self.note_history(m) for m in list(msgs))

    def note_line(self, st):
        """Remember the line on screen in each shabad or bani, so that picking it again
        from the History goes back to that line."""
        tid, pos, lt = st.get("track_id"), st.get("pos"), self.last_track
        if not tid or pos is None or not lt or lt["track"].get("id") != tid:
            return
        lines = lt["track"].get("lines") or []
        if not 0 <= int(pos) < len(lines):
            return
        ln = lines[int(pos)]
        self.line_at[tid] = {"pos": int(pos), "sid": ln.get("sid"), "g": ln.get("g", "")}
        if len(self.line_at) > 2 * HISTORY_KEEP:
            keep = {e["key"] for e in self.history} | {tid}
            self.line_at = {k: v for k, v in self.line_at.items() if k in keep}

    def line_back(self, key: str, sid: int):
        """The shabad and line to show for a History entry: the line last shown in it,
        as sess.show takes them (sid, line); the line is None when not known."""
        at = self.line_at.get(key)
        if not at:
            return sid, None
        if key.startswith("b"):                      # a bani (or Asa Ki Vaar): its own line
            return sid, at["pos"]
        if key.startswith("g"):                      # Akhand / Sehaj Paath: that line of the Granth
            try:
                g0 = int(key[1:].split("-")[0])
            except ValueError:
                return sid, None
            return self.res.granth.corpus_line(g0 + at["pos"])
        if key == f"s{at.get('sid')}":               # a shabad: its own line
            return int(at["sid"]), at["pos"]
        for s in sorted(self.res.anand_parts):       # Anand Sahib's six pauris (k6): the line in its part
            i = next((i for i, l in enumerate(self.res.shabad_track(s)["lines"]) if l["g"] == at["g"]), None)
            if i is not None:
                return s, i
        return sid, None

    # -------------------------------------------------------------- settings
    def apply_settings(self, c: dict):
        """Take the settings given in c, each checked against its kind and limits."""
        for k, default in DEFAULT_SETTINGS.items():
            if k not in c:
                continue
            if isinstance(default, bool):
                self.settings[k] = bool(c[k])
            elif isinstance(default, str):
                v = str(c[k])
                if v in CHOICES.get(k, ()) or (k not in CHOICES and re.fullmatch(r"#[0-9A-Fa-f]{6}", v)):
                    self.settings[k] = v
            else:
                lo, hi = SIZE_LIMITS.get(k, (50, 200))
                try:
                    self.settings[k] = max(lo, min(hi, int(round(float(c[k])))))
                except (TypeError, ValueError):
                    pass

    def save_settings(self):
        """Each side: keep the settings for next time."""

    # -------------------------------------------------------------- history
    def note_history(self, st) -> bool:
        """Add the shabad (or bani) on screen to the history once it has stayed
        there for a while, or at once if the sewadar chose it."""
        tid = st.get("track_id")
        if not tid or (st.get("pos") is None and st.get("last_pos") is None):
            return False
        now = time.time()
        if self._on_screen[0] != tid:
            self._on_screen = (tid, now)
        if self.history and self.history[0]["key"] == tid:
            return False
        settled = (now - self._on_screen[1] >= HISTORY_AFTER_S
                   and st.get("status") in ("following", "held_simran", "held_quiet", "held_user"))
        if not (settled or st.get("confidence") == "manual"):
            return False
        tr = self.last_track["track"] if self.last_track and self.last_track["track"]["id"] == tid else None
        if not tr:
            return False
        e = {"key": tid, "kind": tr["kind"], "sid": tr.get("sid"), "bani_id": tr.get("bani_id"),
             "title": tr.get("title", ""), "where": tr.get("subtitle", ""), "time": time.strftime("%H:%M"),
             "mode": st.get("mode")}
        if tr["kind"] == "bani":                    # (Asa Ki Vaar followed in kirtan is a bani too)
            e["where"] = ("Kirtan: " if st.get("mode") == "kirtan" else "Paath: ") + (tr.get("subtitle") or "")
        elif tr["kind"] == "granth":                 # Akhand / Sehaj Paath: each shabad as it is reached
            e["kind"] = "shabad"
            e["where"] = "Akhand / Sehaj Paath, " + (tr.get("subtitle") or "")
        self.history.insert(0, e)
        del self.history[HISTORY_KEEP:]
        self.history_added(e)
        return True

    def history_added(self, e: dict):
        """Each side: a shabad has just gone into the history."""

    def history_msg(self):
        return {"type": "history", "items": self.history[:100]}

    # -------------------------------------------------------------- screen messages
    def screen_msg_msg(self) -> dict:
        """Each side: what the screens show instead of the Gurbani (None: the Gurbani),
        with the recent pictures and messages."""
        raise NotImplementedError

    def remember_text(self, text: str):
        """Each side: a message just shown, kept at the top of the recent ones."""

    def image_ok(self, name: str) -> bool:
        """Each side: is this picture still there to show?"""
        return True

    def image_used(self, name: str):
        """Each side: a picture just shown."""

    def forget_image(self, name: str):
        """Each side: the sewadar removed a picture from the recent ones."""

    def set_screen_msg(self, c) -> list:
        kind = c.get("kind")
        where = {"screens": bool(c.get("screens", True)), "overlay": bool(c.get("overlay", True))}
        if kind == "vaheguru":
            self.screen_msg = {"kind": "vaheguru", "text": "ਵਾਹਿਗੁਰੂ", **where}
        elif kind == "text":
            text = " ".join(str(c.get("text", "")).split())[:200]
            if not text:
                return []
            self.screen_msg = {"kind": "text", "text": text, **where}
            self.remember_text(text)
        elif kind == "image":
            name = str(c.get("image", ""))
            if not IMAGE_NAME.fullmatch(name) or not self.image_ok(name):
                return []
            self.image_used(name)
            self.screen_msg = {"kind": "image", "image": "/message-image/" + name, **where}
        elif kind == "forget_image":
            name = str(c.get("image", ""))
            self.forget_image(name)
            if self.screen_msg and self.screen_msg.get("image") == "/message-image/" + name:
                self.screen_msg = None
        else:
            self.screen_msg = None
        log.info("screen message: %s", self.screen_msg)
        return [self.screen_msg_msg()]

    # -------------------------------------------------------------- commands
    def on_reset(self):
        """Each side: Start over was pressed (the sound heard so far no longer counts)."""

    def command(self, c: dict) -> list:
        """A sewadar's command (console, phone or the web page): the messages for the screens."""
        sess, cmd = self.sess, c.get("cmd")
        if cmd == "hold":
            return sess.hold(bool(c.get("on", True)))
        if cmd == "step":
            return sess.step(int(c.get("delta", 1)))
        if cmd == "goto":
            return sess.goto(int(c.get("pos", 0)))
        if cmd == "confirm":
            return sess.confirm(int(c["sid"]))
        if cmd == "reset":
            self.on_reset()
            return sess.reset()
        if cmd == "mode":
            bid = c.get("bani_id")
            sehaj = c.get("sehaj")
            return sess.set_mode(c.get("mode", "kirtan"), int(bid) if bid not in (None, "") else None,
                                 None if sehaj is None else bool(sehaj))
        if cmd == "accept_suggestion":
            return sess.accept_suggestion()
        if cmd == "akv":                               # Asa Ki Vaar: start, next, resume, pauri (n), end
            n = c.get("n")
            return sess.akv_command(str(c.get("action", "")), int(n) if str(n).isdigit() else None)
        if cmd == "back":
            return sess.back(c.get("sid"))
        if cmd == "show":
            bid = c.get("bani_id")
            sid, pos, key = int(c.get("sid") or 0), c.get("pos"), str(c.get("key") or "")
            if pos is None and key:                    # picked from the History: back at the line last shown
                sid, pos = self.line_back(key, sid)
            out = sess.show(sid, None if pos is None else int(pos), int(bid) if bid not in (None, "") else None)
            at = self.line_at.get(key) if key == "k6" else None
            if at and sess.track and sess.track.get("id") == "k6" and sess.tracker.pos != at["pos"]:
                out = [m for m in out if m["type"] != "state"] + sess.goto(at["pos"])   # (lines no part has)
            return out
        if cmd == "screen_msg":
            return self.set_screen_msg(c)
        if cmd == "settings":
            self.apply_settings(c)
            if sess:
                self.configure(sess)
            self.save_settings()
            return [{"type": "settings", "settings": self.settings}]
        return []
